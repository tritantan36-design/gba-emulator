# GBA Lite 1.0.1

离线 Android GBA 模拟器，Kotlin/Compose、JNI、源构建 mGBA、GLES2 与 Oboe。最新正式版本 **1.0.1/code15，本地 STABLE**，沿用 V1.0.0 生产证书。V1.0.0 的 Phase7 READY、Phase8 COMPLETE 及历史 tag 保持不变，未自动发布到GitHub或商店。

- [V1.0.1 正式收尾](docs/reports/V1_0_1_LANDSCAPE_EDGE_TO_EDGE_CONTROL_LAYOUT_REPORT.md) · [V1.0.1 发布说明](docs/RELEASE_NOTES_V1.0.1.md) · [V1.0.0 发布报告](docs/reports/PHASE_8_V1_RELEASE_AND_STABLE_PROMOTION_REPORT.md)
- [发布说明](docs/RELEASE_NOTES_V1.0.0.md) · [已知限制](docs/V1_KNOWN_LIMITATIONS.md) · [发布清单](docs/V1_RELEASE_CHECKLIST.md)
- [Debug→正式签名迁移](docs/DEBUG_TO_PRODUCTION_SIGNING_MIGRATION.md)：签名不同，不能覆盖安装；不要直接卸载旧Debug丢失私有数据。
- [签名密钥备份](docs/reports/PHASE_8_SIGNING_KEY_BACKUP_GUIDE.md)：正式密钥在仓库外，必须长期复用并安全备份。

V1.0.1 已完成同证书签名、正式包 smoke、覆盖升级和用户视觉确认。V1.1 从此冻结基线按阶段开发，尚未正式发布。

开发入口：[项目规格](PROJECT_SPEC.md)、[架构](ARCHITECTURE.md)、[测试](docs/TESTING.md)、[存档格式](docs/SAVE_FORMAT.md)、[显示](docs/RENDERER.md)、[外设](docs/GBA_PERIPHERALS.md)、[安全](docs/SECURITY.md)、[ADR](docs/adr/)。

构建环境：Temurin JDK21、Gradle8.14.3、AGP8.13.0、SDK36、NDK27.2.12479018、CMake3.22.1；Android8/API26+、arm64-v8a。配置local.properties或ANDROID_HOME。

```sh
./gradlew :app:assembleDebug :app:assembleRelease test lint :app:exportRuntimeDependencies
python scripts/audit.py --phase7a
```

Gradle Release输出unsigned包；正式V1由外部production配置通过apksigner签名，见scripts/phase8_release.py。Debug包含开发测试接口，Release没有这些接口。当前签名配置与密码不进入Git或源码归档。

设备回归使用专用模拟器/测试设备和明确serial，见[设备策略](docs/ANDROID_TEST_DEVICE_STRATEGY.md)及scripts/android_emulator.py。connected测试仅用于授权环境；不可清除用户现有应用。x86兼容包只用于测试，正式产品仍仅ARM64，不能作为实机认证。

本项目不分发商业ROM或BIOS；合法测试资产、源码和许可证在test-rom/及androidTest，详见[GBA测试语料](GBA_TEST_ROM_CORPUS.md)。mGBA/Oboe官方源码与锁定清单在third_party/；原LICENSE/NOTICE均保留。

2026-10-11完成项目历史清理，源码/测试/正式V1包和签名不变。旧过程报告、截图、候选APK及日志已迁至项目外，参见[历史归档索引](docs/HISTORY_ARCHIVE.md)与[清理审计](docs/reports/PROJECT_HISTORY_CLEANUP_REPORT.md)。当前保留V1发布证据与Phase7最终收口依据，构建缓存可重新生成。
