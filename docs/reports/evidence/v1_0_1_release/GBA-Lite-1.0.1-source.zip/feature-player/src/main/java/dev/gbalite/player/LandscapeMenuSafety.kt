package dev.gbalite.player

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.mandatorySystemGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import dev.gbalite.input.*
import kotlin.math.roundToInt

/** MENU has its own collision check; it never pads or shrinks the control canvas. */
@Composable internal fun landscapeMenuSafety(): Modifier {
    val root=LocalView.current.rootView
    val density=LocalDensity.current
    // Observe inset changes, including reverse landscape, without reserving their aggregate area.
    val cutout=WindowInsets.displayCutout
    val gestures=WindowInsets.mandatorySystemGestures
    val observed=listOf(cutout.getLeft(density,LayoutDirection.Ltr),cutout.getRight(density,LayoutDirection.Ltr),
        cutout.getTop(density),cutout.getBottom(density),gestures.getTop(density),gestures.getBottom(density))
    var size by remember {mutableStateOf(IntSize.Zero)}
    return Modifier.onSizeChanged {size=it}.offset {
        observed.hashCode()
        val rect=ControlRect((root.width-size.width)/2f,0f,(root.width+size.width)/2f,size.height.toFloat())
        val moved=avoidControlObstacles(rect,root.width.toFloat(),root.height.toFloat(),controlEnvironment(root).obstacles)
        IntOffset((moved.left-rect.left).roundToInt(),(moved.top-rect.top).roundToInt())
    }
}
