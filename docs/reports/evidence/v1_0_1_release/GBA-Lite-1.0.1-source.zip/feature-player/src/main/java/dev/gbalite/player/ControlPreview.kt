package dev.gbalite.player

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import dev.gbalite.input.*
import kotlin.math.max
import kotlin.math.min

/** Letterbox the editor to the player control area's aspect, rather than stretching its coordinates. */
@Composable fun ControlPreview(profile: InputProfile,router: InputRouter,selected: String,
    onEdited: (InputProfile)->Unit,onSelected: (String)->Unit,modifier: Modifier=Modifier,
    background: @Composable BoxScope.()->Unit={}) {
    val config=LocalConfiguration.current
    val density=LocalDensity.current
    val root=LocalView.current.rootView
    val windowWidth=if(root.width>0) root.width.toFloat() else config.screenWidthDp*density.density
    val windowHeight=if(root.height>0) root.height.toFloat() else config.screenHeightDp*density.density
    // Landscape play hides system bars. Its preview must reserve cutouts only,
    // rather than inheriting the settings page's visible status/navigation bars.
    val insets=if(profile.landscape) WindowInsets(0,0,0,0) else WindowInsets.safeDrawing
    val vertical=insets.getTop(density)+insets.getBottom(density)
    val horizontal=insets.getLeft(density,androidx.compose.ui.unit.LayoutDirection.Ltr)+insets.getRight(density,androidx.compose.ui.unit.LayoutDirection.Ltr)
    val currentlyLandscape=windowWidth>windowHeight
    val w=if(profile.landscape==currentlyLandscape) windowWidth-horizontal else windowHeight-vertical
    val h=if(profile.landscape==currentlyLandscape) windowHeight-vertical else windowWidth-horizontal
    val ratio=if(profile.landscape) max(w,h)/min(w,h).coerceAtLeast(1f)
        else min(w,h)/(max(w,h)-min(w,h)/1.5f-portraitScreenInset(min(w,h),max(w,h),density.density)).coerceAtLeast(1f)
    BoxWithConstraints(modifier,contentAlignment=Alignment.Center) {
        val fitted=if(maxWidth/maxHeight>ratio) Modifier.fillMaxHeight().aspectRatio(ratio) else Modifier.fillMaxWidth().aspectRatio(ratio)
        Box(fitted) {
            background()
            AndroidView(factory={TouchControls(it,router)},update={view->view.previewWidth=if(profile.landscape) max(w,h) else min(w,h);view.profile=profile;view.editing=true;view.selectedKey=selected;view.onEdited=onEdited;view.onSelected=onSelected},
                modifier=Modifier.fillMaxSize().testTag("layout-preview"))
        }
    }
}
