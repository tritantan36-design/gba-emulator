package dev.gbalite.player

import android.view.View
import dev.gbalite.input.ControlRect

data class ControlEnvironment(val legacy: ControlRect,val obstacles: List<ControlRect>)

/** Actual cutout rectangles, never safeDrawing/systemBars. Preview uses the same scaled window. */
internal fun controlEnvironment(view: View,preview: Boolean=false): ControlEnvironment {
    val root=view.rootView
    val windowWidth=if(preview) maxOf(root.width,root.height).toFloat() else view.width.toFloat()
    val windowHeight=if(preview) minOf(root.width,root.height).toFloat() else view.height.toFloat()
    if(windowWidth<=0 || windowHeight<=0) return ControlEnvironment(ControlRect(0f,0f,view.width.toFloat(),view.height.toFloat()),emptyList())
    val scaleX=view.width/windowWidth;val scaleY=view.height/windowHeight
    val insets=androidx.core.view.ViewCompat.getRootWindowInsets(root)
    val cutout=insets?.displayCutout
    val rotate=preview && root.width<root.height
    fun rect(l: Float,t: Float,r: Float,b: Float)=if(rotate) ControlRect(t*scaleX,l*scaleY,b*scaleX,r*scaleY)
        else ControlRect(l*scaleX,t*scaleY,r*scaleX,b*scaleY)
    val cutouts=cutout?.boundingRects.orEmpty().map {rect(it.left.toFloat(),it.top.toFloat(),it.right.toFloat(),it.bottom.toFloat())}
    val gestures=insets?.getInsets(androidx.core.view.WindowInsetsCompat.Type.mandatorySystemGestures())
    val top=if(rotate) 0f else (gestures?.top ?: 0)*scaleY
    val bottom=if(rotate) 0f else (gestures?.bottom ?: 0)*scaleY
    val left=(if(rotate) cutout?.safeInsetTop else cutout?.safeInsetLeft ?: 0) ?: 0
    val right=(if(rotate) cutout?.safeInsetBottom else cutout?.safeInsetRight ?: 0) ?: 0
    val cutoutTop=(if(rotate) cutout?.safeInsetLeft else cutout?.safeInsetTop ?: 0) ?: 0
    val cutoutBottom=(if(rotate) cutout?.safeInsetRight else cutout?.safeInsetBottom ?: 0) ?: 0
    val legacy=ControlRect(left*scaleX,maxOf(cutoutTop*scaleY,top),view.width-right*scaleX,view.height-maxOf(cutoutBottom*scaleY,bottom))
    val obstacles=cutouts+buildList {
        if(top>0f) add(ControlRect(0f,0f,view.width.toFloat(),top))
        if(bottom>0f) add(ControlRect(0f,view.height-bottom,view.width.toFloat(),view.height.toFloat()))
    }
    return ControlEnvironment(legacy,obstacles)
}
