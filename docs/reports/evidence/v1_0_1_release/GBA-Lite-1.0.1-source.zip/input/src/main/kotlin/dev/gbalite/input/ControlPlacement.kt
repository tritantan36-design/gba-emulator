package dev.gbalite.input

import kotlin.math.abs

/** Window-relative geometry; no Android types, also used by the editor and MENU. */
data class ControlRect(val left: Float,val top: Float,val right: Float,val bottom: Float) {
    val width get()=right-left
    val height get()=bottom-top
    fun intersects(other: ControlRect)=left<other.right && right>other.left && top<other.bottom && bottom>other.top
    fun moved(dx: Float,dy: Float)=ControlRect(left+dx,top+dy,right+dx,bottom+dy)
}

/** Move only an intersecting control, choosing the shortest feasible separating translation. */
fun avoidControlObstacles(rect: ControlRect,width: Float,height: Float,obstacles: List<ControlRect>): ControlRect {
    var result=rect
    repeat(obstacles.size+1) {
        val obstacle=obstacles.firstOrNull {result.intersects(it)} ?: return result
        val candidates=listOf(
            result.moved(obstacle.left-result.right,0f),result.moved(obstacle.right-result.left,0f),
            result.moved(0f,obstacle.top-result.bottom),result.moved(0f,obstacle.bottom-result.top))
            .filter {it.left>=0f && it.top>=0f && it.right<=width && it.bottom<=height}
        val next=candidates.minWithOrNull(compareBy<ControlRect> {candidate->obstacles.count {candidate.intersects(it)}}
            .thenBy {abs(it.left-result.left)+abs(it.top-result.top)}) ?: return result
        if(next==result) return result
        result=next
    }
    return result
}

/** Preserve an old custom layout's pixel placement and size in the full-window coordinate space. */
fun InputProfile.inFullWindow(width: Float,height: Float,legacy: ControlRect,density: Float=1f): InputProfile {
    if(!landscape || coordinateSpace>=2 || width<=0f || height<=0f) return this
    val scale=minOf(legacy.width,legacy.height)/minOf(width,height)
    return copy(coordinateSpace=2,controls=controls.map {
        val radius=minOf(maxOf(it.size*minOf(legacy.width,legacy.height)*1.45f/2,24*density),minOf(legacy.width,legacy.height)*.45f)
        val rx=when(it.key) {"L","R"->radius*1.20f;"START","SELECT"->maxOf(36*density,radius*1.25f);else->radius}
        val ry=when(it.key) {"L","R"->maxOf(24*density,radius*.40f);"START","SELECT"->maxOf(24*density,radius*.38f);else->radius}
        val x=if(legacy.width>=2*rx) (it.x*legacy.width).coerceIn(rx,legacy.width-rx) else legacy.width/2
        val y=if(legacy.height>=2*ry) (it.y*legacy.height).coerceIn(ry,legacy.height-ry) else legacy.height/2
        it.copy(x=((legacy.left+x)/width).coerceIn(0f,1f),y=((legacy.top+y)/height).coerceIn(.08f,.92f),
            size=(it.size*scale).coerceIn(InputProfile.MIN_SIZE,InputProfile.MAX_SIZE))
    })
}
