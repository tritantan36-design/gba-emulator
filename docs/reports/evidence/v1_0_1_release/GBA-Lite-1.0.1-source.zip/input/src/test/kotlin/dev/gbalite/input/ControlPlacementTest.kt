package dev.gbalite.input

import org.junit.Assert.*
import org.junit.Test

class ControlPlacementTest {
    @Test fun nonCollidingControlsAreNeverMoved() {
        val dpad=ControlRect(0f,200f,160f,360f)
        for(hole in listOf(ControlRect(0f,20f,60f,80f),ControlRect(940f,20f,1000f,80f),ControlRect(400f,0f,600f,40f)))
            assertEquals(dpad,avoidControlObstacles(dpad,1000f,500f,listOf(hole)))
    }
    @Test fun leftRightAndWideCutoutsOnlyMoveCollidingControl() {
        for((control,hole) in listOf(
            ControlRect(0f,20f,100f,80f) to ControlRect(0f,30f,40f,70f),
            ControlRect(900f,20f,1000f,80f) to ControlRect(960f,30f,1000f,70f),
            ControlRect(450f,8f,550f,70f) to ControlRect(400f,0f,600f,40f))) {
            val placed=avoidControlObstacles(control,1000f,500f,listOf(hole))
            assertFalse(placed.intersects(hole));assertEquals(control.width,placed.width);assertEquals(control.height,placed.height)
            assertTrue(placed.left>=0 && placed.right<=1000 && placed.top>=0 && placed.bottom<=500)
        }
    }
    @Test fun mandatoryBottomStripMovesOnlyBottomControl() {
        val strip=ControlRect(0f,480f,1000f,500f)
        val middle=ControlRect(300f,200f,400f,260f)
        assertEquals(middle,avoidControlObstacles(middle,1000f,500f,listOf(strip)))
        val bottom=avoidControlObstacles(ControlRect(300f,450f,400f,500f),1000f,500f,listOf(strip))
        assertEquals(480f,bottom.bottom);assertFalse(bottom.intersects(strip))
    }
    @Test fun oldCustomProfileKeepsAbsoluteCentersAndSizeAndConvertsOnlyOnce() {
        val old=InputProfile.default(true).copy(coordinateSpace=1,controls=InputProfile.default(true).controls.map {it.copy(x=.35f,y=.5f)})
        val safe=ControlRect(60f,10f,1000f,480f)
        val next=old.inFullWindow(1000f,500f,safe)
        assertEquals(2,next.coordinateSpace)
        old.controls.zip(next.controls).forEach {(before,after)->
            assertEquals(60f+before.x*940f,after.x*1000f,.001f)
            assertEquals(10f+before.y*470f,after.y*500f,.001f)
            assertEquals(before.size*470f,after.size*500f,.001f)
        }
        assertEquals(next,next.inFullWindow(1000f,500f,safe))
        assertEquals(1,old.coordinateSpace)
        val portrait=InputProfile.default(false).copy(coordinateSpace=1)
        assertEquals(portrait,portrait.inFullWindow(1000f,500f,safe))
    }
    @Test fun untouchedOldDefaultUsesFullWindowButCustomIsRetained() {
        val old=InputProfile.default(true).copy(coordinateSpace=1)
        assertEquals(InputProfile.default(true),old.withCurrentLandscapeDefaults())
        val custom=old.copy(controls=old.controls.map {if(it.key=="DPAD") it.copy(x=.22f) else it})
        assertEquals(custom,custom.withCurrentLandscapeDefaults())
    }
}
