@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.core.*
import dev.gbalite.input.*
import dev.gbalite.player.TouchControls
import dev.gbalite.renderer.OriginalSurface
import dev.gbalite.session.SessionState
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.File

class TouchUiPolishTest {
    @Test fun oldCustomProfileReadDoesNotRewriteOrResetUserValues() {
        val root=File(InstrumentationRegistry.getInstrumentation().targetContext.cacheDir,"hotfix-profile-${System.nanoTime()}")
        val store=PrivateInputProfiles(root)
        val custom=InputProfile.default(true).copy(controls=InputProfile.default(true).controls.map {if(it.key=="DPAD") it.copy(x=.22f) else it},opacity=.73f)
        store.write(custom)
        val file=File(root,"input/landscape.json")
        val json=org.json.JSONObject(file.readText()).apply {remove("coordinateSpace")}
        file.writeText(json.toString());val old=file.readBytes()
        val read=store.read(true)
        assertEquals(custom.copy(coordinateSpace=1),read)
        assertArrayEquals(old,file.readBytes())
        val mapped=read.inFullWindow(1000f,500f,ControlRect(60f,0f,1000f,480f))
        store.write(mapped);assertEquals(mapped,store.read(true))
        val portrait=InputProfile.default(false);store.write(portrait);assertEquals(portrait,store.read(false))
    }
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    private val i get()=InstrumentationRegistry.getInstrumentation()
    private fun model()=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
    private fun waitFor(condition: ()->Boolean)=compose.waitUntil(15000,condition)
    private fun <T: View> find(type: Class<T>): T? {
        fun visit(v: View): T? {if(type.isInstance(v)) return type.cast(v);if(v is ViewGroup) for(n in 0 until v.childCount) visit(v.getChildAt(n))?.let {return it};return null}
        var result: T?=null;compose.runOnUiThread {result=visit(compose.activity.window.decorView)};return result
    }
    private fun open() {
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/persistence.gba")
        i.uiAutomation.executeShellCommand("content query --uri $uri").close()
        i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        compose.runOnUiThread {model().open(uri);model().display(DisplaySettings())}
        waitFor {model().playing && !model().loading && find(OriginalSurface::class.java)?.diagnostics()?.draws?.let {it>2}==true}
        compose.waitForIdle()
    }
    private fun menu() {compose.onNodeWithTag("player-menu").performClick();waitFor {model().session.pausedByUser.value && model().session.state.value==SessionState.PAUSED};compose.onNodeWithTag("pause-root").assertExists()}
    private fun shot(name: String) {
        compose.waitForIdle();Thread.sleep(250)
        val out=File(i.targetContext.filesDir,"touch-ui-screenshots").apply {mkdirs()}
        val b=requireNotNull(i.uiAutomation.takeScreenshot());File(out,"$name.png").outputStream().use {b.compress(Bitmap.CompressFormat.PNG,100,it)};b.recycle()
    }

    @Test fun continuousDpadGesturesAndPointerIsolation() {
        val rows=mutableListOf<String>()
        compose.runOnUiThread {
            val down=mutableSetOf<GbaButton>();val router=InputRouter {b,v->if(v) down+=b else down-=b}
            val view=TouchControls(compose.activity,router);view.layout(0,0,1000,1000)
            view.profile=InputProfile(false,listOf(TouchControl("DPAD",.3f,.5f,.32f),TouchControl("A",.8f,.3f,.12f),TouchControl("B",.8f,.5f,.12f),TouchControl("L",.8f,.7f,.12f),TouchControl("R",.8f,.9f,.12f)))
            fun event(action: Int,vararg points: Pair<Float,Float>) {
                val props=points.indices.map {MotionEvent.PointerProperties().apply {id=it;toolType=MotionEvent.TOOL_TYPE_FINGER}}.toTypedArray()
                val coords=points.map {p->MotionEvent.PointerCoords().apply {x=p.first;y=p.second;pressure=1f;size=1f}}.toTypedArray()
                val e=MotionEvent.obtain(1,2,action,points.size,props,coords,0,0,1f,1f,0,0,android.view.InputDevice.SOURCE_TOUCHSCREEN,0);view.onTouchEvent(e);e.recycle()
            }
            fun point(angle: Double)=Pair(300f+150*kotlin.math.cos(angle*Math.PI/180).toFloat(),500f+150*kotlin.math.sin(angle*Math.PI/180).toFloat())
            for(sign in listOf(1,-1)) for(start in listOf(0,90,180,270)) {
                event(MotionEvent.ACTION_DOWN,point(start.toDouble()))
                for(step in 0..90 step 5) {
                    event(MotionEvent.ACTION_MOVE,point((start+step*sign).toDouble()))
                    assertFalse("no direction gap",down.isEmpty());rows+="$start/$sign/$step:$down"
                }
                event(MotionEvent.ACTION_UP,point((start+90*sign).toDouble()));assertTrue(down.isEmpty())
            }
            for(angle in listOf(45.0,135.0,225.0,315.0)) {
                event(MotionEvent.ACTION_DOWN,point(angle));assertEquals(2,down.size);event(MotionEvent.ACTION_UP,point(angle))
            }
            for((button,y) in listOf(GbaButton.A to 300f,GbaButton.B to 500f,GbaButton.L to 700f,GbaButton.R to 900f)) {
                event(MotionEvent.ACTION_DOWN,point(0.0));event(MotionEvent.ACTION_POINTER_DOWN or (1 shl 8),point(0.0),800f to y)
                for(angle in 0..90 step 5) {
                    event(MotionEvent.ACTION_MOVE,point(angle.toDouble()),800f to y)
                    assertTrue(button in down);assertTrue(down.any {it in setOf(GbaButton.UP,GbaButton.DOWN,GbaButton.LEFT,GbaButton.RIGHT)})
                }
                event(MotionEvent.ACTION_POINTER_UP,point(90.0),800f to y);assertEquals(setOf(button),down)
                event(MotionEvent.ACTION_CANCEL,800f to y);assertTrue(down.isEmpty())
            }
            event(MotionEvent.ACTION_DOWN,point(270.0))
            for(angle in 270..630 step 5) {event(MotionEvent.ACTION_MOVE,point(angle.toDouble()));assertFalse(down.isEmpty())}
            event(MotionEvent.ACTION_UP,point(630.0));assertTrue(down.isEmpty())
            event(MotionEvent.ACTION_DOWN,point(0.0))
            event(MotionEvent.ACTION_POINTER_DOWN or (1 shl 8),point(0.0),800f to 300f)
            event(MotionEvent.ACTION_POINTER_DOWN or (2 shl 8),point(0.0),800f to 300f,800f to 500f)
            for(angle in 0..90 step 5) {
                event(MotionEvent.ACTION_MOVE,point(angle.toDouble()),800f to 300f,800f to 500f)
                assertTrue(GbaButton.A in down && GbaButton.B in down);assertTrue(down.size>=3)
            }
            event(MotionEvent.ACTION_CANCEL,point(90.0),800f to 300f,800f to 500f);assertTrue(down.isEmpty())
            event(MotionEvent.ACTION_DOWN,point(0.0));view.acceptingInput=false;assertTrue(down.isEmpty())
            view.acceptingInput=true;event(MotionEvent.ACTION_MOVE,point(90.0));assertTrue(down.isEmpty())
            event(MotionEvent.ACTION_DOWN,point(0.0));view.onWindowFocusChanged(false);assertTrue(down.isEmpty())
            event(MotionEvent.ACTION_DOWN,300f to 500f);assertTrue(down.isEmpty());event(MotionEvent.ACTION_UP,300f to 500f)
            event(MotionEvent.ACTION_DOWN,point(0.0));event(MotionEvent.ACTION_MOVE,300f to 500f);assertEquals(setOf(GbaButton.RIGHT),down)
            event(MotionEvent.ACTION_MOVE,point(180.0));assertEquals(setOf(GbaButton.LEFT),down);event(MotionEvent.ACTION_UP,point(180.0))
        }
        File(i.targetContext.filesDir,"continuous-dpad-traces.txt").writeText(rows.joinToString("\n"))
    }
    @Test fun captureDpadDiagonal() {
        open()
        val view=requireNotNull(find(TouchControls::class.java));val c=view.profile.controls.first {it.key=="DPAD"}
        val r=maxOf(c.size*view.width/2,24*view.resources.displayMetrics.density).coerceAtMost(kotlin.math.min(view.width,view.height)*.45f)
        val x=(c.x*view.width).coerceIn(r,view.width-r)+r*.7f
        val y=(c.y*view.height).coerceIn(r,view.height-r)+r*.7f
        fun event(action: Int) {compose.runOnUiThread {val e=MotionEvent.obtain(1,2,action,x,y,0);view.onTouchEvent(e);e.recycle()}}
        event(MotionEvent.ACTION_DOWN)
        try {shot("dpad-diagonal-pressed")} finally {event(MotionEvent.ACTION_UP)}
    }
    @Test fun landscapeEdgeControlsOnlyReserveCutoutAndRemainDraggable() {
        fun windowShot(name: String) {
            // Capture the actual app window, separate from emulator OS dialog evidence.
            compose.waitForIdle();Thread.sleep(250)
            val b=requireNotNull(i.uiAutomation.takeScreenshot(compose.activity.window))
            val out=File(i.targetContext.filesDir,"touch-ui-screenshots").apply {mkdirs()}
            File(out,"$name.png").outputStream().use {b.compress(Bitmap.CompressFormat.PNG,100,it)};b.recycle()
        }
        val m=model();val old=m.profiles.read(true)
        try {
            m.profiles.write(InputProfile.default(true));open()
            for(orientation in listOf(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE)) {
                compose.runOnUiThread {compose.activity.requestedOrientation=orientation}
                waitFor {find(TouchControls::class.java)?.profile?.landscape==true}
                compose.waitForIdle();Thread.sleep(500)
                val view=requireNotNull(find(TouchControls::class.java))
                compose.runOnUiThread {
                    val root=compose.activity.window.decorView
                    val cutout=androidx.core.view.ViewCompat.getRootWindowInsets(root)?.displayCutout
                    val location=IntArray(2);view.getLocationInWindow(location)
                    assertEquals("Full-window controls origin",0,location[0])
                    assertEquals(root.width,view.width)
                    assertEquals(root.height,view.height)
                    val bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
                    view.draw(Canvas(bitmap))
                    // Actual visible shoulder and cross reach both safe edges, without percentage margins.
                    for(key in InputProfile.keys) {
                        val bounds=view.controlBounds(key)
                        for(hole in cutout?.boundingRects.orEmpty()) assertFalse("$key overlaps cutout",android.graphics.RectF.intersects(bounds,android.graphics.RectF(hole)))
                        assertTrue("$key remains visible",Color.alpha(bitmap.getPixel(bounds.centerX().toInt(),bounds.centerY().toInt()))>0)
                    }
                    bitmap.recycle()
                    val surface=requireNotNull(find(OriginalSurface::class.java))
                    assertEquals(root.width,surface.width);assertEquals(root.height,surface.height)
                    val insets=androidx.core.view.ViewCompat.getRootWindowInsets(root)
                    val trace=org.json.JSONObject().put("window",listOf(root.width,root.height).toString())
                        .put("surface",listOf(surface.width,surface.height).toString())
                        .put("touch",listOf(location[0],location[1],view.width,view.height).toString())
                        .put("profileLogicalBounds","full Player 0..1")
                        .put("displayCutout",cutout?.boundingRects.toString())
                        .put("mandatoryGestures",insets?.getInsets(androidx.core.view.WindowInsetsCompat.Type.mandatorySystemGestures()).toString())
                        .put("systemBarsVisible",insets?.isVisible(androidx.core.view.WindowInsetsCompat.Type.systemBars()))
                    val controls=org.json.JSONObject()
                    for(key in InputProfile.keys) controls.put(key,org.json.JSONObject().put("visual",view.controlBounds(key).toString()).put("hit",view.controlBounds(key,true).toString()))
                    trace.put("controls",controls)
                    File(i.targetContext.filesDir,"hotfix-bounds-$orientation.json").writeText(trace.toString(2))
                }
                windowShot(if(orientation==ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) "landscape-edge-controls-window" else "reverse-landscape-edge-controls-window")
            }
            menu();compose.onNodeWithText("显示与控制",useUnmergedTree=true).performClick();compose.onNodeWithText("调整按键").performClick()
            compose.onNodeWithTag("layout-preview").performTouchInput {
                down(Offset(6f,height*.52f));moveTo(Offset(width*.18f,height*.55f));moveTo(Offset(0f,height*.55f));up()
            }
            compose.onNodeWithText("当前：方向键").assertExists()
            compose.onNodeWithTag("layout-save").performClick();waitFor {m.profiles.read(true).controls.first {it.key=="DPAD"}.x==0f}
            assertEquals(0f,m.profiles.read(true).controls.first {it.key=="DPAD"}.x)
        } finally {m.profiles.write(old)}
    }

    @Test fun immersiveFullscreenAndBarsRestore() {
        open();shot("dpad-normal")
        for(orientation in listOf(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE)) {
            compose.runOnUiThread {compose.activity.requestedOrientation=orientation}
            waitFor {find(TouchControls::class.java)?.profile?.landscape==true}
            waitFor {
                var hidden=false
                compose.runOnUiThread {
                    val root=compose.activity.window.decorView
                    val insets=androidx.core.view.ViewCompat.getRootWindowInsets(root)
                    hidden=insets!=null && !insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.statusBars()) && !insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
                };hidden
            }
            val surface=requireNotNull(find(OriginalSurface::class.java))
            compose.runOnUiThread {
                assertEquals(compose.activity.window.decorView.width,surface.width)
                assertEquals(compose.activity.window.decorView.height,surface.height)
                val bitmap=requireNotNull(surface.bitmap);assertTrue(bitmap.width>0);bitmap.recycle()
            }
            shot(if(orientation==ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) "landscape-fullscreen" else "reverse-landscape-fullscreen")
            val before=compose.onNodeWithTag("gba-screen").getUnclippedBoundsInRoot()
            val controlsBefore=compose.onNodeWithTag("touch-controls").getUnclippedBoundsInRoot()
            compose.runOnUiThread {androidx.core.view.WindowCompat.getInsetsController(compose.activity.window,compose.activity.window.decorView).show(androidx.core.view.WindowInsetsCompat.Type.systemBars())}
            compose.waitForIdle();assertEquals(before,compose.onNodeWithTag("gba-screen").getUnclippedBoundsInRoot())
            assertEquals(controlsBefore,compose.onNodeWithTag("touch-controls").getUnclippedBoundsInRoot())
            compose.runOnUiThread {androidx.core.view.WindowCompat.getInsetsController(compose.activity.window,compose.activity.window.decorView).hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())}
            menu();compose.onNodeWithText("继续",useUnmergedTree=true).performClick()
        }
        compose.runOnUiThread {compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT}
        waitFor {find(TouchControls::class.java)?.profile?.landscape==false}
        waitFor {
            var visible=false;compose.runOnUiThread {visible=androidx.core.view.ViewCompat.getRootWindowInsets(compose.activity.window.decorView)?.isVisible(androidx.core.view.WindowInsetsCompat.Type.statusBars())==true};visible
        }
    }

    @Test fun noticeCardItselfLetsTouchReachUnderlyingControl() {
        var clicks=0
        compose.runOnUiThread {compose.activity.setContent {
            dev.gbalite.player.ui.GbaTheme {
                Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
                    Button(onClick={clicks++}) {Text("under-notice")}
                    dev.gbalite.player.ui.TransientNotice("布局已保存",1,{})
                }
            }
        }}
        compose.onNodeWithTag("transient-notice").assertIsDisplayed()
        compose.onNodeWithText("under-notice").performClick()
        assertEquals("Even the card's own bounds must not intercept the underlying button",1,clicks)
    }
    /** Also run this on the previous candidate, with the same provider and emulator. */
    @Test fun capturePlayerBaseline() {
        open();shot("player-portrait");menu();shot("pause-portrait")
        compose.onNodeWithText("继续",useUnmergedTree=true).performClick()
        compose.runOnUiThread {compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
        waitFor {find(TouchControls::class.java)?.profile?.landscape==true && find(OriginalSurface::class.java)?.diagnostics()?.draws?.let {it>2}==true}
        shot("player-landscape");menu();shot("pause-landscape")
    }
    @Test fun landscapeEditorKeepsToolsOutsideDraggablePreview() {
        val m=model();val old=m.profiles.read(true)
        try {
            m.profiles.write(InputProfile.default(true));open()
            compose.runOnUiThread {compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
            waitFor {find(TouchControls::class.java)?.profile?.landscape==true}
            menu()
            for(title in listOf("继续","保存存档","读取存档","显示与控制","快进 / 倒带","退出游戏")) compose.onNodeWithText(title,useUnmergedTree=true).assertIsDisplayed()
            val panel=compose.onNodeWithTag("pause-root").getUnclippedBoundsInRoot()
            assertTrue((panel.right-panel.left).value<compose.activity.resources.configuration.screenWidthDp*.8f)
            shot("landscape-pause-compact-preview")
            compose.onNodeWithText("显示与控制",useUnmergedTree=true).performClick()
            compose.onNodeWithText("调整按键").performClick()
            compose.onNodeWithTag("landscape-layout-editor").assertIsDisplayed()
            val preview=compose.onNodeWithTag("editor-preview-pane").getUnclippedBoundsInRoot()
            val tools=compose.onNodeWithTag("editor-tools-pane").getUnclippedBoundsInRoot()
            assertTrue(preview.right<=tools.left)
            assertTrue(m.session.pausedByUser.value)
            shot("landscape-editor-preview")
            val d=InputProfile.default(true).controls.first {it.key=="DPAD"}
            compose.onNodeWithTag("layout-preview").performTouchInput {down(Offset(width*d.x,height*d.y));moveTo(Offset(width*(d.x+.05f),height*(d.y+.06f)));up()}
            compose.onNodeWithText("当前：方向键").assertExists()
            compose.onAllNodes(SemanticsMatcher.keyIsDefined(androidx.compose.ui.semantics.SemanticsProperties.ProgressBarRangeInfo)).onLast()
                .performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.SetProgress) {it(.6f)}
            compose.onNodeWithTag("layout-save").performClick()
            waitFor {m.profiles.read(true).opacity==.6f}
            val saved=m.profiles.read(true).controls.first {it.key=="DPAD"}
            assertTrue(saved.x>d.x+.03f);assertTrue(saved.y>d.y+.03f)
            shot("landscape-editor-adjusted-preview")
            compose.onAllNodes(SemanticsMatcher.keyIsDefined(androidx.compose.ui.semantics.SemanticsProperties.ProgressBarRangeInfo)).onLast()
                .performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.SetProgress) {it(.8f)}
            compose.onNodeWithText("取消").performClick()
            waitFor {compose.onAllNodesWithTag("landscape-layout-editor").fetchSemanticsNodes().isEmpty()}
            compose.onNodeWithTag("pause-controls").assertExists()
            assertEquals(.6f,m.profiles.read(true).opacity)
            assertEquals(.6f,find(TouchControls::class.java)!!.profile.opacity)
            assertTrue(m.session.pausedByUser.value)
        } finally {m.profiles.write(old)}
    }
    @Test fun fourPortraitShellsKeepLandscapeBlack() {
        val m=model();val old=m.displaySettings
        try {
            open()
            for(tone in listOf(BackgroundTone.PURPLE,BackgroundTone.WHITE,BackgroundTone.BLACK,BackgroundTone.RED)) {
                compose.runOnUiThread {m.display(m.displaySettings.copy(background=tone));compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT}
                waitFor {find(TouchControls::class.java)?.profile?.landscape==false}
                val file=File(compose.activity.filesDir,"settings/display-v1.settings")
                waitFor {runCatching {DisplaySettings.decode(file.readText()).background==tone}.getOrDefault(false)}
                compose.onNodeWithText("GBA LITE").assertIsDisplayed()
                shot("shell-${tone.name.lowercase()}-portrait")
                compose.runOnUiThread {compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
                waitFor {find(TouchControls::class.java)?.profile?.landscape==true}
                val draws=find(OriginalSurface::class.java)!!.diagnostics().draws
                waitFor {find(OriginalSurface::class.java)!!.diagnostics().draws>draws+2}
                shot("shell-${tone.name.lowercase()}-landscape")
                val image=requireNotNull(i.uiAutomation.takeScreenshot())
                try {
                    val pixel=image.getPixel((image.width*.04f).toInt(),(image.height*.3f).toInt())
                    assertEquals(0,Color.red(pixel));assertEquals(0,Color.green(pixel));assertEquals(0,Color.blue(pixel))
                } finally {image.recycle()}
                assertEquals(tone,m.displaySettings.background)
            }
        } finally {compose.runOnUiThread {m.display(old)}}
    }
    @Test fun captureEditorBaseline() {
        compose.onNodeWithTag("nav-设置").performClick();compose.onNodeWithTag("settings-控制").performClick();compose.onNodeWithText("竖屏布局").performClick()
        compose.onNodeWithText("保存布局").assertIsDisplayed();shot("editor-before-save")
        compose.onNodeWithText("保存布局").performClick();shot("editor-save-feedback")
    }
    @Test fun captureSilverAtReferenceOpacity() {
        val m=model();val old=m.profiles.read(false)
        try {
            m.profiles.write(InputProfile.default(false).copy(opacity=1f))
            open();shot("silver-reference-100-percent")
        } finally {m.profiles.write(old)}
    }
    @Test fun crossCornersSlideDiagonalMultitouchAndEditSelection() {
        compose.runOnUiThread {
            val down=mutableSetOf<GbaButton>();val router=InputRouter {b,v->if(v) down+=b else down-=b}
            val view=TouchControls(compose.activity,router);view.layout(0,0,1000,1000)
            view.profile=InputProfile(false,listOf(TouchControl("DPAD",.3f,.5f,.32f),TouchControl("A",.8f,.5f,.2f)),opacity=.4f)
            fun event(action: Int,vararg points: Pair<Float,Float>) {
                val props=points.indices.map {MotionEvent.PointerProperties().apply {id=it;toolType=MotionEvent.TOOL_TYPE_FINGER}}.toTypedArray()
                val coords=points.map {p->MotionEvent.PointerCoords().apply {x=p.first;y=p.second;pressure=1f;size=1f}}.toTypedArray()
                val e=MotionEvent.obtain(1,2,action,points.size,props,coords,0,0,1f,1f,0,0,android.view.InputDevice.SOURCE_TOUCHSCREEN,0);view.onTouchEvent(e);e.recycle()
            }
            val bitmap=Bitmap.createBitmap(1000,1000,Bitmap.Config.ARGB_8888);view.draw(Canvas(bitmap))
            for(dx in listOf(-.8f,.8f)) for(dy in listOf(-.8f,.8f)) {
                val x=300+160*dx;val y=500+160*dy
                assertEquals("transparent corner",0,Color.alpha(bitmap.getPixel(x.toInt(),y.toInt())))
                event(MotionEvent.ACTION_DOWN,x to y);assertEquals(setOf(if(dx>0) GbaButton.RIGHT else GbaButton.LEFT,if(dy>0) GbaButton.DOWN else GbaButton.UP),down);event(MotionEvent.ACTION_UP,x to y)
            }
            for((point,keys) in listOf((300f to 370f) to setOf(GbaButton.UP),(430f to 500f) to setOf(GbaButton.RIGHT),
                (170f to 500f) to setOf(GbaButton.LEFT),(300f to 630f) to setOf(GbaButton.DOWN),
                (365f to 370f) to setOf(GbaButton.UP,GbaButton.RIGHT))) {
                event(MotionEvent.ACTION_DOWN,point);assertEquals(keys,down);event(MotionEvent.ACTION_UP,point)
            }
            event(MotionEvent.ACTION_DOWN,300f to 370f)
            event(MotionEvent.ACTION_POINTER_DOWN or (1 shl 8),300f to 370f,800f to 500f);assertEquals(setOf(GbaButton.UP,GbaButton.A),down)
            event(MotionEvent.ACTION_POINTER_UP or (1 shl 8),300f to 370f,800f to 500f);assertEquals(setOf(GbaButton.UP),down)
            event(MotionEvent.ACTION_CANCEL,300f to 370f);assertTrue(down.isEmpty())
            event(MotionEvent.ACTION_DOWN,430f to 500f);view.onWindowFocusChanged(false);assertTrue(down.isEmpty())
            view.editing=true;var selected="";view.onSelected={selected=it}
            event(MotionEvent.ACTION_DOWN,428f to 628f);assertEquals("DPAD",selected)
            event(MotionEvent.ACTION_MOVE,500f to 700f);assertEquals(.5f,view.profile.controls.first().x);assertEquals(.7f,view.profile.controls.first().y)
            event(MotionEvent.ACTION_UP,500f to 700f);assertTrue(down.isEmpty());bitmap.recycle()
        }
    }
    @Test fun schemaOneCustomProfilesRemainExactAndDirectionsIndependent() {
        val root=File(i.targetContext.cacheDir,"touch-ui-profile-${System.nanoTime()}").apply {mkdirs()}
        val store=PrivateInputProfiles(root)
        assertEquals(.40f,store.read(true).opacity);assertEquals(.65f,store.read(false).opacity)
        val input=File(root,"input").apply {mkdirs()}
        // Historical schema 1, including the old default positions: never silently migrate saved values.
        val historical="""{"schema":1,"opacity":1.0,"controls":[{"key":"DPAD","x":0.24,"y":0.43,"size":0.32},{"key":"A","x":0.83,"y":0.35,"size":0.2},{"key":"B","x":0.65,"y":0.53,"size":0.2},{"key":"L","x":0.12,"y":0.12,"size":0.17},{"key":"R","x":0.88,"y":0.12,"size":0.17},{"key":"SELECT","x":0.38,"y":0.83,"size":0.16},{"key":"START","x":0.63,"y":0.83,"size":0.16}]}"""
        File(input,"portrait.json").writeText(historical)
        val old=store.read(false);assertEquals(.43f,old.controls.first().y);assertEquals(1f,old.opacity)
        val wide=store.read(true).copy(opacity=.73f,controls=store.read(true).controls.map {if(it.key=="A") it.copy(x=.85f,size=.18f) else it})
        store.write(wide);assertEquals(historical,File(input,"portrait.json").readText())
        assertEquals(old,PrivateInputProfiles(root).read(false));assertEquals(wide,PrivateInputProfiles(root).read(true))
        store.write(InputProfile.default(false));assertEquals(.51f,store.read(false).controls.first().y);assertEquals(wide,store.read(true))
    }
    @Test fun previewScalesMinimumSizesAndWholeButtonOpacityMatchesSlider() {
        compose.runOnUiThread {
            for(landscape in listOf(false,true)) {
                val profile=InputProfile.default(landscape).copy(opacity=.4f)
                val full=TouchControls(compose.activity,InputRouter {_,_->});full.profile=profile;full.layout(0,0,1000,1000)
                val preview=TouchControls(compose.activity,InputRouter {_,_->});preview.profile=profile;preview.previewWidth=1000f;preview.layout(0,0,500,500)
                val a=Bitmap.createBitmap(1000,1000,Bitmap.Config.ARGB_8888);val b=Bitmap.createBitmap(500,500,Bitmap.Config.ARGB_8888)
                full.draw(Canvas(a));preview.draw(Canvas(b))
                for(c in profile.controls) {
                    // Sample the button body away from text, outlines and antialiased boundaries.
                    val bounds=full.controlBounds(c.key)
                    val x=bounds.centerX().toInt();val y=(bounds.centerY()+10).toInt()
                    assertTrue("$landscape ${c.key} preview body opacity",kotlin.math.abs(Color.alpha(a.getPixel(x,y))-Color.alpha(b.getPixel(x/2,y/2)))<=1)
                    assertTrue("whole button is 40%, not accumulated paint layers",kotlin.math.abs(102-Color.alpha(a.getPixel(x,y)))<=1)
                    val body=a.getPixel(x,y)
                    assertTrue("$landscape ${c.key} neutral silver material",kotlin.math.abs(Color.red(body)-Color.blue(body))<=4)
                }
                a.recycle();b.recycle()
            }
        }
    }
    @Test fun saveNoticeDoesNotMoveEditorAndDoesNotBlockDrag() {
        val m=model();val old=m.profiles.read(false)
        try {
            compose.onNodeWithTag("nav-设置").performClick();compose.onNodeWithTag("settings-控制").performClick();compose.onNodeWithText("竖屏布局").performClick()
            compose.onNodeWithTag("layout-preview").assertExists();shot("editor-before-save")
            val before=compose.onNodeWithTag("layout-preview").getUnclippedBoundsInRoot()
            compose.onNodeWithText("保存布局").assertIsDisplayed().performTouchInput {down(center)}
            compose.runOnUiThread {m.dismissSuccessNotice()}
            compose.onNodeWithText("保存布局").performTouchInput {up()}
            waitFor {m.successNotice=="布局已保存"}
            compose.onNodeWithTag("transient-notice").assertIsDisplayed()
            assertEquals(before,compose.onNodeWithTag("layout-preview").getUnclippedBoundsInRoot())
            shot("editor-save-notice")
            compose.onNodeWithTag("layout-preview").performTouchInput {down(Offset(width*.24f,height*.51f));moveTo(Offset(width*.30f,height*.58f));up()}
            compose.onNodeWithText("拖动按键 · 当前 DPAD").assertExists()
            // A repeated success refreshes the timer without stacking notices.
            val event=m.noticeEvent;compose.onNodeWithText("保存布局").assertIsDisplayed().performClick()
            waitFor {m.noticeEvent>event};compose.onAllNodesWithTag("transient-notice").assertCountEquals(1)
            waitFor {m.successNotice==null};compose.onNodeWithTag("transient-notice").assertDoesNotExist()
            shot("editor-after-notice")
        } finally {m.profiles.write(old)}
    }
    @Test fun outsideResumeConsumesGestureSecondaryStaysPausedAndLandscapeCompact() {
        val m=model();val portrait=m.profiles.read(false);val landscape=m.profiles.read(true)
        try {
            // Use defaults only for this test; restore existing custom files afterwards.
            m.profiles.write(InputProfile.default(false));m.profiles.write(InputProfile.default(true));open()
            val controls=requireNotNull(find(TouchControls::class.java));val screen=requireNotNull(find(OriginalSurface::class.java))
            assertEquals(compose.activity.window.decorView.width,screen.width)
            assertEquals(1.5,screen.width.toDouble()/screen.height,.02)
            shot("new-player-portrait")
            menu();val before=m.session.playerMetrics().frames;Thread.sleep(150);assertEquals(before,m.session.playerMetrics().frames)
            compose.onNodeWithTag("pause-outside").performTouchInput {down(Offset(width*.38f,height*.89f))}
            assertTrue(m.session.pausedByUser.value)
            compose.onNodeWithTag("pause-outside").performTouchInput {up()}
            waitFor {!m.session.pausedByUser.value && m.session.state.value==SessionState.RUNNING}
            // No underlying TouchControls gesture is created (even when closing over SELECT).
            val field=TouchControls::class.java.getDeclaredField("pointers").apply {isAccessible=true}
            assertTrue((field.get(controls) as Set<*>).isEmpty())
            menu();compose.onNodeWithText("保存存档",useUnmergedTree=true).performClick()
            compose.onNodeWithTag("pause-outside").performTouchInput {click(Offset(4f,4f))}
            compose.onNodeWithTag("pause-save").assertExists();assertTrue(m.session.pausedByUser.value)
            compose.onNodeWithContentDescription("返回菜单").performClick()
            compose.onNodeWithTag("pause-root").performTouchInput {click(Offset(4f,4f))};assertTrue(m.session.pausedByUser.value)
            compose.onNodeWithText("继续",useUnmergedTree=true).performClick()
            compose.runOnUiThread {compose.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
            waitFor {find(TouchControls::class.java)?.profile?.landscape==true}
            assertEquals(.40f,find(TouchControls::class.java)!!.profile.opacity)
            compose.onNodeWithContentDescription("菜单").assertExists();compose.onNodeWithText("菜单").assertDoesNotExist();shot("new-player-landscape")
            menu();for(title in listOf("继续","保存存档","读取存档","显示与控制","快进 / 倒带","退出游戏")) compose.onNodeWithText(title,useUnmergedTree=true).assertIsDisplayed()
            val panel=compose.onNodeWithTag("pause-root").getUnclippedBoundsInRoot()
            assertTrue((panel.bottom-panel.top).value<compose.activity.resources.configuration.screenHeightDp*.85f);shot("new-pause-landscape")
            compose.onNodeWithTag("pause-outside").performTouchInput {click(Offset(4f,4f))};waitFor {!m.session.pausedByUser.value}
        } finally {m.profiles.write(portrait);m.profiles.write(landscape)}
    }
    @Test fun screenshotSuccessIsOneOverlayOverPauseAndStorageFailureThrows() {
        val m=model();open();menu()
        compose.onNodeWithText("截图",useUnmergedTree=true).performClick()
        waitFor {m.successNotice=="截图已保存"}
        compose.onAllNodesWithTag("transient-notice").assertCountEquals(1)
        compose.onNodeWithTag("transient-notice").assertIsDisplayed();shot("pause-screenshot-notice")
        assertTrue(m.session.pausedByUser.value)
        waitFor {m.successNotice==null}
        // Fail only a disposable profile storage path; never mutate game/save files.
        val blocker=File(i.targetContext.cacheDir,"touch-ui-blocker-${System.nanoTime()}").apply {writeText("not a directory")}
        assertTrue(runCatching {PrivateInputProfiles(blocker).write(InputProfile.default(false))}.isFailure)
    }
    @Test fun landscapeEditorUsesFullscreenRatioAndOpacitySurvivesRecreation() {
        val m=model();val portrait=m.profiles.read(false);val wide=m.profiles.read(true)
        fun editor() {
            compose.onNodeWithTag("nav-设置").performClick();compose.onNodeWithTag("settings-控制").performClick();compose.onNodeWithText("横屏布局").performClick()
        }
        try {
            m.profiles.write(wide.copy(opacity=.73f));editor()
            compose.onNodeWithText("透明度：73%").assertExists()
            val view=requireNotNull(find(TouchControls::class.java));val root=compose.activity.window.decorView
            val cutout=androidx.core.view.ViewCompat.getRootWindowInsets(root)?.displayCutout
            val safeWidth=root.width
            val safeHeight=root.height
            assertEquals(maxOf(safeWidth,safeHeight).toDouble()/minOf(safeWidth,safeHeight),view.width.toDouble()/view.height,.02)
            compose.onNodeWithText("恢复默认").performClick();compose.onNodeWithText("透明度：40%").assertExists()
            compose.onAllNodes(SemanticsMatcher.keyIsDefined(androidx.compose.ui.semantics.SemanticsProperties.ProgressBarRangeInfo)).onLast()
                .performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.SetProgress) {it(.58f)}
            compose.onNodeWithText("透明度：58%").assertExists()
            val adjusted=requireNotNull(find(TouchControls::class.java)).profile.opacity
            // Slider arithmetic may round one ULP. Persist the exact rendered value,
            // while independently checking it represents the requested 58 percent.
            assertEquals(.58,adjusted.toDouble(),.000001)
            compose.onNodeWithText("保存布局").assertIsDisplayed().performTouchInput {down(center)}
            compose.runOnUiThread {m.dismissSuccessNotice()}
            compose.onNodeWithText("保存布局").performTouchInput {up()}
            try {waitFor {m.profiles.read(true).opacity==adjusted}}
            catch(e: Throwable) {
                shot("landscape-editor-failure")
                throw AssertionError("Saved opacity=${m.profiles.read(true).opacity}; notice=${m.successNotice}; error=${m.message}; orientation=${compose.activity.resources.configuration.orientation}; UI=${compose.onRoot(useUnmergedTree=true).printToString()}",e)
            }
            assertEquals(portrait,m.profiles.read(false));shot("landscape-editor")
            compose.activityRule.scenario.recreate();compose.waitForIdle()
            waitFor {compose.onAllNodesWithText("透明度：58%").fetchSemanticsNodes().isNotEmpty()};assertEquals(portrait,m.profiles.read(false))
        } finally {m.profiles.write(portrait);m.profiles.write(wide)}
    }
}
