# V1.0.1 landscape layout audit — 2026-10-14

Baseline: V1.0.0/code14, production certificate ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f. Previous history cleanup remains uncommitted and is outside this hotfix.

Source findings before modification:

1. MainActivity already uses decorFitsSystemWindows=false, immersive transient system bars and ALWAYS/SHORT_EDGES display-cutout mode for landscape Player. No landscape systemBars/safeDrawing padding is applied by MainActivity.
2. Player.kt applies displayCutout UNION mandatorySystemGestures TOP/BOTTOM as windowInsetsPadding to the entire landscape TouchControls AndroidView. Surface already fills the entire Player. The portrait root alone uses safeDrawingPadding.
3. TouchControls.geometry interprets x/y relative to its own width/height; landscape radius uses min(width,height)*1.45. Consequently every control is positioned and sized in the inset-reduced rectangle. Hidden bars do not remove displayCutout/mandatory gesture insets, so that reduced coordinate space survives immersive mode.
4. There is no per-control cutout intersection test. The MENU container also receives aggregate cutout padding. ControlPreview similarly subtracts aggregate cutout insets.
5. PrivateInputProfiles stores schema=1 JSON (not DataStore). Existing files have no coordinate-space marker. Custom landscape profiles therefore need read-time compatibility mapping; untouched defaults can use full-window coordinates directly. Portrait must remain identical.
6. The code13 edge test explicitly expects the entire view to start at safeInsetLeft; that assertion must change to full-window bounds and per-control collision checks.

Plan: remove landscape touch-root padding; retain full-bleed Surface unchanged; map old custom profiles at read/render time using the previous actual inset rectangle and preserve their stored values until edited/saved. Add an optional coordinate-space marker to input-profile JSON only, keeping schema=1 and DataStore untouched. Use actual cutout bounding rectangles and top/bottom mandatory gesture strips for local control collision avoidance. Share resulting geometry between drawing, hit testing and the resolver. No default position or input algorithm change is planned.
