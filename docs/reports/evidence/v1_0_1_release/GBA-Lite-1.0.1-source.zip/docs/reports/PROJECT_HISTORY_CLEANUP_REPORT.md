# Project History Cleanup Audit — 2026-10-11

按用户要求审计并移除项目内无用历史内容。Phase8 COMPLETE/V1 STABLE保持，无业务/测试源码改动、版本提升或APK构建。

- 267个历史文件/目录目标（2,393个文件，约1.03GiB）迁出项目至D:/GPT/archives/gba-emulator/history-2026-10-11，逐文件SHA256核验通过。包括重复阶段报告、旧执行文档、候选截图/APK/原始失败/复测，以及根目录过程日志；有追溯价值的材料不永久抹除。
- 16个可重建Gradle/Kotlin/native/build/Python缓存目录永久删除，共594,203,296 bytes（约567MiB）。执行前检查绝对路径边界与reparse point，未触及.git/third_party/Gradle wrapper。
- 合并当前权威与人工验收内容，移除重复及失效“NOT READY/未开始Phase8”过程段落，保留真实风险；README改为V1开发入口。历史Markdown链接改指项目外归档。
- 保留所有生产/测试源码、合法fixture、vendor/许可/依赖锁、local.properties、Phase7 final consolidation证据、全部Phase8发布证据及正式APK/source zip。
- 正式密钥在项目外未读取或修改；主手机、现有存档和生产数据未操作。v1.0.0原发布tag、外部交付包与源码归档不改写。

[历史归档索引](../HISTORY_ARCHIVE.md)、[结果记录](evidence/project_cleanup_20261011/summary.json)。源码冻结、原发布证据、交付哈希与链接核验结果见evidence/project_cleanup_20261011/verification.json。本轮不为文档/缓存清理重新构建APK或重跑设备验收。Git变更仅为可审阅的删除/文档整理，不自动提交或推送。
