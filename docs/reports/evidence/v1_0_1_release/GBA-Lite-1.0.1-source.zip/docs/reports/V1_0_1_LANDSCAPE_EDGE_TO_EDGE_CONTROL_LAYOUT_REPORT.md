# V1.0.1 横屏布局热修复 — 最终收尾

实现检查点：2026-10-14。正式收尾：2026-10-15。**V1.0.1/code15 STABLE（本地正式签名交付，环境及人工范围见下文）。**

## A. Baseline

正式基线仍为 V1.0.0/code14、tag v1.0.0，Phase7 READY、Phase8 COMPLETE、V1 STABLE。本轮候选源码为 1.0.1/code15。此前项目历史清理的未提交改动独立保留，不回退或混入热修复源码范围。

## B. User-visible Problem

隐藏系统栏后，触控层仍整体扣除 cutout 安全边距及上下 mandatory gestures。未与挖孔相交的按键也受影响，自定义布局编辑预览使用缩小后的画布。

## C. Root Cause

见[修改前源码审计](V1_0_1_LANDSCAPE_EDGE_TO_EDGE_CONTROL_LAYOUT_AUDIT.md)。根因在 Player 的触控 AndroidView 全局 windowInsetsPadding，以及 TouchControls 使用该 View 的尺寸解释 x/y 和按键大小；不是 Renderer viewport，也不是 MainActivity 的横屏 safeDrawing。

## D. Window Insets

横屏触控 View 移除全局 inset padding。使用 WindowInsetsCompat 读取实际 displayCutout.boundingRects，mandatorySystemGestures 只生成上下边缘障碍条；左右导航/系统栏不生成全局占位。MainActivity 沉浸策略不变，Compose MENU 单独做碰撞位移。

## E. Full-screen Coordinate Space

新横屏布局 x/y 按完整 Player 0..1 映射。Surface 与触控层均为完整窗口。2340×1080 模拟器记录中，Surface=2340×1080、TouchControls=(0,0,2340,1080)。布局编辑预览使用完整窗口的纵横比。Renderer 的 3:2 Fit/Integer 等逻辑未修改，比例产生的黑边仍属于正常画面布局。

## F. Per-control Cutout Avoidance

L/R、DPAD、A/B、START/SELECT 的共同 geometry 先定位，再仅对与实际障碍矩形相交的具体控件选择最短可行分离位移。MENU 使用同一个纯几何避让函数。不会把 cutout 的 safeInsetLeft 当成所有左侧按键的 padding。极端尺寸导致没有可行位置时需继续评估，不能承诺任意自定义巨大按键都能避开所有硬件遮挡。

## G. Default Profile

默认按键坐标、大小、透明度未调整。旧默认及未改位置/大小的旧默认派生布局沿用当前默认，以完整画布解释。

## H. Custom Profile Compatibility

input/landscape.json 保持 schema=1，新增可选 coordinateSpace 标记；不是 DataStore schema 变更。缺失标记的旧自定义布局标记为 1，其原始坐标、尺寸和透明度保持在原文件中，读取不自动写回。绘制时将旧安全矩形下的实际中心和尺寸转换为完整窗口坐标，考虑旧边缘 clamp；仅编辑拖动后转换为 2 并由用户保存。新文件标记为 2，避免重复转换。原有尺寸最小值/边界约束继续有效。转换依赖当前设备/方向提供的实际旧 inset，旧格式本身未记录历史设备窗口尺寸。竖屏读取和几何行为保持原状。

## I. D-pad Hitbox Integrity

绘制、hit test、8-way resolver 均调用同一 geometry。15% 命中扩展、12% dead zone、80 ms 中心保持、7° hysteresis、多指 ownership 算法未改。controlBounds 诊断记录该共同几何，不维护另一套测试专用坐标。

## J. Landscape / Reverse Landscape

专用 API36 x86_64 模拟器使用 ARM translation 运行 ARM64 Debug。正横屏与反横屏分别记录窗口、Surface、触控层、各按键 visual/hit bounds、实际 cutout 矩形、mandatory gestures 和系统栏可见状态。此环境不构成 Physical ARM 性能认证。

## K. Gesture / Three-button Navigation

矩阵包含无挖孔/手势、hole/手势、tall 刘海/手势、无挖孔/三键，每组覆盖正反横屏、编辑保存及沉浸恢复。实际 overlay 配置及矩阵结果在 [matrix.json](evidence/v1_0_1_layout/matrix.json)。运行器限定项目专用 AVD，结束后恢复原 overlay。

四组各 2 项设备测试全部通过（共 8 项执行），保存 8 张正反横屏截图。与无挖孔基线比较：hole 正横屏没有按键碰撞，位置不变；反横屏仅 R 避让。tall 正横屏仅 DPAD 避让，反横屏仅 A 避让。三键模式仅 START/SELECT 因上下 mandatory gestures 差异改变垂直位置。见[bounds comparison](evidence/v1_0_1_layout/bounds-comparison.json)。

实际效果：[无挖孔横屏](evidence/v1_0_1_layout/no-cutout/landscape.png)、[挖孔反横屏](evidence/v1_0_1_layout/left-hole/reverse-landscape.png)。红色区域为项目自有测试 ROM 的画面，黑色背景保持不变。

## L. Automated Regression

- JVM full：85 个测试、0 失败，含新增 5 项几何/旧布局兼容测试。
- lint 与 Debug/AndroidTest 构建通过。首轮 NewApi 错误已通过 WindowInsetsCompat 修正，保留初始失败日志。
- 核验新环境安装的是 code15，且安装 APK 与本地 APK 的 SHA256 相同，见 [安装身份](evidence/v1_0_1_installed_identity.json)。
- 首次新环境回归 21 项中 19 项通过：编辑器保存手势一次未触发，以及旧视觉测试按原始 x/y 取样误采边缘描边。改为实际边界取样；环境稳定后两项定向复跑通过。补充存档/恢复/后台/重建及快进/倒带专项，定向共 4 项通过。原始失败保留，不宣称首次全绿。
- 旧 AVD 覆盖安装曾因 Debug 签名不同失败，其结果移入 v1_0_1_unverified_existing_emulator，不作为本轮通过依据；新建独立 AVD，不删除旧应用。旧环境 SystemUI 启动 ANR 已保留，不能归因于应用。
- [JVM 结果](evidence/v1_0_1_jvm_results.json)、[定向设备结果](evidence/v1_0_1_targeted_regression.log)、[新环境首次回归](evidence/v1_0_1_clean_regression.log)。

## M. Upgrade 1.0.0 → 1.0.1

PASS：新建 GBA_Lite_V1_0_1_Release_API36/emulator-5582，在生产 V1.0.0 中通过真实 SAF 导入自主 persistence ROM，生成 Battery、Quick、Slot1、截图、游玩时长、别名和非默认显示设置，并植入明确记录的旧格式自定义布局测试文件。正式覆盖升级至 code15 成功，38 个 files/databases 文件 SHA256 完全一致。冷启动别名/时长保留，Continue 画面一致，Quick/Slot1 读取成功提示另核验；运行后的两份旧布局仍逐字节一致。[升级证据](evidence/v1_0_1_release/install/upgrade.json)、[Continue oracle](evidence/v1_0_1_release/install/continue-oracle.json)。不使用用户手机或真实存档。

## N. Security / Provenance

92 个 V1 基线构建输入 SHA256 未变。变更仅为 app 版本/About 显示、输入 JSON 可选标记、横屏 Player/控件/预览几何；新文件为纯几何和窗口环境/MENU 布局助手。mGBA、Renderer、Audio、FF audio、Save/State、Game ID、Room、DataStore、权限、网络、依赖、Pause Menu/Settings IA 均未修改。正式 APK 的权限/ABI/测试资产/原生库检查仍需随 Release 执行。见[源码身份](evidence/v1_0_1_source_identity.json)。

## O. Signing Identity

PASS：继续使用原 V1 production certificate：ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f。未创建新密钥，凭据未打印/写入交付。[签名验证](evidence/v1_0_1_release/signature.txt)。

## P. Artifact Identity

正式 [GBA-Lite-1.0.1-code15-arm64-release.apk](evidence/v1_0_1_release/GBA-Lite-1.0.1-code15-arm64-release.apk)，SHA256 `39e8d535c4b3ff0ae3cfd8408fba06e9de984ba2a628eda85e810fae12eae4f6`。Release 构建/lint、105 项边界审计、实际 APK 权限为空/ARM64/许可证/native symbols 检查均通过。独立测试应用归档升级测试数据后重置，再安装正式 code15 全新验证：真实 SAF、A/B/L/R 精确色值及松手恢复、单次连续 RIGHT→DOWN、Pause、Quick/Slot 存取、正常退出与冷 Resume、Home/foreground 通过。升级环境中另验证 2×选择及恢复1×。[身份](evidence/v1_0_1_release/identity.json)、[包审计](evidence/v1_0_1_release/package-audit.md)、[全新安装 smoke](evidence/v1_0_1_release/install/fresh-lifecycle-save-smoke.json)。V1.0.0 原包、源码 zip、tag 不覆盖；未自动推送或发布。

自动化过程如实保留：最初按无挖孔坐标定位旧自定义 A 而未命中，依据实际右侧136px cutout 更正；persistence fixture 将 SRAM 与 L/R 按键位 OR 到同一色值，不能作为独立按键阴性 oracle，改用无 SRAM 的 bringup fixture；ACTION_UP 后等待下一实际渲染帧再判定松手；横屏 Home 的继续标题被裁切，冷恢复使用可见最近游戏卡片的正常 resume=true 路径。这些没有引发生产代码修改。无应用 crash buffer 记录。

## Q. Manual Acceptance

2026-10-15 用户明确“认可上轮效果，完成收尾后进入1.1”。视觉确认 PASS；本轮未新增实体手机手感测试记录，不将自动输入当作物理手感反馈。方向键算法未改，正式包与 Debug 矩阵验证上述操作。既有 40+ 分钟长测不重复声明为本轮测试。

## R. Known Risks

正式签名 Release smoke/生产升级已验证，用户视觉已认可；环境仍为 API36 x86_64 ARM translation，非实体 ARM/OEM 扩展认证。旧自定义布局在新的设备窗口尺寸下只能依据该设备的旧 inset 模型兼容解释；极端布局可能受到尺寸/碰撞约束。Physical ARM 性能风险保持此前接受记录，不新增认证。横屏 Home 原有标题裁切另记录，未扩大本 hotfix 范围。

## S. Final Decision

**V1.0.1/code15 STABLE，本地正式签名交付。** 无本轮 hard blocker；视觉通过、自动化和正式升级通过，物理手感/设备覆盖边界透明保留。V1.0.0 历史发布保持不变；未自动提交、打 tag、推送或外部发布。以本轮冻结源码及正式 APK 作为 V1.1 唯一稳定基线，允许进入 Stage 1。
