# GBA Lite 1.0.1 — Release Notes

VersionCode15，沿用 V1.0.0 正式签名。2026-10-15 本地交付。

- 横屏触控画布使用完整窗口，不再整体扣除挖孔安全边距。
- 按键及 MENU 仅在与真实挖孔或必要上下手势区相交时局部避让。
- 旧自定义布局保留原文件，按旧坐标语义兼容解释；编辑器预览匹配完整横屏画布。
- 竖屏、3:2 渲染、音频、方向键算法、正常存档及即时存档保持原逻辑。

同证书 V1.0.0 → V1.0.1 覆盖升级及测试数据保留验证通过。Debug 签名仍不能覆盖生产包；不要卸载含重要数据的旧 Debug。自动化环境不是新增实体 ARM/OEM 认证。见[最终报告](reports/V1_0_1_LANDSCAPE_EDGE_TO_EDGE_CONTROL_LAYOUT_REPORT.md)与[V1 既有风险](V1_KNOWN_LIMITATIONS.md)。
