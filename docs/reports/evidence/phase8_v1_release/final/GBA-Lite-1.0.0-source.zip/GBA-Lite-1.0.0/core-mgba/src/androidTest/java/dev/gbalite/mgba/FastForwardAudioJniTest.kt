package dev.gbalite.mgba

import android.os.ParcelFileDescriptor
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import org.json.JSONObject

class FastForwardAudioJniTest {
    @Test fun acceleratedPcmTransitionsAndLifecycle() {
        val i=InstrumentationRegistry.getInstrumentation()
        val rom=File(i.targetContext.cacheDir,"ff-audio.gba")
        i.context.assets.open("bringup.gba").use {input->rom.outputStream().use {input.copyTo(it)}}
        val log=File(i.targetContext.filesDir,"ff-audio-jni.jsonl").apply {writeText("")}
        val bridge=JniBridge();val handle=bridge.create()
        fun stats()=requireNotNull(bridge.audioStatsForTest(handle))
        fun audible(speed: Int) {
            assertTrue(bridge.control(handle,0,speed))
            val before=stats();val played=bridge.playedForTest(handle);val frames=bridge.framesForTest(handle);val start=System.nanoTime()
            Thread.sleep(700)
            val deadline=System.currentTimeMillis()+5000
            while(bridge.playedForTest(handle)==played && System.currentTimeMillis()<deadline) Thread.sleep(20)
            val after=stats();val consumed=bridge.playedForTest(handle)-played
            assertTrue("audible PCM at ${speed}x",consumed>0)
            assertEquals(speed.toLong(),after[4]);assertTrue(after[3] in 0..(if(speed==1) 4096 else 2048))
            val input=after[0]-before[0];val output=after[1]-before[1]
            assertTrue(input>0 && output>0)
            assertTrue("temporal compression follows requested multiplier",kotlin.math.abs(output-input/speed)<=2)
            val metrics=requireNotNull(bridge.metrics(handle))
            log.appendText(JSONObject().put("speed",speed).put("inputFrames",input).put("outputFrames",output)
                .put("playedNonzeroSamples",consumed).put("droppedFrames",after[2]).put("ringFill",after[3])
                .put("actualMultiplier",(bridge.framesForTest(handle)-frames)*1e9/(System.nanoTime()-start)/59.7275)
                .put("underruns",metrics[5]).toString()+"\n")
        }
        fun silent(action: ()->Unit) {
            action();val played=bridge.playedForTest(handle);Thread.sleep(150)
            assertEquals(played,bridge.playedForTest(handle));assertEquals(0L,stats()[3])
        }
        try {
            ParcelFileDescriptor.open(rom,ParcelFileDescriptor.MODE_READ_ONLY).use {assertEquals(0,bridge.loadRom(handle,it.fd,rom.length()))}
            assertTrue(bridge.start(handle))
            for(speed in listOf(1,2,1,4,1,8,1,2,4,8,4,2,1)) audible(speed)
            audible(4);silent {assertTrue(bridge.pause(handle))}
            assertTrue(bridge.control(handle,0,4));assertTrue(bridge.start(handle));audible(4)
            silent {assertTrue(bridge.pause(handle))}
            val state=requireNotNull(bridge.exportBytes(handle,true))
            assertTrue(bridge.importBytes(handle,state,true));assertTrue(bridge.control(handle,0,4));assertTrue(bridge.start(handle));audible(4)
            silent {assertTrue(bridge.control(handle,1,1))}
            assertTrue(bridge.control(handle,1,0));audible(1)
            audible(4);silent {assertTrue(bridge.control(handle,1,1))};assertTrue(bridge.control(handle,1,0));audible(4);audible(1)
            silent {assertTrue(bridge.pause(handle))}
        } finally {bridge.destroy(handle)}
        assertEquals(0,bridge.activeHandlesForTest())
    }
}
