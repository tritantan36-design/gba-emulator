"""Run a separate continuous A/B campaign and restore the private pre-test snapshot."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import phase7_performance_coverage as coverage
import phase7_restore_physical_backup as restore

def main(label):
    serial='3B15AV01Z0000000'
    folder=coverage.OUT/('physical-ab-'+label)
    if folder.exists(): raise RuntimeError('Preserve previous campaign')
    stop=coverage.checked(serial,'shell','am','force-stop','dev.gbalite.app')
    for key,value in [('screen_brightness_mode','0'),('screen_brightness','1584')]:
        coverage.checked(serial,'shell','settings','put','system',key,value)
        assert coverage.checked(serial,'shell','settings','get','system',key).strip()==value.encode()
    error=None
    try:
        coverage.performance(serial,True,label)
    except Exception as exc:
        error=repr(exc)
        raise
    finally:
        # performance() restores code9 first. Preserve data/settings cleanup separately.
        try:
            restore.main(serial,label)
            if folder.exists(): coverage.write(folder/'restoration.json',{'complete':True,'originalFiles':665,'brightnessMode':'1'})
        except Exception as exc:
            if folder.exists(): coverage.write(folder/'restoration.json',{'complete':False,'error':repr(exc),'recoveryRequired':True})
            raise
        finally:
            if folder.exists(): coverage.write(folder/'campaign-status.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'samplingError':error,'samplingComplete':error is None,'label':label})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label',required=True)
    args=parser.parse_args()
    if not args.label.replace('-','').isalnum() or len(args.label)>64: parser.error('Invalid label')
    main(args.label)
