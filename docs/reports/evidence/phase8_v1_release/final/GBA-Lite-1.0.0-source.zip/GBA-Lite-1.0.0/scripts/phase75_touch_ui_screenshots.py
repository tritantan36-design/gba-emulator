"""Export screenshot evidence only from the explicit project-owned API34 AVD."""
import io
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
ADB = ROOT.parents[1] / "tools/android-sdk/platform-tools/adb.exe"
serial = sys.argv[1]
label = sys.argv[2]
if serial not in ("emulator-5580", "emulator-5574", "emulator-5578") or label not in ("before", "after", "after-final", "api29", "api36", "silver", "silver-final", "batch-delete"):
    raise ValueError("Explicit validation serial and evidence label required")
def device(*args):
    return subprocess.check_output([str(ADB), "-s", serial, *args])
avd = device("emu", "avd", "name").decode().splitlines()[0]
if not avd.startswith(("GBA_Lite_", "GbaLite_QA_")):
    raise ValueError("Not a project-owned AVD")
source_folder = "batch-delete-screenshots" if label == "batch-delete" else "touch-ui-screenshots"
data = device("exec-out", "run-as", "dev.gbalite.app", "tar", "-cf", "-", f"files/{source_folder}")
out = ROOT / "docs/reports/evidence/phase7_5_touch_ui" / label
out.mkdir(parents=True, exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for item in archive:
        if item.isfile() and item.name.endswith(".png") and ("--editor-only" not in sys.argv or Path(item.name).name.startswith("editor-")):
            dest = out / Path(item.name).name
            if dest.exists():
                raise FileExistsError(dest)
            dest.write_bytes(archive.extractfile(item).read())
            print(dest.relative_to(ROOT))
