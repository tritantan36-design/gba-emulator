"""Frozen-candidate evidence and opt-in performance sampling; no production build or ROM download."""
import argparse
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

ROOT = Path('D:/GPT/projects/gba-emulator')
OUT = ROOT / 'docs/reports/evidence/phase7_performance_coverage'
PREVIOUS = ROOT / 'docs/reports/evidence/phase7_closeout'
ADB = 'D:/GPT/tools/android-sdk/platform-tools/adb.exe'
NEW = ROOT / 'docs/reports/evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-ui-refinement-code9-debug.apk'
OLD = ROOT / 'docs/reports/evidence/phase7/manual-handoff/GBA-Lite-0.7.0-manual-debug.apk'
THRESHOLDS = {'realtimeMinimumMultiplier': .95, 'twoTimesMinimumMultiplier': 1.8,
              'suspiciousRelativeLoss': .15, 'maximumBetweenRunRelativeDrift': .10,
              'maximumWithinCellCv': .10, 'eightTimes': 'BEST_EFFORT',
              'formalGate': 'UNCHANGED: fps > 59.7275 * min(speed,4) * .85'}

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2), encoding='utf-8')
def call(serial, *args): return subprocess.run([ADB, '-s', serial, *args], capture_output=True, timeout=2400)
def checked(serial, *args):
    r=call(serial, *args)
    if r.returncode: raise RuntimeError((r.stdout+r.stderr).decode(errors='replace'))
    return r.stdout

def freeze():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT/'baseline.json').exists(): raise RuntimeError('Baseline already exists; preserve it')
    baseline=json.loads((PREVIOUS/'apk-sha256.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT/p)==h for p,h in baseline['productionSources'].items())
    folder=NEW.parent
    assert all(sha(folder/p)==meta['sha256'] for p,meta in baseline['packages'].items())
    baseline['capturedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    baseline['gitStatus']=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
    baseline['devices']=subprocess.run([ADB,'devices','-l'],capture_output=True).stdout.decode(errors='replace')
    write(OUT/'baseline.json',baseline)
    write(OUT/'performance-thresholds.json',THRESHOLDS)
    print('Frozen candidate and predeclared thresholds verified',flush=True)

def environment(serial, path):
    with path.open('wb') as f:
        for command in [('getprop','ro.product.cpu.abi'),('getprop','ro.build.version.sdk'),
                        ('settings','get','global','low_power'),('settings','get','system','screen_brightness'),
                        ('settings','get','system','screen_brightness_mode'),
                        ('dumpsys','battery'),('dumpsys','thermalservice'),('dumpsys','audio'),('wm','size')]:
            r=call(serial,'shell',*command)
            f.write(('COMMAND '+ ' '.join(command)+'\n').encode()+r.stdout+r.stderr)

def performance(serial, physical, run_label=None):
    # A/B downgrades replace the package. Physical runs require an explicitly selected
    # dedicated test handset; never clear/uninstall app data and always restore code9.
    abi=checked(serial,'shell','getprop','ro.product.cpu.abi').decode().strip()
    baseline=json.loads((OUT/'baseline.json').read_text(encoding='utf-8'))
    assert sha(NEW)==baseline['packages'][NEW.name]['sha256']
    assert sha(OLD)=='a0cc12c18cab69a6294cdf95fafd516899cb957a1090f9897463b304aef24051'
    if physical and (serial.startswith('emulator-') or abi!='arm64-v8a'):
        raise RuntimeError('Physical run requires a connected arm64 handset')
    if not physical and not serial.startswith('emulator-'): raise RuntimeError('Physical opt-in required')
    if physical:
        battery=checked(serial,'shell','dumpsys','battery').decode()
        import re
        level=re.search(r'level:\s*(\d+)',battery)
        scale=re.search(r'scale:\s*(\d+)',battery)
        if not level or not scale or int(level[1])/int(scale[1])<=.50:
            raise RuntimeError('Physical performance run requires battery above 50%')
        if checked(serial,'shell','settings','get','global','low_power').strip()!=b'0':
            raise RuntimeError('Disable battery saver before performance comparison')
    testApk=ROOT/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'
    checked(serial,'install','-r',str(testApk))
    if run_label and (not run_label.replace('-', '').isalnum() or len(run_label)>64):
        raise RuntimeError('Run label must be a short alphanumeric/hyphen checkpoint name')
    folder=OUT/(('physical-ab' if physical else 'emulator-ab')+('-'+run_label if run_label else ''))
    folder.mkdir(exist_ok=False)
    assert json.loads((OUT/'performance-thresholds.json').read_text())==THRESHOLDS
    write(folder/'protocol.json',{'serial':serial,'abi':abi,'thresholds':THRESHOLDS,'orientation':'LANDSCAPE',
         'background':'BLACK','scale':'FIT','audio':'same production default; PCM enabled',
         'sequence':['OLD','CODE9','CODE9','OLD'],'warmupMs':2000,'sampleMs':10000,
         'cellRepeats':3,'recoverySeconds':30,'oldSha256':sha(OLD),'newSha256':sha(NEW)})
    try:
        for round_,apk in enumerate([OLD,NEW,NEW,OLD],1):
            label=f'{round_}-'+('old' if apk==OLD else 'code9')
            print(label,flush=True)
            checked(serial,'install','-r','-d',str(apk))
            query=checked(serial,'shell','content','query','--uri','content://dev.gbalite.app.test.rom/phase7-stress-a.gba')
            if b'Row: 0' not in query: raise RuntimeError('Probe provider query failed')
            cache=checked(serial,'exec-out','run-as','dev.gbalite.app.test','cat','cache/phase3-test-phase7-stress-a.gba')
            expected=json.loads((ROOT/'test-rom/manifests/phase7-stress.json').read_text(encoding='utf-8'))['phase7-stress-a.gba']['sha256']
            actual=hashlib.sha256(cache).hexdigest()
            write(folder/f'{label}-rom.json',{'expectedSha256':expected,'actualSha256':actual,'bytes':len(cache)})
            if actual!=expected: raise RuntimeError('Cached probe ROM differs from pinned fixture; do not overwrite or lower import checks')
            environment(serial,folder/f'{label}-environment.log')
            for repeat in range(3):
                stem=f'{label}-{repeat+1}'
                r=call(serial,'shell','am','instrument','-w','-r','-e','phase7SampleMs','10000',
                       '-e','phase7WarmupMs','2000','-e','class','dev.gbalite.app.Phase7PerformanceAbTest#measureAllModes',
                       'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner')
                (folder/f'{stem}.log').write_bytes(r.stdout+r.stderr)
                data=checked(serial,'exec-out','run-as','dev.gbalite.app','cat','files/phase7-closeout-performance.jsonl')
                (folder/f'{stem}.jsonl').write_bytes(data)
                if b'OK (1 test)' not in r.stdout or b'FAILURES!!!' in r.stdout: raise RuntimeError('Sampler failed')
                environment(serial,folder/f'{stem}-after.log')
                print(stem+' completed and exported',flush=True)
            if round_<4: time.sleep(30)
    finally:
        r=call(serial,'install','-r','-d',str(NEW))
        (folder/'restore-code9.log').write_bytes(r.stdout+r.stderr)
        if r.returncode: raise RuntimeError('Code9 restore failed; inspect retained log')
    analyze(folder)

def analyze(folder):
    rows=[]
    for p in sorted(folder.glob('[1-4]-*.jsonl')):
        for line in p.read_text().splitlines():
            row=json.loads(line); row['round']=int(p.name[0]); row['candidate']='OLD' if '-old-' in p.name else 'CODE9'
            rows.append(row)
    summaries=[]
    for mode in ['ORIGINAL','SHARP','GBA_COLOR','LCD']:
        for speed in [1,2,4,8]:
            cell=[r for r in rows if r['mode']==mode and r['speed']==speed]
            groups={n:[r['fps'] for r in cell if r['round']==n] for n in range(1,5)}
            if any(len(v)!=3 for v in groups.values()): raise RuntimeError('Incomplete balanced repeated matrix')
            means={n:statistics.mean(v) for n,v in groups.items()}
            old=statistics.mean(groups[1]+groups[4]); new=statistics.mean(groups[2]+groups[3])
            drift=max(abs(means[1]-means[4])/old,abs(means[2]-means[3])/new)
            cv=max(statistics.stdev(v)/statistics.mean(v) for v in groups.values())
            temporalCv=max(statistics.stdev(r['temporalFps'])/statistics.mean(r['temporalFps']) for r in cell)
            summaries.append({'mode':mode,'speed':speed,'oldFps':old,'newFps':new,
                'relativeDifference':new/old-1,'withinCellCv':cv,'betweenRunDrift':drift,
                'withinSampleTemporalCv':temporalCv,
                'stable':drift<=.10 and cv<=.10 and temporalCv<=.10,'oldMeets4x':old>=59.7275*4*.95})
    # Environment controls must be reviewed from the before/after dumps: absence of
    # such review never emits an automatic product PASS or confirmed regression.
    write(folder/'analysis.json',{'cells':summaries,'classification':'BLOCKED_ENVIRONMENT',
        'reason':'Numeric analysis complete; environment/viewport/audio and thermal controls require review before product classification'})
    with (folder/'metrics.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['candidate','round','mode','speed','fps','actualMultiplier','displayFps','elapsedMs','underrunsDelta'])
        writer.writeheader();writer.writerows({k:r[k] for k in writer.fieldnames} for r in rows)

def games(serial):
    if not serial.startswith('emulator-'): raise RuntimeError('Use dedicated project emulator for gameplay coverage')
    avd=checked(serial,'emu','avd','name').decode().splitlines()[0]
    if not avd.startswith(('GBA_Lite_','GbaLite_QA_')): raise RuntimeError('Project-owned AVD required')
    for game,filename in [('blob-v1.1','blob-goes-3d-v1.1.gba'),('hyperspace-v0.25.0','hyperspace-roll-agb-v0.25.0.gba')]:
        folder=OUT/(game+'-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));folder.mkdir(exist_ok=False)
        rom=ROOT/'docs/reports/evidence/phase7/gameplay-closeout'/filename
        manifest=json.loads((ROOT/'test-rom/manifests/phase7-gameplay-local.json').read_text(encoding='utf-8'))
        reviewed=next(g for g in manifest['games'] if g['id']==game)
        assert sha(rom)==reviewed['sha256'] and rom.stat().st_size==reviewed['bytes']
        write(folder/'rom.json',{'sha256':sha(rom),'source':'existing locally approved phase7 corpus'})
        checked(serial,'push',str(rom),'/data/local/tmp/'+filename)
        for package in ['dev.gbalite.app','dev.gbalite.app.test']:
            checked(serial,'shell','run-as',package,'mkdir','-p','files/phase7-gameplay')
            checked(serial,'shell','run-as',package,'cp','/data/local/tmp/'+filename,'files/phase7-gameplay/'+filename)
        before=set(checked(serial,'shell','run-as','dev.gbalite.app','ls','files').decode().splitlines())
        r=call(serial,'shell','am','instrument','-w','-r','-e','phase7Gameplay',game,'-e','phase7GameplaySeconds','600',
               '-e','class','dev.gbalite.app.Phase7GameplayTest#stagedHomebrewGameplay',
               'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner')
        (folder/'instrumentation.log').write_bytes(r.stdout+r.stderr)
        print(r.stdout.decode(errors='replace')[-2000:],flush=True)
        # Export all run folders, including failures; no fake result on missing output.
        names=checked(serial,'shell','run-as','dev.gbalite.app','ls','files').decode().splitlines()
        for name in names:
            if name.startswith('phase7-gameplay-result-') and name not in before:
                for leaf in ['result.json','events.jsonl']:
                    data=checked(serial,'exec-out','run-as','dev.gbalite.app','cat','files/'+name+'/'+leaf)
                    (folder/(name+'-'+leaf)).write_bytes(data)
        log=checked(serial,'logcat','-d','-v','threadtime');(folder/'logcat.log').write_bytes(log)
        if b'OK (1 test)' not in r.stdout or b'FAILURES!!!' in r.stdout: raise RuntimeError('Gameplay failed; preserve evidence')

def regression(serial):
    if not serial.startswith('emulator-'): raise RuntimeError('Project emulator required')
    if any((OUT/(name+'.log')).exists() for name in ['activity-zip','performance-harness','jni']):
        raise RuntimeError('Preserve prior regression evidence; choose a new output directory before repeating')
    commands=[('activity-zip', ['-e','class','dev.gbalite.app.ActivityTest,dev.gbalite.app.LibraryExperienceTest#zipUiDuplicateAndInvalidZipLeaveLibraryIntact',
                  'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner'],4),
              ('performance-harness', ['-e','class','dev.gbalite.app.Phase7PerformanceAbTest#measureAllModes',
                  'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner'],1)]
    for name,arguments,expected in commands:
        r=call(serial,'shell','am','instrument','-w','-r',*arguments)
        (OUT/(name+'.log')).write_bytes(r.stdout+r.stderr)
        print(name,r.stdout.decode(errors='replace')[-1500:],flush=True)
        if f'OK ({expected} test'.encode() not in r.stdout or b'FAILURES!!!' in r.stdout: raise RuntimeError(name+' failed')
        if name=='performance-harness':
            (OUT/'performance-harness.jsonl').write_bytes(checked(serial,'exec-out','run-as','dev.gbalite.app','cat','files/phase7-closeout-performance.jsonl'))
    checked(serial,'install','-r',str(ROOT/'core-mgba/build/outputs/apk/androidTest/debug/core-mgba-debug-androidTest.apk'))
    r=call(serial,'shell','am','instrument','-w','-r','dev.gbalite.coremgba.test/dev.gbalite.mgba.ForegroundJniRunner')
    (OUT/'jni.log').write_bytes(r.stdout+r.stderr)
    print(r.stdout.decode(errors='replace')[-1500:],flush=True)
    if b'OK (17 tests)' not in r.stdout or b'FAILURES!!!' in r.stdout: raise RuntimeError('JNI failed')

def verify():
    b=json.loads((OUT/'baseline.json').read_text(encoding='utf-8'))
    sources={p:sha(ROOT/p)==h for p,h in b['productionSources'].items()}
    packages={p:sha(NEW.parent/p)==v['sha256'] for p,v in b['packages'].items()}
    locks=json.loads((PREVIOUS/'format-and-dependency-locks.json').read_text(encoding='utf-8'))
    formats={p:sha(ROOT/p)==h for p,h in locks.items()}
    assert all(sources.values()) and all(packages.values()) and all(formats.values())
    write(OUT/'source-integrity.json',{'productionUnchanged':True,'productionSources':sources,
        'packages':packages,'formatAndDependencyLocks':formats,'permissions':[],
        'permissionsEvidence':'apk-provenance-audit.md (merged manifests checked independently)'})
    reuse=['api26-cycle-bringup-retry/api26-smoke.log','api26-audio/api26-smoke.log',
           'api29-behavior/api29-smoke.log','api29-audio/api29-smoke.log',
           'api29-monitor-summary.json','phase2-state-search.json','format-and-dependency-locks.json',
           'performance-metrics.csv','formal-performance-metrics.txt']
    manifest=[]
    for name in reuse:
        path=PREVIOUS/name
        assert path.is_file()
        text=path.read_text(encoding='utf-8')
        if name.endswith('smoke.log'): assert 'OK (' in text and 'FAILURES!!!' not in text
        manifest.append({'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
    write(OUT/'reused-evidence.json',manifest)
    import xml.etree.ElementTree as ET
    suites=[]
    for path in ROOT.glob('*/build/test-results/**/TEST-*.xml'):
        if 'androidTest' in str(path): continue
        suite=ET.parse(path).getroot()
        suites.append({'path':path.relative_to(ROOT).as_posix(),'tests':int(suite.get('tests',0)),
            'failures':int(suite.get('failures',0)),'errors':int(suite.get('errors',0)),'skipped':int(suite.get('skipped',0))})
    assert suites and all(not s['failures'] and not s['errors'] for s in suites)
    write(OUT/'jvm-results.json',{'executions':sum(s['tests'] for s in suites),'suites':suites})
    print('Candidate integrity, reused evidence and JVM results verified',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['freeze','games','performance','regression','verify'])
    p.add_argument('--serial')
    p.add_argument('--run-label',help='New evidence directory suffix; prior runs are never overwritten')
    p.add_argument('--dedicated-arm-test-device',action='store_true',help='Opt in to package OLD downgrade on a dedicated test phone')
    a=p.parse_args()
    if a.action=='freeze': freeze()
    elif a.action=='verify': verify()
    elif not a.serial: p.error('Explicit serial required')
    elif a.action=='games': games(a.serial)
    elif a.action=='regression': regression(a.serial)
    else: performance(a.serial,a.dedicated_arm_test_device,a.run_label)
