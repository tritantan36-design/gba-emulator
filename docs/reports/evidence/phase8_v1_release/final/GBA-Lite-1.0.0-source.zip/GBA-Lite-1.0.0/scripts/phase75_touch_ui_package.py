"""Package local Phase 7.5 touch-UI evidence; never uploads APKs or screenshots."""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/reports/evidence/phase7_5_touch_ui"
HANDOFF = OUT / "manual-handoff"
HANDOFF.mkdir(parents=True, exist_ok=True)
silver = "--silver" in sys.argv
package_label = "silver-controls" if silver else "touch-ui"
after_folder = "silver-final" if silver else "after-final"
metadata_name = "silver-candidate-and-evidence.json" if silver else "candidate-and-evidence.json"
comparison_name = "silver-comparison.html" if silver else "comparison.html"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

packages = {}
for name, source in {
    f"GBA-Lite-0.7.5-{package_label}-debug.apk": ROOT / "app/build/outputs/apk/debug/app-debug.apk",
    f"GBA-Lite-0.7.5-{package_label}-release-unsigned.apk": ROOT / "app/build/outputs/apk/release/app-release-unsigned.apk",
}.items():
    dest = HANDOFF / name
    if dest.exists() and sha(dest) != sha(source):
        raise FileExistsError(f"Preserve previous candidate; choose a new name: {dest}")
    shutil.copyfile(source, dest)
    packages[name] = {"sha256": sha(dest), "bytes": dest.stat().st_size}
(HANDOFF / ("SILVER-SHA256SUMS.txt" if silver else "SHA256SUMS.txt")).write_text("".join(f"{v['sha256']}  {n}\n" for n,v in packages.items()), encoding="utf-8")

baseline = json.loads((ROOT / "docs/reports/evidence/phase7_5/protected-source-before.json").read_text())
changed = [name for name, value in baseline.items() if not (ROOT/name).is_file() or sha(ROOT/name) != value]
assert changed == ["input/src/main/kotlin/dev/gbalite/input/InputProfile.kt"], changed
units = []
for module in ROOT.iterdir():
    for variant in ("test", "testDebugUnitTest"):
        for path in (module / "build/test-results" / variant).glob("TEST-*.xml"):
            e = ET.parse(path).getroot()
            units.append({"module": module.name, "suite": e.get("name"),
                          **{k: int(e.get(k, "0")) for k in ("tests", "failures", "errors", "skipped")}})
lint = {}
for module in ("app", "feature-player"):
    issues = ET.parse(ROOT/module/"build/reports/lint-results-debug.xml").getroot().findall("issue")
    lint[module] = {severity: sum(e.get("severity")==severity for e in issues) for severity in ("Error", "Warning")}
screens = {}
for folder in ("before", "after", "after-final", "api29", "api36", "silver", "silver-final"):
    for path in (OUT/folder).glob("*.png"):
        width,height = struct.unpack(">II",path.read_bytes()[16:24])
        screens[str(path.relative_to(OUT)).replace("\\","/")] = {"sha256": sha(path), "width": width, "height": height,
            "evidenceRole": "retained-failure" if "failure" in path.name else "screenshot"}
product_file = "feature-player" if silver else "feature-player/src/main/java/dev/gbalite/player/ui/TransientNotice.kt"
product_commit=subprocess.check_output(["git","log","-1","--format=%H","--",product_file],cwd=ROOT).decode().strip()
metadata = {"productCommit": product_commit, "versionName": "0.7.5", "versionCode": 8,
            "packages": packages, "protectedBaselineFiles": len(baseline), "authorizedChanges": changed,
            "units": units, "lint": lint, "screenshots": screens}
(OUT / metadata_name).write_text(json.dumps(metadata, ensure_ascii=False, indent=2),encoding="utf-8")

sections = []
for title, before, after in (
    ("竖屏游戏：整行画面 / 十字键（同一合法测试画面）", "player-portrait.png", "new-player-portrait.png"),
    ("横屏游戏：默认半透明 / 图标菜单", "player-landscape.png", "new-player-landscape.png"),
    ("横屏暂停：紧凑六项 / 底部操作可见", "pause-landscape.png", "new-pause-landscape.png"),
    ("编辑器保存：页面内大提示 → 独立轻提示", "editor-save-feedback.png", "editor-save-notice.png"),
):
    sections.append(f'<section><h2>{title}</h2><div class="pair"><figure><figcaption>修改前 · API34 模拟器</figcaption><img src="before/{before}"></figure><figure><figcaption>修改后 · API34 模拟器</figcaption><img src="{after_folder}/{after}"></figure></div></section>')
(OUT / comparison_name).write_text('''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GBA Lite 触控 UI 前后对比</title>
<style>body{margin:0 auto;padding:24px;max-width:1400px;background:#161920;color:#efedf4;font:16px/1.6 system-ui}h1{font-size:28px}h2{font-size:20px}section{margin:32px 0}.pair{display:grid;grid-template-columns:1fr 1fr;gap:20px}figure{margin:0;background:#252934;border-radius:16px;padding:12px}figcaption{margin-bottom:12px;color:#cbb7ef}img{display:block;max-width:100%;max-height:85vh;margin:auto}a{color:#cbb7ef}@media(max-width:700px){.pair{grid-template-columns:1fr}}</style>
<h1>GBA Lite · Phase 7.5 触控与游戏界面补丁</h1><p>真实同设备截图，原始 PNG 未改动。红色为应用内合法 persistence 测试画面，不能代表商业游戏兼容性或实机体验。已有保存布局继续保留；新默认位置与 40% 横屏透明度只适用于未保存配置和显式恢复默认。</p>'''+"".join(sections)+
'<p>实机握持、声音、刘海/手势体验仍待用户验收。Phase7/7.5 NOT_READY。</p></html>',encoding="utf-8")
print(json.dumps({"packages": packages, "unitTests": sum(e["tests"] for e in units), "unitFailures": sum(e["failures"]+e["errors"] for e in units),
                  "lint": lint, "protectedFiles": len(baseline), "authorizedChanges": changed, "screenshots": len(screens)},ensure_ascii=False,indent=2))
