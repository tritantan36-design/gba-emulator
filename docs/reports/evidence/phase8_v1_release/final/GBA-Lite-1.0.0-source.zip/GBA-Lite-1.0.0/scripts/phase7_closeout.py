"""Local evidence capture; no ROM downloads, production mutations or gate changes."""
import argparse, hashlib, json, subprocess, datetime, os, sys
from pathlib import Path

ROOT = Path('D:/GPT/projects/gba-emulator')
OUT = ROOT / 'docs/reports/evidence/phase7_closeout'
ADB = 'D:/GPT/tools/android-sdk/platform-tools/adb.exe'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def adb(*args): return subprocess.run([ADB, '-s', 'emulator-5574', *args], capture_output=True)
def freeze():
    OUT.mkdir(parents=True, exist_ok=True)
    meta=json.loads((ROOT/'docs/reports/evidence/phase7_5_touch_ui/ui-refinement-delivery-metadata.json').read_text(encoding='utf-8-sig'))
    files={p: digest(ROOT/p) for p in meta['changedSources'] if '/src/main/' in p or p.endswith('build.gradle.kts') or '/src/main/kotlin/' in p}
    packages={p:{'sha256':digest(ROOT/'docs/reports/evidence/phase7_5_touch_ui/manual-handoff'/p),'bytes':(ROOT/'docs/reports/evidence/phase7_5_touch_ui/manual-handoff'/p).stat().st_size} for p in meta['packages']}
    assert packages==meta['packages']
    assert all(meta['changedSources'][p]==h for p,h in files.items())
    result={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':'0.7.5','versionCode':9,'packages':packages,'certificateSha256':meta['signatureSha256'],'productionSources':files,'productionMatchesDeliveredCandidate':True,'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'gitStatus':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'mGBA':'26b7884bc25a5933960f3cdcd98bac1ae14d42e2','Oboe':'b15f5e39c01a7ada306d959e5129620b145fb8b4','RoomSchema':3,'DataStore':'1.1.7','rawStateVersion':7,'stateMetadataVersion':1}
    path=OUT/'apk-sha256.json'
    if path.exists(): raise RuntimeError('Refusing evidence overwrite')
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(path)
def measure():
    if list(OUT.glob('performance-*.jsonl')): raise RuntimeError('Preserve prior A/B evidence; select a new output directory before repeating')
    if adb('emu','avd','name').stdout.decode(errors='replace').splitlines()[0].strip()!='GBA_Lite_API36': raise RuntimeError('Wrong AVD')
    old=ROOT/'docs/reports/evidence/phase7/manual-handoff/GBA-Lite-0.7.0-manual-debug.apk'
    new=ROOT/'docs/reports/evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-ui-refinement-code9-debug.apk'
    for n,apk in enumerate([old,new,new,old]):
        label=f'{n+1}-'+('code9' if apk==new else 'old')
        print(label,flush=True)
        installed=adb('install','-r','-d',str(apk))
        (OUT/f'performance-{label}-install.log').write_bytes(installed.stdout+installed.stderr)
        if installed.returncode: raise RuntimeError(installed.stdout+installed.stderr)
        env=adb('shell','sh','-c','"getprop ro.build.version.sdk; getprop ro.product.cpu.abi; settings get system screen_brightness; dumpsys battery; dumpsys thermalservice"')
        (OUT/f'performance-{label}-environment.log').write_bytes(env.stdout+env.stderr)
        run=adb('shell','am','instrument','-w','-r','-e','class','dev.gbalite.app.Phase7PerformanceAbTest#measureAllModes','dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner')
        (OUT/f'performance-{label}.log').write_bytes(run.stdout+run.stderr)
        data=adb('exec-out','run-as','dev.gbalite.app','cat','files/phase7-closeout-performance.jsonl')
        (OUT/f'performance-{label}.jsonl').write_bytes(data.stdout)
        print(run.stdout.decode(errors='replace')[-1500:],flush=True)
        if run.returncode or b'OK (1 test)' not in run.stdout: break
    restored=adb('install','-r','-d',str(new))
    (OUT/'performance-restore-code9.log').write_bytes(restored.stdout+restored.stderr)
    assert restored.returncode==0

def regression():
    if (OUT/'api36-final-regression.log').exists(): raise RuntimeError('Preserve prior regression log')
    classes=','.join(['dev.gbalite.app.ActivityTest','dev.gbalite.app.PersistenceActivityTest#batteryBackgroundRecreateManualSlotsQuickAndResume','dev.gbalite.app.PersistenceActivityTest#renamedRomUsesSameGameAndFreshActivityResumes','dev.gbalite.app.TouchUiPolishTest#outsideResumeConsumesGestureSecondaryStaysPausedAndLandscapeCompact','dev.gbalite.app.TouchUiPolishTest#crossCornersSlideDiagonalMultitouchAndEditSelection','dev.gbalite.app.PeripheralExperienceTest','dev.gbalite.app.RendererExperienceTest'])
    run=adb('shell','am','instrument','-w','-r','-e','class',classes,'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner')
    (OUT/'api36-final-regression.log').write_bytes(run.stdout+run.stderr)
    print(run.stdout.decode(errors='replace')[-3000:],flush=True)
    metrics=adb('exec-out','run-as','dev.gbalite.app','cat','files/phase4-renderer-metrics.txt')
    (OUT/'formal-performance-metrics.txt').write_bytes(metrics.stdout+metrics.stderr)
    install=adb('install','-r',str(ROOT/'core-mgba/build/outputs/apk/androidTest/debug/core-mgba-debug-androidTest.apk'))
    (OUT/'jni-install.log').write_bytes(install.stdout+install.stderr)
    if install.returncode: raise RuntimeError('JNI test APK install failed')
    run=adb('shell','am','instrument','-w','-r','dev.gbalite.coremgba.test/dev.gbalite.mgba.ForegroundJniRunner')
    (OUT/'jni-final-regression.log').write_bytes(run.stdout+run.stderr)
    print(run.stdout.decode(errors='replace')[-2500:],flush=True)

def compatibility(api, cycle_only=False, audio_only=False):
    api_out=OUT/(f'api{api}-audio' if audio_only else f'api{api}-cycle-bringup-retry' if cycle_only else f'api{api}-behavior');api_out.mkdir(parents=True,exist_ok=True)
    serial='emulator-5580' if api==26 else 'emulator-5582'
    avd='GBA_Lite_API26_Compat' if api==26 else 'GbaLite_QA_API29'
    env=os.environ.copy();env['ANDROID_AVD_HOME']='D:/GPT/tools/android-avd';env['ANDROID_USER_HOME']='D:/GPT/tools/android-user'
    helper=ROOT/'scripts/android_emulator.py'
    for action,extra in [('start',['--avd',avd,'--graphics','software','--output',str(api_out/f'api{api}-boot.log')]),('wait',['--timeout','120'])]:
        subprocess.run([sys.executable,str(helper),action,'--serial',serial,*extra],env=env,check=True)
    def call(*args):return subprocess.run([ADB,'-s',serial,*args],capture_output=True)
    completed=False
    try:
        identity=call('shell','sh','-c','"getprop ro.build.version.sdk; getprop ro.product.cpu.abi; getprop ro.product.model"')
        (api_out/f'api{api}-identity.log').write_bytes(identity.stdout+identity.stderr)
        for label,path in [('app','app/build/outputs/apk/compat/app-compat.apk'),('tests','app/build/outputs/apk/androidTest/compat/app-compat-androidTest.apk')]:
            result=call('install','-r','-t',str(ROOT/path));(api_out/f'api{api}-{label}-install.log').write_bytes(result.stdout+result.stderr)
            if result.returncode:raise RuntimeError(result.stdout+result.stderr)
        cache={}
        for name in ['phase7-stress-a.gba','bringup.gba']:
            probe=call('exec-out','run-as','dev.gbalite.app.test','cat','cache/phase3-test-'+name)
            expected=(ROOT/'app/src/androidTest/assets'/name).read_bytes()+(b'' if name.startswith('phase7-') else b'PHASE3_TEST_ONLY')
            cache[name]={'readExitCode':probe.returncode,'expectedSha256':hashlib.sha256(expected).hexdigest(),'actualSha256':hashlib.sha256(probe.stdout).hexdigest(),'bytes':len(probe.stdout),'header3':probe.stdout[3] if len(probe.stdout)>3 else None,'headerB2':probe.stdout[0xb2] if len(probe.stdout)>0xb2 else None}
        (api_out/f'api{api}-fixture-cache.json').write_text(json.dumps(cache,indent=2),encoding='utf-8')
        classes=','.join(['dev.gbalite.app.ActivityTest','dev.gbalite.app.PersistenceActivityTest#batteryBackgroundRecreateManualSlotsQuickAndResume','dev.gbalite.app.TouchUiPolishTest#crossCornersSlideDiagonalMultitouchAndEditSelection','dev.gbalite.app.Phase7ApiCloseoutTest'])
        if cycle_only: classes='dev.gbalite.app.Phase7ApiCloseoutTest#safOrientationHomeRecoveryCycles'
        if audio_only: classes='dev.gbalite.app.Phase7ApiCloseoutTest#pcmPlaybackPausesOnHomeAndResumes'
        run=call('shell','am','instrument','-w','-r','-e','phase7ApiCycles','20' if api==29 else '1','-e','class',classes,'dev.gbalite.app.test/androidx.test.runner.AndroidJUnitRunner')
        (api_out/f'api{api}-smoke.log').write_bytes(run.stdout+run.stderr)
        completed=run.returncode==0 and b'OK (' in run.stdout and b'FAILURES!!!' not in run.stdout
        (api_out/f'api{api}-execution-status.json').write_text(json.dumps({'instrumentationCompletedSuccessfully':completed,'adbReturnCode':run.returncode,'expectedTests':1 if cycle_only or audio_only else 7,'requestedCycles':None if audio_only else 20 if api==29 else 1},indent=2),encoding='utf-8')
        print(run.stdout.decode(errors='replace')[-4000:],flush=True)
        data=call('exec-out','run-as','dev.gbalite.app','cat','files/phase7-api-closeout.jsonl');(api_out/f'api{api}-saf-monitor.jsonl').write_bytes(data.stdout+data.stderr)
        audio=call('exec-out','run-as','dev.gbalite.app','cat','files/phase7-api-audio.json');(api_out/f'api{api}-audio.json').write_bytes(audio.stdout+audio.stderr)
        nav=call('exec-out','run-as','dev.gbalite.app','cat','files/phase7-api-navigation-error.txt');(api_out/f'api{api}-navigation-diagnostic.txt').write_bytes(nav.stdout+nav.stderr)
        log=call('logcat','-d','-v','threadtime');(api_out/f'api{api}-logcat.log').write_bytes(log.stdout+log.stderr)
        relaunch=call('shell','am','force-stop','dev.gbalite.app');relaunch=call('shell','am','start','-W','-n','dev.gbalite.app/.MainActivity');(api_out/f'api{api}-cold-relaunch.log').write_bytes(relaunch.stdout+relaunch.stderr)
    finally:call('emu','kill')
    if not completed: raise RuntimeError('Instrumentation failed or was incomplete; raw evidence retained')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','measure','regression','api26','api29','api26retry','api26audio','api29audio']);args=parser.parse_args()
    {'freeze':freeze,'measure':measure,'regression':regression,'api26':lambda:compatibility(26),'api29':lambda:compatibility(29),'api26retry':lambda:compatibility(26,True),'api26audio':lambda:compatibility(26,audio_only=True),'api29audio':lambda:compatibility(29,audio_only=True)}[args.action]()
