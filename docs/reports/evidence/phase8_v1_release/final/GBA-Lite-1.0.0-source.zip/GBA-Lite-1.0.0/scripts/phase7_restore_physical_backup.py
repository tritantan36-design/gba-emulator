"""Restore the recorded pre-A/B private snapshot after code9 restoration; explicit serial only.

No clear-data/uninstall. Remove only test-added files absent from the immutable backup
within the two backed-up directories, then restore and verify every original byte.
Private game data never goes into the public evidence directory.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path('D:/GPT/projects/gba-emulator')
ADB='D:/GPT/tools/android-sdk/platform-tools/adb.exe'
PRIVATE=Path('D:/GPT/artifacts/gba-emulator/private-device-backups/20261009-PLG110')
EVIDENCE=ROOT/'docs/reports/evidence/phase7_performance_coverage/physical-preflight'

def main(serial, checkpoint=None):
    if serial!='3B15AV01Z0000000': raise RuntimeError('Backup belongs to the explicitly recorded device')
    if checkpoint and (not checkpoint.replace('-', '').isalnum() or len(checkpoint)>64):
        raise RuntimeError('Checkpoint must be a short alphanumeric/hyphen name')
    suffix='-'+checkpoint if checkpoint else ''
    def call(*args): return subprocess.run([ADB,'-s',serial,*args],capture_output=True,check=True).stdout
    before=json.loads((PRIVATE/'file-hashes.json').read_text(encoding='utf-8'))
    preflight=json.loads((EVIDENCE/'preflight.json').read_text(encoding='utf-8'))
    archive=PRIVATE/'app-data-before.tar'
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==preflight['privateBackupSha256']
    packagePath=call('shell','pm','path','dev.gbalite.app').decode().strip().splitlines()[0].removeprefix('package:')
    restoredApk=PRIVATE/('installed-restored'+suffix+'.apk')
    if restoredApk.exists(): raise RuntimeError('Preserve prior APK recovery evidence')
    call('pull',packagePath,str(restoredApk))
    assert hashlib.sha256(restoredApk.read_bytes()).hexdigest()==preflight['installedApkSha256'],'Restore frozen code9 before restoring private data'
    call('shell','am','force-stop','dev.gbalite.app')
    # Retain a complete post-test snapshot before restoring anything.
    after=PRIVATE/('app-data-after-test'+suffix+'.tar')
    if after.exists(): raise RuntimeError('Preserve prior recovery evidence')
    with after.open('wb') as out:
        run=subprocess.run([ADB,'-s',serial,'exec-out','run-as','dev.gbalite.app','tar','-cf','-','files','databases'],stdout=out,stderr=subprocess.PIPE)
        if run.returncode: raise RuntimeError(run.stderr.decode(errors='replace'))
    with tarfile.open(after) as tar:
        additions=[m.name for m in tar if m.isfile() and m.name not in before]
    for name in additions:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or path.parts[0] not in ('files','databases'):
            raise RuntimeError('Unsafe archive member')
        # A/B monopolizes this test app; these are the explicitly captured test additions.
        # The post-test snapshot above keeps them recoverable.
        call('shell','run-as','dev.gbalite.app','rm','--',name)
    temporary='/data/local/tmp/phase7-original-app-data.tar'
    call('push',str(archive),temporary)
    call('shell','run-as','dev.gbalite.app','tar','-xf',temporary)
    call('shell','rm','--',temporary)
    verified=PRIVATE/('app-data-restored'+suffix+'.tar')
    if verified.exists(): raise RuntimeError('Preserve prior verified recovery evidence')
    with verified.open('wb') as out:
        run=subprocess.run([ADB,'-s',serial,'exec-out','run-as','dev.gbalite.app','tar','-cf','-','files','databases'],stdout=out,stderr=subprocess.PIPE)
        if run.returncode: raise RuntimeError(run.stderr.decode(errors='replace'))
    with tarfile.open(verified) as tar:
        restored={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}
    assert restored==before,'Original private files do not match; backups retained'
    settings=json.loads((EVIDENCE/'original-screen-settings.json').read_text(encoding='utf-8'))
    for key in ['screen_brightness','screen_brightness_mode']:
        call('shell','settings','put','system',key,settings[key])
    result={'code9Restored':True,'originalFilesVerified':len(before),'privateFileHashesExactlyRestored':True,
            'testAddedFilesRemovedAfterPrivateSnapshot':len(additions),'screenSettingsRestored':settings,
            'privateBackupRetained':True,'noClearDataOrUninstall':True}
    assert call('shell','settings','get','system','screen_brightness_mode').decode().strip()==settings['screen_brightness_mode'],'Brightness mode restoration did not persist'
    (EVIDENCE/('restore-result'+suffix+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--serial',required=True)
    p.add_argument('--checkpoint',help='Preserve separate restoration evidence for each new campaign')
    a=p.parse_args();main(a.serial,a.checkpoint)
