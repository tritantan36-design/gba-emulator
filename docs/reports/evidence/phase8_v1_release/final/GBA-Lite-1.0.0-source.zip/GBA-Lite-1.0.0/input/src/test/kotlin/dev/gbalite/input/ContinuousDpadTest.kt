package dev.gbalite.input

import dev.gbalite.core.GbaButton
import kotlin.math.*
import org.junit.Assert.*
import org.junit.Test

class ContinuousDpadTest {
    private fun at(degrees: Double,old: DpadState=DpadState())=resolveDpad(cos(degrees*PI/180).toFloat(),sin(degrees*PI/180).toFloat(),old)
    @Test fun eightDirectionsAndAllBoundaries() {
        for(n in 0..7) {
            assertEquals(n,at(n*45.0).sector)
            val boundary=n*45+22.5
            assertEquals(n,at(boundary-.1).sector)
            assertEquals((n+1)%8,at(boundary+.1).sector)
            assertEquals(n,at(boundary+6.9,DpadState(n)).sector)
            assertEquals((n+1)%8,at(boundary+7.1,DpadState(n)).sector)
            assertEquals((n+1)%8,at(boundary-6.9,DpadState((n+1)%8)).sector)
            assertEquals(n,at(boundary-7.1,DpadState((n+1)%8)).sector)
        }
    }
    @Test fun clockwiseAndCounterclockwiseContinuousTransitions() {
        for(sign in listOf(1,-1)) for(start in listOf(0,90,180,270)) {
            var old=at(start.toDouble())
            val visited=mutableSetOf<Int>()
            for(step in 0..90) {
                old=at((start+step*sign).toDouble(),old)
                assertFalse(old.buttons.isEmpty());visited+=old.sector!!
            }
            assertEquals(3,visited.size)
        }
    }
    @Test fun deadZoneCenterCrossingTimeoutAndRegionExit() {
        assertTrue(resolveDpad(0f,0f).buttons.isEmpty())
        val right=at(0.0);val hold=resolveDpad(0f,0f,right,100)
        assertEquals(setOf(GbaButton.RIGHT),hold.buttons)
        assertEquals(setOf(GbaButton.RIGHT),resolveDpad(0f,0f,hold,179).buttons)
        assertTrue(resolveDpad(0f,0f,hold,180).buttons.isEmpty())
        assertEquals(setOf(GbaButton.LEFT),resolveDpad(-.5f,0f,hold,130).buttons)
        assertTrue(resolveDpad(1.16f,0f,right).buttons.isEmpty())
        assertTrue(resolveDpad(Float.NaN,0f,right).buttons.isEmpty())
        assertEquals(setOf(GbaButton.RIGHT,GbaButton.DOWN),resolveDpad(1.1f,1.1f).buttons)
    }
    @Test fun routerOnlySendsDifferencesAndPreservesOtherPointer() {
        val changes=mutableListOf<Pair<GbaButton,Boolean>>()
        val router=InputRouter {b,down->changes+=b to down}
        router.update("a",setOf(GbaButton.A));router.update("dpad",at(0.0).buttons);changes.clear()
        router.update("dpad",at(45.0).buttons)
        assertEquals(listOf(GbaButton.DOWN to true),changes);changes.clear()
        router.update("dpad",at(90.0).buttons)
        assertEquals(listOf(GbaButton.RIGHT to false),changes);changes.clear()
        router.releaseSource("dpad")
        assertEquals(listOf(GbaButton.DOWN to false),changes);changes.clear()
        router.releaseAll();assertEquals(listOf(GbaButton.A to false),changes)
    }
}
