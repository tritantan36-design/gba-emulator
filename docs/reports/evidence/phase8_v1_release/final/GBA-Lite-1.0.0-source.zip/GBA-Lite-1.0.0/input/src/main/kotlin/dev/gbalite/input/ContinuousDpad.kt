package dev.gbalite.input

import dev.gbalite.core.GbaButton
import kotlin.math.*

/** Normalized to the current visual half-width, independent of layout and rendering. */
data class DpadState(val sector: Int?=null,val centerSince: Long?=null) {
    val buttons: Set<GbaButton> get()=when(sector) {
        0 -> setOf(GbaButton.RIGHT)
        1 -> setOf(GbaButton.RIGHT,GbaButton.DOWN)
        2 -> setOf(GbaButton.DOWN)
        3 -> setOf(GbaButton.DOWN,GbaButton.LEFT)
        4 -> setOf(GbaButton.LEFT)
        5 -> setOf(GbaButton.LEFT,GbaButton.UP)
        6 -> setOf(GbaButton.UP)
        7 -> setOf(GbaButton.UP,GbaButton.RIGHT)
        else -> emptySet()
    }
}

fun resolveDpad(dx: Float,dy: Float,previous: DpadState=DpadState(),nowMs: Long=0): DpadState {
    if(!dx.isFinite() || !dy.isFinite() || abs(dx)>1.15f || abs(dy)>1.15f) return DpadState()
    if(hypot(dx,dy)<.12f) {
        if(previous.sector==null) return DpadState()
        val since=previous.centerSince ?: nowMs
        return if(nowMs-since<80) previous.copy(centerSince=since) else DpadState()
    }
    val angle=(atan2(dy.toDouble(),dx.toDouble())*180/PI+360)%360
    val old=previous.sector
    if(old!=null) {
        val delta=abs((angle-old*45+540)%360-180)
        if(delta<=22.5+7) return DpadState(old)
    }
    return DpadState(((angle+22.5)/45).toInt()%8)
}
