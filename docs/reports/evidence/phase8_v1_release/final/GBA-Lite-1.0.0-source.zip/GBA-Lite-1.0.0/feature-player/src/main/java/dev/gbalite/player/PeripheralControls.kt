package dev.gbalite.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import dev.gbalite.core.*

@Composable fun PeripheralDialog(s: PeripheralSettings,change: (PeripheralSettings)->Unit,detected: Int,
    tilt: Boolean,gyro: Boolean,light: Boolean,haptic: String,done: ()->Unit,calibrate: ()->Unit,manual: (() -> Unit)?) {
    AlertDialog(onDismissRequest=done,title={Text("外设")},confirmButton={TextButton(onClick=done) { Text("返回菜单") }},
        text={Column(Modifier.verticalScroll(rememberScrollState())) {PeripheralContent(s,change,detected,tilt,gyro,light,haptic,calibrate,manual)}})
}
@Composable fun ColumnScope.PeripheralContent(s: PeripheralSettings,change: (PeripheralSettings)->Unit,detected: Int,tilt: Boolean,gyro: Boolean,light: Boolean,haptic: String,calibrate: ()->Unit,manual: (() -> Unit)?,gameLoaded: Boolean=true) {
    Text("仅支持相应卡带功能的游戏会响应感应输入，普通游戏无需调整。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    PeripheralSection("手柄", "蓝牙与 USB") {
        Detail("连接方式", "在系统设置中连接蓝牙手柄，或通过 USB 接入。连接后可直接操作。")
        Detail("按键对应", "Xbox A / PlayStation × → A\nXbox X / PlayStation □ → B\nL1 / R1 → L / R\nStart → START，Select / Back → SELECT\n方向键 / 左摇杆 → 方向")
    }
    PeripheralSection("动作感应", "倾斜与旋转") {
        ModeSelector("倾斜",s.tilt,sensorStatus(16,tilt,detected,gameLoaded),"控制游戏中的倾斜方向") {change(s.copy(tilt=it))}
        HorizontalDivider()
        ModeSelector("陀螺仪",s.gyro,sensorStatus(8,gyro,detected,gameLoaded),"控制游戏中的旋转动作") {change(s.copy(gyro=it))}
        Text("自动：按游戏需求使用设备传感器；设备不支持时使用手动输入。",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(enabled=gameLoaded && (tilt || gyro),onClick=calibrate) {Text("以刚才的姿态校准中立")}
        Text(if(gameLoaded) "先以舒适姿态游玩，再打开此页校准。旋转屏幕后可重新校准。" else "开始游戏后可校准中立姿态。",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(enabled=manual!=null,onClick={manual?.invoke()}) {Text("打开手动倾斜／旋转控制")}
        Text(if(manual==null) "开始游戏后可打开手动控制；倾斜圆盘松开回中，旋转滑块松开停止。" else "选择手动模式后打开控制面板；松手回中或停止。",style=MaterialTheme.typography.bodySmall)
    }
    PeripheralSection("光照感应", "太阳能卡带") {
        ModeSelector("太阳能",s.solar,sensorStatus(4,light,detected,gameLoaded),"只控制卡带日照输入，不改变屏幕亮度") {change(s.copy(solar=it))}
        Text("手动日照强度：${s.sunlight}%",style=MaterialTheme.typography.bodyMedium)
        Slider(value=s.sunlight.toFloat(),onValueChange={change(s.copy(sunlight=it.toInt()))},valueRange=0f..100f,steps=9,
            enabled=s.solar!=PeripheralMode.DISABLED && (s.solar==PeripheralMode.MANUAL || !light))
        Text(when {s.solar==PeripheralMode.DISABLED->"太阳能输入已关闭。";s.solar==PeripheralMode.MANUAL->"拖动滑块设置游戏中的日照强度。";!light->"设备无可用光照传感器，自动模式使用上方手动强度。";else->"自动模式使用环境光；切换到手动后可调节强度。"},style=MaterialTheme.typography.bodySmall)
    }
    PeripheralSection("时钟与震动", "其他卡带功能") {
        Detail("实时时钟", "自动使用系统时间，供支持时钟功能的游戏读取。")
        HorizontalDivider()
        Detail("真实震动当前未启用", "当前版本不提供游戏震动。")
    }
}
@Composable private fun PeripheralSection(title: String,subtitle: String,content: @Composable ColumnScope.()->Unit) {
    Surface(shape=dev.gbalite.player.ui.UiShapes.Card,color=MaterialTheme.colorScheme.surface,
        border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text(title,style=MaterialTheme.typography.titleMedium)
            Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}
@Composable private fun Detail(title: String,text: String) {
    Text(title,style=MaterialTheme.typography.bodyMedium)
    Text(text,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
}
private fun sensorStatus(flag: Int,available: Boolean,detected: Int,gameLoaded: Boolean): String {
    val device=if(available) "支持" else "无可用传感器，可使用手动输入"
    val game=if(!gameLoaded) "载入游戏后检测" else if(detected and flag!=0) "已检测到需求" else "未自动检测到需求"
    return "设备：$device\n游戏：$game"
}
@Composable private fun ModeSelector(title: String,mode: PeripheralMode,status: String,description: String,select: (PeripheralMode)->Unit) {
    Text(title,style=MaterialTheme.typography.bodyMedium)
    Text(description,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    Text(status,style=MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {PeripheralMode.entries.forEach {m ->
        FilterChip(selected=m==mode,onClick={select(m)},label={Text(when(m) {PeripheralMode.AUTO->"自动";PeripheralMode.MANUAL->"手动";PeripheralMode.DISABLED->"关闭"})})
    }}
}
/** Modal live control: game runs; listeners remain scoped to Session state. Release resets axes. */
@Composable internal fun ManualPeripheralPanel(send: (Float,Float,Float)->Unit,done: ()->Unit) {
    DisposableEffect(Unit) { onDispose { send(0f,0f,0f) } }
    var x by remember { mutableFloatStateOf(0f) };var y by remember { mutableFloatStateOf(0f) }
    var z by remember { mutableFloatStateOf(0f) }
    AlertDialog(onDismissRequest=done,title={Text("手动控制")},confirmButton={TextButton(onClick=done) { Text("完成") }},text={Column {
        Text("先在外设设置选手动。拖动圆盘倾斜；松开回中立。")
        Canvas(Modifier.fillMaxWidth().height(140.dp).pointerInput(Unit) {
            detectDragGestures(onDragStart={ p ->
                x=(p.x/size.width*2-1).coerceIn(-1f,1f);y=(1-p.y/size.height*2).coerceIn(-1f,1f);send(x,y,z)
            },onDragEnd={x=0f;y=0f;send(0f,0f,z)},onDragCancel={x=0f;y=0f;send(0f,0f,z)}) { c,_ ->
                c.consume();x=(c.position.x/size.width*2-1).coerceIn(-1f,1f)
                y=(1-c.position.y/size.height*2).coerceIn(-1f,1f);send(x,y,z)
            }
        }) {
            drawCircle(Color.LightGray,radius=size.minDimension/2)
            drawCircle(Color.DarkGray,12.dp.toPx(),Offset((x+1)*size.width/2,(1-y)*size.height/2))
        }
        Text("旋转角速度（独立于倾斜，松手停止）")
        Slider(value=z,onValueChange={z=it;send(x,y,z)},onValueChangeFinished={z=0f;send(x,y,0f)},valueRange=-1f..1f)
    }})
}
