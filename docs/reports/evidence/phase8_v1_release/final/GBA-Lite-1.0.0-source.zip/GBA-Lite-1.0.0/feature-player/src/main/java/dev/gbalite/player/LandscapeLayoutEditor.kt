package dev.gbalite.player

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import dev.gbalite.core.FrameSource
import dev.gbalite.input.*
import dev.gbalite.player.ui.*
import java.nio.ByteBuffer
import kotlin.math.roundToInt

/** An isolated, paused preview: tools never overlap the draggable control viewport. */
@Composable internal fun LandscapeLayoutEditor(profile: InputProfile,frames: FrameSource,busy: Boolean,error: String?,
    onChange: (InputProfile)->Unit,onReset: ()->Unit,onSave: ()->Unit,onCancel: ()->Unit) {
    var selected by remember {mutableStateOf("A")}
    var all by remember {mutableStateOf(false)}
    var base by remember {mutableStateOf(profile)}
    var factor by remember {mutableFloatStateOf(1f)}
    val router=remember {InputRouter {_,_->}}
    val image=remember(frames) {
        val buffer=ByteBuffer.allocateDirect(240*160*4)
        if(frames.copyFrame(buffer)) {
            buffer.rewind()
            val pixels=IntArray(240*160) {
                val r=buffer.get().toInt() and 255;val g=buffer.get().toInt() and 255;val b=buffer.get().toInt() and 255;buffer.get()
                (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            Bitmap.createBitmap(pixels,240,160,Bitmap.Config.ARGB_8888)
        } else null
    }
    Surface(Modifier.fillMaxSize().testTag("landscape-layout-editor"),color=MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            GbaTopBar("横屏按键布局",back=if(busy) null else onCancel,actions={
                TextButton(enabled=!busy,onClick=onCancel) {Text("取消")}
                Button(enabled=!busy,onClick=onSave,modifier=Modifier.padding(end=12.dp).testTag("layout-save")) {Text(if(busy) "保存中…" else "保存布局")}
            })
            Row(Modifier.fillMaxWidth().weight(1f),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f).fillMaxHeight().padding(start=12.dp,bottom=12.dp).testTag("editor-preview-pane"),contentAlignment=Alignment.Center) {
                    ControlPreview(profile,router,selected,onChange,{selected=it},Modifier.fillMaxSize()) {
                        Box(Modifier.fillMaxSize().background(Color.Black))
                        image?.let {Image(it.asImageBitmap(),"暂停画面预览",Modifier.fillMaxSize(),contentScale=ContentScale.Fit,filterQuality=FilterQuality.None)}
                    }
                }
                Column(Modifier.width(248.dp).fillMaxHeight().testTag("editor-tools-pane").verticalScroll(rememberScrollState()).padding(end=12.dp,bottom=12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text("直接拖动左侧按键",style=MaterialTheme.typography.titleSmall)
                    Text("当前：${if(selected=="DPAD") "方向键" else selected}",style=MaterialTheme.typography.bodySmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        profile.controls.forEach {control -> FilterChip(selected=control.key==selected,onClick={selected=control.key},label={Text(if(control.key=="DPAD") "方向" else control.key)})}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=!all,onClick={all=false},label={Text("单个")})
                        FilterChip(selected=all,onClick={base=profile;factor=1f;all=true},label={Text("整体")})
                    }
                    Text(if(all) "整体大小：${(factor*100).roundToInt()}%" else "按键大小：${(profile.controls.first {it.key==selected}.size*100).roundToInt()}%",style=MaterialTheme.typography.bodySmall)
                    if(all) {
                        val lo=InputProfile.MIN_SIZE/base.controls.minOf {it.size};val hi=InputProfile.MAX_SIZE/base.controls.maxOf {it.size}
                        if(hi-lo>.0001f) Slider(factor,{factor=it;val sizes=base.scaledSizes(it).controls.associate {c->c.key to c.size};onChange(profile.copy(controls=profile.controls.map {c->c.copy(size=sizes.getValue(c.key))}))},valueRange=lo..hi)
                    } else Slider(profile.controls.first {it.key==selected}.size,{value->onChange(profile.copy(controls=profile.controls.map {if(it.key==selected) it.copy(size=value) else it}))},valueRange=InputProfile.MIN_SIZE..InputProfile.MAX_SIZE)
                    Text("透明度：${(profile.opacity*100).roundToInt()}%",style=MaterialTheme.typography.bodySmall)
                    Slider(profile.opacity,{onChange(profile.copy(opacity=it))},valueRange=.15f..1f)
                    OutlinedButton(enabled=!busy,onClick={all=false;factor=1f;base=InputProfile.default(true);onReset()}) {Text("恢复默认")}
                    Text("游戏已暂停；保存后生效。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    error?.let {Text(it,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)}
                }
            }
        }
    }
}
