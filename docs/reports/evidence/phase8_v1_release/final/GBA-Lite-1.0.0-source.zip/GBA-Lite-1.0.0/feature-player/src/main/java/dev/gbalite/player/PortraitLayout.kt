package dev.gbalite.player

/** Modest top breathing room, capped to preserve controls on shorter screens. */
internal fun portraitScreenInset(width: Float,height: Float,density: Float): Float =
    minOf(48f*density,((height-width/1.5f).coerceAtLeast(0f))*.10f)
