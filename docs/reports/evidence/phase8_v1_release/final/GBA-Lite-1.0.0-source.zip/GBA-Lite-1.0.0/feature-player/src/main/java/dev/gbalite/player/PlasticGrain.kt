package dev.gbalite.player

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Shader
import kotlin.random.Random

/** Small, deterministic tiles reused by every frame; no per-frame bitmap allocation. */
internal object PlasticGrain {
    val face: BitmapShader by lazy {
        val random=Random(73)
        val pixels=IntArray(64*64) {val c=random.nextInt(246,256);(255 shl 24) or (c shl 16) or (c shl 8) or c}
        BitmapShader(Bitmap.createBitmap(pixels,64,64,Bitmap.Config.ARGB_8888),Shader.TileMode.REPEAT,Shader.TileMode.REPEAT)
    }
    val shell: BitmapShader by lazy {
        val random=Random(91)
        val pixels=IntArray(128*128) {(random.nextInt(3,10) shl 24) or if(random.nextBoolean()) 0x00ffffff else 0}
        BitmapShader(Bitmap.createBitmap(pixels,128,128,Bitmap.Config.ARGB_8888),Shader.TileMode.REPEAT,Shader.TileMode.REPEAT)
    }
}
