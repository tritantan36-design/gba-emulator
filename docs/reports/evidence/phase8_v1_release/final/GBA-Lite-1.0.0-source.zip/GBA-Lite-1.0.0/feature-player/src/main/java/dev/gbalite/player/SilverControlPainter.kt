package dev.gbalite.player

import android.graphics.*

/** Procedural silver plastic: shared by the player, layout editor and menu. */
internal class SilverControlPainter {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val path=Path()
    private val rect=RectF()
    private val bold=Typeface.create(Typeface.DEFAULT,Typeface.BOLD)
    private val faces=mutableMapOf<Pair<Float,Float>,Shader>()
    private val bevels=mutableMapOf<Float,Shader>()
    private val recesses=mutableMapOf<Float,Shader>()
    private val corners=mutableMapOf<Float,CornerPathEffect>()
    private val shoulderRadii=FloatArray(8)

    fun draw(canvas: Canvas,key: String,rx: Float,ry: Float,density: Float,pressed: Float=0f,selected: Boolean=false) {
        val small=key in setOf("SELECT","START","MENU")
        val circle=key=="A" || key=="B" || small
        val radius=if(small) ry*.67f else rx
        val cy=if(small) -ry*.24f else 0f
        val height=if(circle) radius else ry
        val rim=if(small) radius*.10f else minOf(rx,ry)*.055f
        fun shape(inset: Float=0f,dy: Float=0f) {
            if(key=="DPAD") {
                val outer=rx-inset;val arm=rx*.36f-inset
                path.reset();path.moveTo(-arm,-outer+dy);path.lineTo(arm,-outer+dy)
                path.lineTo(arm,-arm+dy);path.lineTo(outer,-arm+dy)
                path.lineTo(outer,arm+dy);path.lineTo(arm,arm+dy)
                path.lineTo(arm,outer+dy);path.lineTo(-arm,outer+dy)
                path.lineTo(-arm,arm+dy);path.lineTo(-outer,arm+dy)
                path.lineTo(-outer,-arm+dy);path.lineTo(-arm,-arm+dy);path.close()
                paint.pathEffect=corners.getOrPut(rx) {CornerPathEffect(rx*.12f)}
                canvas.drawPath(path,paint);paint.pathEffect=null
            } else if(circle) canvas.drawCircle(0f,cy+dy,radius-inset,paint)
            else {
                rect.set(-rx+inset,-ry+inset+dy,rx-inset,ry-inset+dy)
                // Shoulder keys have a straight upper lip and an inward rounded heel.
                shoulderRadii.fill(ry*.12f)
                val heel=if(key=="L") 4 else 6
                shoulderRadii[heel]=ry*1.5f;shoulderRadii[heel+1]=ry*1.5f
                path.reset();path.addRoundRect(rect,shoulderRadii,Path.Direction.CW)
                canvas.drawPath(path,paint)
            }
        }
        paint.style=Paint.Style.FILL;paint.shader=null
        // A soft contact shadow, then a dark socket and the visible lower sidewall.
        paint.color=0x10000000;shape(inset=-1.2f*density,dy=(3f-pressed)*density)
        paint.color=0x25000000;shape(inset=-.6f*density,dy=(2.5f-pressed)*density)
        paint.color=0xff18191c.toInt();shape(dy=(2f-pressed)*density)
        val body=canvas.save();val travel=pressed*1.5f*density;canvas.translate(0f,travel)
        paint.color=0xff303136.toInt();shape()
        // Rounded moulded bevel catches the light above a broad, subtly grained face.
        paint.shader=bevels.getOrPut(height) {LinearGradient(0f,-height,0f,height,
            intArrayOf(0xfff9f9f7.toInt(),0xffdededb.toInt(),0xffa0a1a3.toInt(),0xff606166.toInt()),
            floatArrayOf(0f,.22f,.78f,1f),Shader.TileMode.CLAMP)}
        shape(inset=rim*.65f)
        paint.shader=faces.getOrPut(rx to height) {ComposeShader(LinearGradient(-rx*.55f,-height,rx*.55f,height,
            intArrayOf(0xfff2f2f0.toInt(),0xffe6e6e4.toInt(),0xffd3d3d1.toInt(),0xffbcbdbb.toInt()),
            floatArrayOf(0f,.32f,.72f,1f),Shader.TileMode.CLAMP),PlasticGrain.face,PorterDuff.Mode.MULTIPLY)}
        shape(inset=rim*1.7f)
        paint.shader=null
        if(key=="DPAD") {
            // Four recessed triangular arrows; no font-dependent arrow glyphs.
            for(turn in 0..3) {
                val save=canvas.save();canvas.rotate(turn*90f)
                path.reset();path.moveTo(0f,-rx*.75f);path.lineTo(rx*.16f,-rx*.47f);path.lineTo(-rx*.16f,-rx*.47f);path.close()
                canvas.save();canvas.translate(0f,density)
                paint.color=0xfff7f7f3.toInt();canvas.drawPath(path,paint);canvas.restore()
                paint.shader=recesses.getOrPut(rx) {LinearGradient(0f,-rx*.75f,0f,-rx*.47f,0xff969694.toInt(),0xffc0c0be.toInt(),Shader.TileMode.CLAMP)}
                canvas.drawPath(path,paint);paint.shader=null
                paint.style=Paint.Style.STROKE;paint.strokeWidth=maxOf(.5f,density*.5f);paint.color=0xff939391.toInt();canvas.drawPath(path,paint);paint.style=Paint.Style.FILL
                canvas.restoreToCount(save)
            }
            paint.color=0xfff4f4f0.toInt();canvas.drawCircle(0f,density,rx*.19f,paint)
            paint.color=0xff999997.toInt();canvas.drawCircle(0f,0f,rx*.19f,paint)
            paint.color=0xffbdbdbb.toInt();canvas.drawCircle(0f,density*.5f,rx*.175f,paint)
        } else {
            paint.typeface=bold;paint.textAlign=Paint.Align.CENTER
            paint.textSize=if(small) minOf(12*density,rx*.55f) else if(key=="L" || key=="R") ry*1.15f else radius*.80f
            val baseline=if(small) ry*.98f-travel else -(paint.ascent()+paint.descent())/2
            if(!small) {
                paint.color=0xfff8f8f6.toInt();canvas.drawText(key,0f,baseline+density*.7f,paint)
                paint.color=0xff8b8b89.toInt();canvas.drawText(key,0f,baseline-density*.35f,paint)
            }
            paint.color=if(small) 0xff626260.toInt() else 0xffa6a6a4.toInt()
            canvas.drawText(key,0f,baseline,paint)
        }
        if(selected) {
            paint.style=Paint.Style.STROKE;paint.strokeWidth=2*density;paint.color=0xffad8cdb.toInt();shape()
            paint.style=Paint.Style.FILL
        }
        canvas.restoreToCount(body)
    }
}
