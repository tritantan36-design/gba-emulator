package dev.gbalite.player

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.StrokeCap
import dev.gbalite.core.BackgroundTone

fun shellName(tone: BackgroundTone)=when(tone) {
    BackgroundTone.PURPLE->"紫色";BackgroundTone.WHITE->"白色"
    BackgroundTone.BLACK->"黑色";BackgroundTone.RED->"红色"
}
fun shellColor(tone: BackgroundTone)=when(tone) {
    BackgroundTone.PURPLE->Color(0xFF7024B1);BackgroundTone.WHITE->Color(0xFFE5E3DD)
    BackgroundTone.BLACK->Color(0xFF25262C);BackgroundTone.RED->Color(0xFFB02D3F)
}
/** Code-drawn plastic casing, shared with the portrait control-layout preview. */
@Composable fun ConsoleShell(tone: BackgroundTone,modifier: Modifier,controls: Boolean=false) {
    val colors=when(tone) {
        BackgroundTone.PURPLE->listOf(Color(0xFF8533C6),shellColor(tone),Color(0xFF541689))
        BackgroundTone.WHITE->listOf(Color(0xFFF3F1EB),shellColor(tone),Color(0xFFCACAC4))
        BackgroundTone.BLACK->listOf(Color(0xFF37393F),shellColor(tone),Color(0xFF17181D))
        BackgroundTone.RED->listOf(Color(0xFFCD4B58),shellColor(tone),Color(0xFF842232))
    }
    val grain=remember {android.graphics.Paint().apply {shader=PlasticGrain.shell}}
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(colors))
        drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha=.10f),Color.Transparent),
            center=Offset(size.width*.15f,-size.height*.08f),radius=size.maxDimension*.95f))
        drawRect(Brush.horizontalGradient(listOf(Color.Black.copy(alpha=.20f),Color.Transparent,Color.Transparent,Color.Black.copy(alpha=.17f)),
            startX=0f,endX=size.width))
        drawIntoCanvas {it.nativeCanvas.drawRect(0f,0f,size.width,size.height,grain)}
        // A thin moulded lip and inset edge catch the light without obscuring controls.
        drawRoundRect(Color.White.copy(alpha=.10f),Offset(2*density,2*density),
            Size(size.width-4*density,size.height-4*density),CornerRadius(14*density),style=Stroke(1.5f*density))
        drawRoundRect(Color.Black.copy(alpha=.18f),Offset(5*density,5*density),
            Size(size.width-10*density,size.height-10*density),CornerRadius(12*density),style=Stroke(density))
        if(controls) {
            drawLine(Color.Black.copy(alpha=.5f),Offset.Zero,Offset(size.width,0f),4*density)
            drawLine(Color.White.copy(alpha=.25f),Offset(0f,3*density),Offset(size.width,3*density),density)
            // Recessed speaker vents at the foot of the casing.
            repeat(5) {index ->
                val x=size.width*(.75f+index*.035f)
                val from=Offset(x,size.height*.935f);val to=Offset(x-size.width*.015f,size.height*.975f)
                drawLine(Color.White.copy(alpha=.24f),from+Offset(density,density),to+Offset(density,density),3.5f*density,cap=StrokeCap.Round)
                drawLine(Color.Black.copy(alpha=.50f),from,to,3*density,cap=StrokeCap.Round)
                drawLine(Color.Black.copy(alpha=.35f),from,to,1.5f*density,cap=StrokeCap.Round)
            }
        }
    }
}
