package dev.gbalite.player
import android.content.Context
import android.graphics.Canvas
import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.View
import dev.gbalite.input.*
import dev.gbalite.core.GbaButton
import kotlin.math.min

/** All pointers are hit-tested every event, including slides and cancellation. */
class TouchControls(context: Context,private val router: InputRouter): View(context) {
    init {contentDescription="GBA 触控：方向键、A、B、L、R、Start、Select"}
    var profile=InputProfile.default(false); set(value) { if(field!=value) { if(!editing) release();field=value; invalidate() } }
    var editing=false; set(value) { if(field!=value) { field=value; invalidate() } }
    /** Editor-only scale keeps minimum touch sizes and drawing metrics proportional to the real player. */
    var previewWidth: Float?=null;set(value) {if(field!=value) {field=value;invalidate()}}
    private fun controlDensity()=resources.displayMetrics.density*(previewWidth?.let {width/it.coerceAtLeast(1f)} ?: 1f)
    var onEdited: (InputProfile)->Unit={}
    var onSelected: (String)->Unit={}
    private val painter=SilverControlPainter()
    private var dragKey: String?=null
    private var dragPointer=-1
    private var pointers=emptySet<String>()
    private val dpadOwners=mutableMapOf<String,DpadState>()
    private val centerReleases=mutableMapOf<String,Runnable>()
    var acceptingInput=true;set(value) {if(field!=value) {field=value;release()}}
    private fun clearDpad(source: String) {
        dpadOwners.remove(source);centerReleases.remove(source)?.let(::removeCallbacks)
    }
    private fun base()=if(profile.landscape) min(width,height)*1.45f else width.toFloat()
    private var pressed=emptySet<String>()
    private var fading=emptySet<String>()
    private var fade=0f
    private val feedback=ValueAnimator.ofFloat(1f,0f).apply {
        duration=100
        addUpdateListener {fade=it.animatedValue as Float;invalidate()}
    }
    private fun pressed(keys: Set<String>) {
        if(keys==pressed) return
        fading=pressed-keys;pressed=keys
        feedback.cancel();feedback.start();invalidate()
    }
    private fun extents(c: TouchControl,r: Float): Pair<Float,Float> = when(c.key) {
        "L","R" -> r*1.20f to maxOf(24*controlDensity(),r*.40f)
        "START","SELECT" -> maxOf(36*controlDensity(),r*1.25f) to maxOf(24*controlDensity(),r*.38f)
        else -> r to r
    }
    private fun geometry(c: TouchControl): Triple<Float,Float,Float> {
        val r=min(maxOf(c.size*base()/2,24*controlDensity()),min(width,height)*.45f)
        val (rx,ry)=extents(c,r)
        return Triple(if(width>=2*rx) (c.x*width).coerceIn(rx,width-rx) else width/2f,if(height>=2*ry) (c.y*height).coerceIn(ry,height-ry) else height/2f,r)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val density=controlDensity()
        for(c in profile.controls) {
            val (x,y,r)=geometry(c);val (rx,ry)=extents(c,r)
            val amount=if(c.key in pressed) 1f else if(c.key in fading) fade else 0f
            val opacity=((profile.opacity+(1-profile.opacity)*amount*.35f)*255).toInt()
            val layer=canvas.saveLayerAlpha(x-rx-4*density,y-ry-4*density,x+rx+4*density,y+ry+6*density,opacity)
            canvas.save();canvas.translate(x,y)
            painter.draw(canvas,c.key,rx,ry,density,amount,editing && c.key==selectedKey)
            canvas.restore()
            canvas.restoreToCount(layer)
        }
    }
    var selectedKey="A";set(value) {if(field!=value) {field=value;invalidate()}}
    private fun hit(x: Float,y: Float): TouchControl?=profile.controls.sortedBy {it.key=="DPAD"}.firstOrNull {
        val (cx,cy,r)=geometry(it);val (rx,ry)=extents(it,r)
        if(it.key=="DPAD") {
            val dx=kotlin.math.abs(x-cx);val dy=kotlin.math.abs(y-cy)
            if(editing) dx<=r && dy<=r else dx<=r*1.15f && dy<=r*1.15f
        }
        else if(it.key in setOf("L","R","START","SELECT")) kotlin.math.abs(x-cx)<=rx && kotlin.math.abs(y-cy)<=ry
        else (x-cx)*(x-cx)+(y-cy)*(y-cy)<=r*r
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if(event.actionMasked==MotionEvent.ACTION_CANCEL) { router.releaseAll(); release(); return true }
        if(editing) {
            if(event.actionMasked==MotionEvent.ACTION_DOWN) {
                dragKey=hit(event.x,event.y)?.key; dragPointer=event.getPointerId(0)
                dragKey?.let(onSelected)
            }
            val index=event.findPointerIndex(dragPointer)
            if(index>=0 && event.actionMasked==MotionEvent.ACTION_MOVE) {
                profile=profile.copy(controls=profile.controls.map { c-> if(c.key==dragKey)
                    c.copy(x=(event.getX(index)/width).coerceIn(if(profile.landscape) 0f else .08f,if(profile.landscape) 1f else .92f),y=(event.getY(index)/height).coerceIn(.08f,.92f)) else c })
                onEdited(profile)
            }
            if(event.actionMasked==MotionEvent.ACTION_UP) release()
            return true
        }
        if(!acceptingInput) {release();return true}
        val active=mutableSetOf<String>()
        val visual=mutableSetOf<String>()
        val observed=(0 until event.pointerCount).map { "touch:${event.getPointerId(it)}" }.toSet()
        if((pointers-observed).isNotEmpty()) { router.releaseAll(); release(); return true }
        for(i in 0 until event.pointerCount) {
            val source="touch:${event.getPointerId(i)}"
            if((event.actionMasked==MotionEvent.ACTION_UP || event.actionMasked==MotionEvent.ACTION_POINTER_UP) && i==event.actionIndex) {
                router.releaseSource(source);clearDpad(source); continue
            }
            active+=source
            val newlyDown=(event.actionMasked==MotionEvent.ACTION_DOWN || event.actionMasked==MotionEvent.ACTION_POINTER_DOWN) && i==event.actionIndex
            val c=if(source in dpadOwners) profile.controls.firstOrNull {it.key=="DPAD"} else hit(event.getX(i),event.getY(i))
            if(newlyDown && c?.key=="DPAD") dpadOwners[source]=DpadState()
            val keys=if(c==null) emptySet() else if(c.key=="DPAD" && source in dpadOwners) {
                val (x,y,r)=geometry(c)
                val next=resolveDpad((event.getX(i)-x)/r,(event.getY(i)-y)/r,dpadOwners.getValue(source),android.os.SystemClock.uptimeMillis())
                dpadOwners[source]=next
                centerReleases.remove(source)?.let(::removeCallbacks)
                val centerSince=next.centerSince
                if(centerSince!=null) {
                    val callback=Runnable {
                        if(dpadOwners[source]==next) {
                            dpadOwners[source]=DpadState();router.releaseSource(source)
                            if(dpadOwners.values.none {it.buttons.isNotEmpty()}) pressed(pressed-"DPAD")
                        }
                        centerReleases.remove(source)
                    }
                    centerReleases[source]=callback
                    postDelayed(callback,(80-(android.os.SystemClock.uptimeMillis()-centerSince)).coerceAtLeast(0))
                }
                next.buttons
            } else if(c.key=="DPAD") emptySet() else setOf(GbaButton.valueOf(c.key))
            if(keys.isNotEmpty()) c?.let {visual+=it.key}
            router.update(source,keys)
        }
        (pointers-active).forEach {router.releaseSource(it);clearDpad(it)}; pointers=active;pressed(visual)
        if(event.actionMasked==MotionEvent.ACTION_UP) { release(); performClick() }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
    fun release() { centerReleases.values.forEach(::removeCallbacks);centerReleases.clear();dpadOwners.clear();router.releasePrefix("touch:"); pointers=emptySet(); dragKey=null; dragPointer=-1;pressed(emptySet()) }
    override fun onDetachedFromWindow() { router.releaseAll(); release(); feedback.cancel(); super.onDetachedFromWindow() }
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) { if(!hasWindowFocus) release(); super.onWindowFocusChanged(hasWindowFocus) }
}
