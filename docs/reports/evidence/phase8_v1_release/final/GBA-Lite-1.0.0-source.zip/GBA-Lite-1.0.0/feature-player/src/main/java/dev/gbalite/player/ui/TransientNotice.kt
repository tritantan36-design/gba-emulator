package dev.gbalite.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** A visual-only overlay: never consumes a pointer or contributes to page measurement. */
@Composable fun TransientNotice(text: String?,event: Long,onExpired: ()->Unit) {
    val expired by rememberUpdatedState(onExpired)
    var lastText by remember {mutableStateOf("")}
    if(text!=null) SideEffect {lastText=text}
    LaunchedEffect(text,event) {if(text!=null) {delay(1800);expired()}}
    Box(Modifier.fillMaxSize().safeDrawingPadding(),contentAlignment=Alignment.Center) {
        AnimatedVisibility(text!=null,enter=fadeIn(),exit=fadeOut()) {
            // Material Surface installs a pointer node even in its non-clickable overload.
            // A drawing-only Box lets hit testing reach controls beneath the card itself.
            Box(modifier=Modifier.widthIn(max=300.dp).padding(16.dp)
                    .shadow(8.dp,UiShapes.Small).background(MaterialTheme.colorScheme.inverseSurface,UiShapes.Small).testTag("transient-notice")
                    .semantics {liveRegion=LiveRegionMode.Polite}) {
                Text(lastText,Modifier.padding(horizontal=20.dp,vertical=12.dp),
                    color=MaterialTheme.colorScheme.inverseOnSurface,style=MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
