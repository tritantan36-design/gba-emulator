package dev.gbalite.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp

@Composable internal fun SilverMenuButton(opacity: Float,landscape: Boolean,speed: Int,modifier: Modifier,onClick: ()->Unit) {
    val painter=remember {SilverControlPainter()}
    Canvas(modifier.size(if(landscape) 48.dp else 56.dp).alpha(opacity)
        .semantics {contentDescription="菜单";stateDescription="${speed}×";role=Role.Button}.clickable(onClick=onClick)) {
        drawIntoCanvas {
            val canvas=it.nativeCanvas;val save=canvas.save()
            canvas.translate(size.width/2,size.height/2)
            painter.draw(canvas,"MENU",size.width*.43f,size.height*.40f,density)
            canvas.restoreToCount(save)
        }
    }
}
