plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
subprojects {
    dependencyLocking { lockAllConfigurations() }
    configurations.configureEach {
        resolutionStrategy.eachDependency {
            val v = requested.version.orEmpty()
            require(!v.contains("+") && !v.contains("SNAPSHOT", true) && !v.startsWith("latest")) {
                "Unpinned dependency: $requested"
            }
        }
    }
}
