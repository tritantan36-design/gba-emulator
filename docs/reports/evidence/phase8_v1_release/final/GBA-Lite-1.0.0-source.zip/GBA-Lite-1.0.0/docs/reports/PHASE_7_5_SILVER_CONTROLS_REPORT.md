# Silver reference-style touch controls

后续已加入[首页/游戏库批量删除](HOME_LIBRARY_BATCH_DELETE_REPORT.md)，最新安装候选
以该报告为准，继续包含本页银灰按键；本页保留视觉补丁的历史验证与SHA。

2026-10-08。用户明确要求按所附银灰手柄图尽量一比一重画方向键及其他按键。
产品提交 `24251d1fa9140cf7e58561345a465f2ad590992c`，包含 `99b3403`。
本轮是前一轮触控补丁的视觉更新，参考范围由用户最新请求确定。

## 实现

- 方向键：窄臂圆角十字、黑色外沿、银灰渐变、中央浅凹圆盘及四向三角凹刻。
- A/B：黑色圆形外沿、上亮下暗的塑料面、浅灰凹刻字母。
- L/R：平直上沿、镜像内侧大圆角、同材质字母与下沿阴影。
- SELECT/START/MENU：小银灰圆钮，下方独立文字。菜单仍有48dp以上触控目标、
  中文无障碍名称和当前速度状态，点击沿用既有暂停入口。
- SilverControlPainter 同时用于游戏、布局编辑器和菜单，无位图依赖或新增资源下载。

没有改布局配置文件、默认坐标/大小/透明度或存档格式。保留旧配置及原有多指、
滑动、斜向、松手、取消事件处理。小圆钮保留原较大的系统键触控目标。
画面背景继续由原显示设置决定；品牌字样、水印与背景图案未加入按键实现。

之前报告中“横屏仅菜单图标”和“系统键呈胶囊形”的外观描述被本次明确请求取代。
横屏40%、竖屏65%新默认透明度仍保留；如要观察参考图的不透明材质效果，
在布局编辑器将透明度调到100%后保存。已有按键位置不会因换皮重置。

## 验证及交付

首批 API34 11/11通过（41.527秒），最终字体版本11/11通过（45.755秒）。
对应原始日志为 `silver-api34-tests.log`、`silver-final-api34-tests.log`。
肩键轮廓最终12/12通过（41.899秒），见 `silver-shoulder-final-tests.log`，不以之前批次冒充。
测试验证整体透明度、预览缩放、银灰中性色、多指输入、暂停及布局保存/重建。
系统圆钮测试同时验证小视觉轮廓与原宽触控区，肩键验证宽轮廓可见且能触发。

普通arm64 Debug/unsigned Release构建与lint通过（肩键最终批次17秒）。
66个独立JVM用例通过；本轮布局/控件变更没有涉及模拟核心。
app lint零错误20警告，feature-player零错误9警告，未关闭检查。
源码/APK审计105项通过；3064文件基线仍只有之前授权的InputProfile默认值不同。
API26/29/36的本次银灰材质未补跑；前一轮API36通过不写成本轮通过。

本机证据目录：`docs/reports/evidence/phase7_5_touch_ui/`。
最终截图在 `silver-final/`，中间版本在 `silver/`；历史失败截图仍标记为失败诊断。
红色画面是合法内部测试ROM；100%透明度截图用于材质参考，不表示默认设置改变。

[最终安装包](evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-silver-controls-debug.apk)
与 [校验值](evidence/phase7_5_touch_ui/manual-handoff/SILVER-SHA256SUMS.txt)。
[实际截图对比](evidence/phase7_5_touch_ui/silver-comparison.html)。
元数据：`silver-candidate-and-evidence.json`。旧候选不覆盖。

Debug SHA256：`9260b4df954c09aa5a2918f88719638028cd0cbbe1081a298cb2dbfce18edc1d`。
unsigned Release SHA256：`ca88b81ecc458ed3d8ce44cd7f5d6f7dc4aa8bbba9409a362315e1c60aaf0b95`。
沿用0.7.5/code8、原开发签名；覆盖安装，不卸载、不清数据。

实机视觉和握持验收为PENDING_USER。历史Phase7缺口保持原状态，Phase7/7.5
NOT_READY；本轮没有推进Phase8。上一轮GitHub TLS阻塞尚未确认解除，本轮不声称远程CI通过。
