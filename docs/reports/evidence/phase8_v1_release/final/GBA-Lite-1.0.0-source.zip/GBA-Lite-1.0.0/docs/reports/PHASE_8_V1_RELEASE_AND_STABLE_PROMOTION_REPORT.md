# Phase 8 V1 Release and Stable Promotion — 2026-10-10

## A. Executive Status

**Phase7 READY；Phase8 COMPLETE；V1.0.0/code14 STABLE（本地正式签名交付）。** 无剩余hard blocker；不等于GitHub/商店已发布。未push、未创建GitHub Release。

## B. Phase7 Authority

以Phase7最终两份权威报告和直接用户反馈为基线，开始前快照保存于`evidence/phase8_v1_release/baseline/`。code13基线/91份冻结输入均核验，Phase7 READY保持，不重开已接受性能/覆盖缺口。初始Git工作区包含已接受但未提交的code9→13变更，全部冻结而非假装等于旧HEAD。

## C. V1 Source Identity

1.0.0/versionCode14，package dev.gbalite.app，minSdk26/targetSdk36，arm64-v8a。V1生产输入manifest SHA256 `985315f45e50acb18914d82d5ab770e82cb4a08439baf09fad21a7f264519956`；覆盖authored main/debug、Gradle/wrapper、许可、Room schemas和官方vendor lock/hash manifests。vendor文件另由105项审计逐文件核验。所有生产输入结束核验一致。[源码身份](evidence/phase8_v1_release/baseline/identity.json)。

## D. Version Promotion

code13→V1仅修改app/build.gradle.kts版本元数据和UnifiedSettings关于标题0.7.9→1.0.0；业务逻辑未改。未升级工具链、未新建功能。先bump，再执行全部本轮gate；code9–13原历史包/证据保存，code13开发包与旧code12 Release另存baseline。

## E. Build Environment

Windows、Temurin21.0.12.1+1、Gradle8.14.3、AGP8.13.0、Kotlin2.2.20、NDK27.2.12479018、CMake3.22.1、SDK36。aapt2检查使用已安装35.0.0（36.0.0包无该exe），签名使用apksigner36.0.0；不改变构建pinned工具链。[环境](evidence/phase8_v1_release/build/toolchain.json)。

## F. Unsigned Release Validation

两次独立clean Release build A/B均PASS；A包括lint及依赖导出，B后另运行final lint并保存XML/HTML。最终lint0 Error/Fatal、5条非阻断Warning，原样保留。unsigned A/B、完整日志、依赖列表保留。Gradle assembleRelease保持unsigned，官方交付通过外部配置apksigner生产签名。

## G. Production Signing

新建长期JKS RSA4096，alias gba-lite-release，有效10000天；密钥与signing.properties仅位于D:/GPT/secure/gba-lite-signing/。目录仅当前账户/SYSTEM可访问，密码高强度随机且只环境传入官方工具，未打印/提交/放入证据。后续版本复用此身份。安全备份尚需用户执行，见[备份指南](PHASE_8_SIGNING_KEY_BACKUP_GUIDE.md)。

## H. Certificate Identity

production证书SHA256 `ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f`，CN=GBA Lite，2026-10-10创建、2054-02-25到期，与历史Debug证书不同。A/B apksigner verify verbose+print-certs PASS，signed manifest/badging身份code14/1.0.0/arm64一致。公钥证书可以复核，私钥不交付。

## I. Fresh Install

新建项目专用GBA_Lite_V1_Release_API36（emulator-5576），干净userdata；正式ARM64包在官方API36 x86_64 ARM转译环境安装Success，冷启动/Home/Library/真实SAF导入PASS。没有卸载/清除主手机Debug；主手机production安装DEFERRED_DATA_PROTECTION。[安装](evidence/phase8_v1_release/install/fresh-install.json)。

## J. Release Artifact Smoke

实际production-signed Build A（与B逐bit一致）：自主bringup.gba Surface红帧；A/B/L/R响应；RIGHT→DOWN无UP连续转换、松手恢复基线；横屏沉浸画面（首次系统Got it提示正常关闭）。1×/2×/4×/回1×、Pause/Home/foreground/Rewind静音恢复音频轨道状态PASS_WITH_NOTE。首次pause即时采样是T stopping排空轨道，随后正常退出；automation倍数按钮自动resume/滚动入口操作更正，无业务改动。AudioFlinger状态不是实听音质/PCM认证，Phase7用户实听反馈保持原scope。原截图/XML/轨道状态及oracle保存于install/。

## K. Regression

最终V1 JVM80 variant结果/71独立方法，0失败；combined test build90 UP-TO-DATE tasks如实记录。host native9/9 PASS，JNI完整18/18 PASS，targeted app9/9 PASS（184.528s）。JNI首次两个模拟器同时运行时2项pacing/rewind计数失败；停止Release游戏后原源码/原断言完整18项PASS（60.112s），两轮日志均保留，未放宽门槛、不删失败、不据此宣称物理认证。Debug回归不冒充正式Release smoke。

## L. Persistence

production Release实际Quick Save/Load、Slot1保存/读取、后台前台、正常退出/冷Continue PASS。自主SRAM fixture持久化32768 bytes（首字节10），退出再冷Continue画面(255,0,82)与退出前一致。BuildA→B同证书同code14重装前后58个files/databases文件hash完全一致，继续游戏恢复一致。首次production无旧版可做版本递增升级，重装路径PASS_WITH_NOTE；不同Debug code14覆盖被INSTALL_FAILED_UPDATE_INCOMPATIBLE拒绝且数据不变。[Battery](evidence/phase8_v1_release/install/battery-smoke.json)、[更新数据](evidence/phase8_v1_release/upgrade/data-preservation.json)。

## M. Security / Provenance

最终Debug14+Release14审计105 PASS；实际signed Release badging及ELF另核验，归档全部vendor源码清单、source lock、运行时依赖清单；无ROM/BIOS/test-provider/instrumentation/sanitizer/wrap泄漏、无ads/analytics/telemetry/cloud/Firebase依赖。测试ROM只推至专用模拟器，没有打包进生产APK。Source archive凭据排除另复核。

## N. Permissions

最终Release merged manifest permissions=[]，无INTERNET/VIBRATE、非debuggable/非testOnly；signed APK身份确认。[权限](evidence/phase8_v1_release/provenance/permissions.json)。

## O. Native Integrity

实际signed Release ARM64 .so动态符号由官方llvm-nm检查：无Debug ForTest JNI exports、无__asan/__ubsan runtime exports；不是用Debug库替代检查。mGBA0.10.5/26b7884bc25a5933960f3cdcd98bac1ae14d42e2、Oboe1.9.3/b15f5e39c01a7ada306d959e5129620b145fb8b4保持官方源。[ELF](evidence/phase8_v1_release/provenance/native-integrity.json)。

## P. Reproducibility

**BIT_FOR_BIT_REPRODUCIBLE**：clean A/B unsigned hash相同，signed APK均为`26b4f57da47aea63daac7ad91fa270dd77820b3c1bcb3cad8f430ccd0ac01659`，entry内容/时间一致，同一生产证书。[结果](evidence/phase8_v1_release/reproducibility/result.json)。

## Q. Licenses

App Apache-2.0、mGBA MPL-2.0、Oboe Apache-2.0及上游内嵌第三方声明保留；APK assets许可与原文件逐字节相同，依赖及vendor inventory归档，不删除NOTICE。Source archive包含第三方源文件及其原许可，满足source-level追溯。[清单](evidence/phase8_v1_release/licenses/inventory.json)。

## R. Debug→Production Migration

签名不同，同package不能覆盖；专用环境实际拒绝验证通过。禁止自动卸载/pm clear用户旧Debug，未执行。当前无完整save/state/library导入导出，不承诺无损迁移。见[迁移说明](../DEBUG_TO_PRODUCTION_SIGNING_MIGRATION.md)。

## S. Release Notes

[发布说明](../RELEASE_NOTES_V1.0.0.md)只列已实现功能；[发布清单](../V1_RELEASE_CHECKLIST.md)固定本轮gate与证据。

## T. Known Limitations

[限制](../V1_KNOWN_LIMITATIONS.md)：8×best-effort、formal ARM未认证ACCEPTED_RISK、API26/29/第二OEM/完整RTC传感器游戏缺口、USB物理未测、Rumble/ASan延期、Phase2历史fixture缺失、API29短黑帧及旧音频异常记录。Release smoke不是实体ARM/多OEM/实听替代，不重开已有接受风险。

## U. Final Artifact Identity

`final/GBA-Lite-1.0.0-code14-arm64-release.apk`；外部交付D:/GPT/artifacts/gba-emulator/v1.0.0/同名文件。APK SHA256 `26b4f57da47aea63daac7ad91fa270dd77820b3c1bcb3cad8f430ccd0ac01659`；certificate `ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f`；source manifest `985315f45e50acb18914d82d5ab770e82cb4a08439baf09fad21a7f264519956`。准确路径/hash及source archive SHA见[最终身份](evidence/phase8_v1_release/final/artifact-identity.json)。生产密钥/密码不随交付。

## V. Source Archive

GBA-Lite-1.0.0-source.zip使用经过验证的源码、许可证、docs、Gradle wrapper及vendor；排除build/.gradle/.git/local.properties/keystore/signing.properties/.env、私有数据和临时evidence。archive allowlist/secret scanning/file hashes保存final/；历史自有合法test fixtures按仓库测试策略保留，与APK不含ROM的边界区分。

## W. Git / Tag

发布前已有受验收的未提交改动；以冻结manifest确认无未知生产差异。所有gate完成后创建本地release commit与tag v1.0.0，真实HEAD/tag/status/diff记录在final/git-state.json。未push、未创建GitHub Release；不把旧HEAD当最终V1源码。

## X. Stable Readiness Matrix

|项目|状态|范围/证据|
|---|---|---|
|V1 source identity|PASS|code14/1.0.0；冻结manifest无drift|
|Release build|PASS|clean A/B及final lint，0 errors|
|Release native|PASS|实际Release ELF/native allowlist|
|Signing key|PASS|长期RSA4096外部安全配置|
|Signature verification|PASS|apksigner A/B；Debug证书不同|
|Fresh install|PASS_WITH_NOTE|全新API36 ARM转译模拟器；主手机延期保护数据|
|Launch|PASS|真实冷启动|
|ROM import|PASS|真实SAF两个自主fixture|
|Renderer|PASS|真实Surface、输入色彩oracle|
|Input|PASS|Release A/B/L/R、RIGHT→DOWN、松手恢复|
|Audio|PASS_WITH_NOTE|Release轨道状态；不认证实听质量|
|FF audio|PASS_WITH_NOTE|2×/4×/回1×/Rewind输出状态|
|Persistence|PASS|Release Battery/Quick/Slot/Continue|
|Background/foreground|PASS|实际Home及恢复输出|
|Provenance|PASS|105检查+signed artifact独立检查|
|Permissions|PASS|[]；非debuggable/testOnly|
|Licenses|PASS|原许可/NOTICE/vendor源保留|
|Reproducibility|PASS|BIT_FOR_BIT_REPRODUCIBLE|
|Migration note|PASS|签名冲突真实拒绝；无主手机数据操作|
|Source archive|PASS|排除秘密/临时输出并校验|
|Final APK hash|PASS|A/B/交付副本一致|
|Release notes|PASS|仅已实现功能|
|Known limitations|PASS|接受风险/覆盖缺口保持透明|
|Git/tag status|PASS_WITH_NOTE|本地release commit/tag；未对外发布|

## Y. Hard Blockers

**NONE。** 无生产业务变化、未知source drift、安装/导入/黑屏/native crash/音频输出失效/存档损坏/签名/权限/许可hard blocker。JNI初次负载失败、AudioFlinger排空采样及UI automation更正有完整记录，不删除或冒称首次全通过。

## Z. Final Decision

**Phase7 READY；Phase8 COMPLETE；V1.0.0/code14 STABLE。** 本地正式签名交付，不自动外部发布。后续正式版继续使用固定签名身份，密钥备份REQUIRED；若Release出现相关回归或身份/源码漂移则重开对应gate。主手机Debug数据保留，正式安装迁移边界必须遵守。
