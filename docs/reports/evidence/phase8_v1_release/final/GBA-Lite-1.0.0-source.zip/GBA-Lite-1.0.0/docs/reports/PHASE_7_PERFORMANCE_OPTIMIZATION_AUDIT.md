# Phase 7 Performance Optimization Audit — 2026-10-09

Phase A complete before any production edits. Frozen baseline0.7.5/code9 and97 source/build/lock files captured in evidence/phase7_performance_optimization/baseline.json and code9-source-snapshot. Existing dirty code9 changes preserved, no reset.

The task document contains stale context: code9 physical A/B was already executed (192rows) and viewport matched; the final result remains BLOCKED_ENVIRONMENT due predeclared temporal variance. This round defers new physical A/B. Human >40min stability/basic storage/exit progress is retained; not extended to exact45min or audio/hardware PASS.

## A/B Compose root and input state

**Suspect / evidence:** Player.kt:44–94, PlayerViewModel.kt:76–90.

**Observed:** No frame/FPS/audio-stat MutableState assignment in Player. Sensor polling writes peripheralDetected; equal Int writes are suppressed. Touch pressed state stays in native View. Slots StateFlow changes on persistence, not every frame.

**Measured/observed boundary:** Static observation; no runtime recomposition count collected, so no claim of measured reduction.

**Recommended change:** DO NOT CHANGE Compose state scopes.

**Risk / expected impact:** Low confidence of root-recomposition waste; no visual/scope changes justified.

## C Hidden overlays

**Suspect / evidence:** Player.kt: conditional menu/editor/settings/manualPanel branches and produceState inside save/load branch.

**Observed:** Pause/settings/editor content exists only while its branch is active. Thumbnail decoding runs only while save/load content is composed, on IO; no screenshot polling. Touch feedback animation runs for 100ms on pressed-state changes.

**Measured/observed boundary:** Static scope/lifetime observation; no hidden UI timer identified.

**Recommended change:** DO NOT CHANGE hidden UI.

**Risk / expected impact:** Keep overlay disposal and save/feedback behavior.

## D Viewport/measure

**Suspect / evidence:** Player.kt:100–121; OriginalSurface.onSurfaceTextureSizeChanged; code9 physical review.json.

**Observed:** Portrait TextureView has width and aspectRatio(1.5), landscape fillMaxSize; safe insets retained. Actual continuous physical OLD/CODE9 matrix had identical x367/y0/1620x1080. Earlier translated runs had 1035x690 vs1080x720 and differed in window/inset/layout conditions; not reproduced under matched physical conditions.

**Measured/observed boundary:** Physical viewport equality is measured; exact historical mismatch cause not established.

**Recommended change:** DO NOT CHANGE internal buffer or visual dimensions.

**Risk / expected impact:** Would risk Sharp/LCD/integer semantics without proven benefit.

## E Renderer invariant GL setup

**Suspect / evidence:** OriginalSurface.kt: DisplayRenderer.onDrawFrame and applySettings.

**Observed:** Each draw repeats glViewport/useProgram/activeTexture/bindTexture/sampler uniform/two vertex pointers/two enables (+outputSize when present), while GL context, settings, dimensions and vertices are unchanged. Only this renderer owns GL state on its HandlerThread; applySettings, surfaceChanged, inject and context creation are explicit invalidation points.

**Measured/observed boundary:** 9 invariant GL calls per draw, or 10 with outputSize; static call count, not an FPS attribution.

**Recommended change:** MOVE invariant setup to existing applied-settings boundary.

**Risk / expected impact:** High confidence, low risk if lifecycle/fallback/resize tests pass; removes repeated JNI/driver state traffic without changing draw or presentation.

## F Pacing / duplicate frames

**Suspect / evidence:** OriginalSurface.kt draw runnable, EGL swap interval 1; FrameSource single copyFrame API.

**Observed:** One Choreographer callback drives render and swaps. Emulator pacing is separate at requested emulation speed; display pacing is expected. FrameSource exposes no frame sequence, so identical source contents or pause state cannot be safely treated as unchanged without extra copying/API changes.

**Measured/observed boundary:** No measured redundant scheduled callback chain or double-throttle root cause.

**Recommended change:** DO NOT CHANGE scheduling, swap interval, frame submission or upload.

**Risk / expected impact:** Avoid stalls/black frames and API changes; settings state caching only.

## G Fast-forward audio

**Suspect / evidence:** mgba_bridge.cpp: native loop; audio_output.cpp; pcm_ring.h.

**Observed:** PCM buffer reused; reads bounded to2048 samples; audio ring4096 stereo frames; push only at speed==1, FF stops output stream. Draining blip audio during FF preserves core audio state.

**Measured/observed boundary:** No duplicate push/copy of all fast-forward audio into Oboe identified; Debug per-nonzero-sample atomic hook is instrumentation overhead, absent Release.

**Recommended change:** DO NOT CHANGE Audio/core drain behavior.

**Risk / expected impact:** Changing synthesis/drain would risk FF→1x or State sound restoration; native/Oboe remain frozen.

## H IO/persistence

**Suspect / evidence:** EmulatorSession checkpointLocked/captureLocked; PlayerViewModel45s timer; PlayerImages.

**Observed:** Checkpoint transitions pause, persists Battery before State and metadata, resumes on success; runs IO dispatcher under Session mutex. Thumbnail PNG allocated only for state/checkpoint or explicit screenshot, not per frame. Periodic45s checkpoint is existing contract.

**Measured/observed boundary:** IO occurs on intended transitions/explicit saves, no per-frame Room/DataStore or PNG encoder identified.

**Recommended change:** DO NOT CHANGE scheduling, lock scope or atomicity.

**Risk / expected impact:** Save reliability and Battery/State semantics outrank unmeasured optimization.

## I Threads/locks

**Suspect / evidence:** Core::loop control_/frameMutex_; MgbaCoreAdapter @Synchronized; Session Mutex; PCM SPSC atomics.

**Observed:** Renderer copies under frame mutex; core metrics/peripheral JNI holds control mutex briefly but contends with emulation; a50Hz sensor loop makes several diagnostic calls. Sample metrics allocations observed statically; elapsed lock contention not measured.

**Measured/observed boundary:** Potential cost, not proof of dispensable sensor/control work.

**Recommended change:** DO NOT CHANGE locks, sensor sampling or Session.

**Risk / expected impact:** Contract risk; no removals or shared cache that could hide stopEpoch/rewind transitions.

## J Metrics/logging/allocation

**Suspect / evidence:** Renderer DEBUG guards; MgbaCoreAdapter/JNI metrics; TouchControls.geometry/onDraw.

**Observed:** No Release per-frame Log/JSON/file output. Renderer glFinish once/120draws is Debug diagnostic, not Release; kept to preserve diagnostics. Touch geometry pairs/Triples and debug metrics arrays allocate; no measured GC spikes.

**Measured/observed boundary:** Debug/instrumentation is not unsigned Release performance.

**Recommended change:** DO NOT CHANGE diagnostics/allocations without profiling.

**Risk / expected impact:** Record overhead and retain comparable instrumentation.

## Touch identical setters

**Suspect / evidence:** TouchControls.kt profile/previewWidth/selectedKey setters; Player AndroidView.update and preview update.

**Observed:** Assigning unchanged immutable-value profile, previewWidth or selectedKey always invalidates View. Player update assigns two of them together for unrelated menu feedback state; no drawing property changes in equal assignments.

**Measured/observed boundary:** Exactly two avoidable invalidations per unchanged Player update (profile+selected); previewWidth separately. No evidence of idle Compose loop.

**Recommended change:** Equality guard these setters.

**Risk / expected impact:** High confidence, low risk; changed values still invalidate; editing/pressed visuals and routing untouched.

## Audit gate

Only invariant GL state setup and equal-value TouchControls invalidation meet the high-confidence, behavior-preserving gate. No UI redesign, no pacing/frame sequence/API changes, no native/audio/session/storage/input/sensor changes. Preserve shaders, dimensions, all original formal gates, debug GPU sample semantics and all historical failures. New production edits require0.7.6/code10 and separately archived packages.

Before/after emulator characterization and screenshots use frozen code9/new candidate on the same project-owned API36 software-rendered translated emulator. They are directional signals only; samples and environmental limitations will be retained. Subsequent targeted Surface/lifecycle/fallback/scale/input/State/audio tests must pass; any listed behavioral hard-stop causes rejection and rollback of this round only.
