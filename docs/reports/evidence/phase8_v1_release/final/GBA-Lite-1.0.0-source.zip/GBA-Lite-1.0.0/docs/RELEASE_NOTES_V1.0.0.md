# GBA Lite 1.0.0 — Release Notes

VersionCode14，基于Phase7已冻结并人工验收的code13；仅提升版本元数据，无业务逻辑变更。最终Stable判定以Phase8报告为准。

- GBA-only、离线，mGBA0.10.5核心；SAF导入.gba与受支持的单ROM.zip，游戏库与搜索/批量删除。
- 游戏内Battery存档、Quick Save/Load、4个手动即时存档、退出自动保存与Quick Resume。
- 快进2×/4×/8×（8×尽力模式）、倒带；连续方向键、触控布局及HID输入。
- Original/Sharp/GBA Color/LCD显示模式，Fit/Integer，横屏沉浸显示与竖屏游戏机外壳。
- RTC、运动/光照适配与回退有实现；完整游戏兼容范围有限。截图保存在应用私有目录。
- 零网络权限、零遥测；不提供ROM或BIOS。App Apache-2.0、mGBA MPL-2.0、Oboe Apache-2.0，许可随包附带。

正式签名不同于旧Debug签名；安装前阅读[迁移说明](DEBUG_TO_PRODUCTION_SIGNING_MIGRATION.md)和[已知限制](V1_KNOWN_LIMITATIONS.md)。
