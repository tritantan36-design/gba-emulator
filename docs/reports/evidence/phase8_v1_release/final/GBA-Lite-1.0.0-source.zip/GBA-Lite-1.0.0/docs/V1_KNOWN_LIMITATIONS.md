# V1 Known Limitations

- 8×快进是best-effort，快进音频不保调；实际机器性能不足时可欠供。
- 正式物理ARM性能A/B未认证：用户明确停止并接受风险，实际反馈无明显卡顿、掉速或异常发热；不是客观性能提升证明。
- API26/29真实ARM、第二OEM未验证；API29历史短黑帧继续监测。
- USB物理覆盖不完整，合成HID不是物理USB验收；实体Rumble按V1零权限政策延期。
- 完整ASan/full-dependency sanitizer/fuzz覆盖延期；targeted UBSan旧证据继续有效。
- RTC/传感器有host/JNI/probe/fallback证据，完整游戏兼容性有限。
- 历史Phase2原始State资产不可用，沿用已接受风险；现代存档路径通过。
- 1×旧初轮34 underrun后续未复现，根因未确认；用户音频专项已通过，不将旧异常删除。
- Debug→Production签名不同，不能同包覆盖安装；当前没有完整存档/即时存档/游戏库导入导出迁移功能。
- Production主手机安装为DEFERRED_DATA_PROTECTION；正式包安装smoke使用全新API36 x86_64模拟器的ARM64转译，不能外推物理ARM/多OEM或音质实听认证。
