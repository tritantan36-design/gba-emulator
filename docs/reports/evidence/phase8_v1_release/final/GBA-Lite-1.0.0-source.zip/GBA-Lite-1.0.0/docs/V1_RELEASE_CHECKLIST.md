# V1 Release Checklist — 1.0.0/code14

Phase7 READY、Phase8 COMPLETE、V1 STABLE。正式交付gate完成，详见[Phase8权威报告](reports/PHASE_8_V1_RELEASE_AND_STABLE_PROMOTION_REPORT.md)。

- [x] code13冻结核验；只提升版本与About元数据，V1源码manifest冻结。
- [x] 两次clean Release +最终lint0 errors；正式签名/证书/身份验证。
- [x] 全新专用环境fresh install、实际SAF/Surface/Input/Audio/FF/Persistence/生命周期smoke。
- [x] 最终JVM80、host9、JNI18、targeted app9通过；失败/复测日志保留。
- [x] 105项审计、权限[]、Release ELF/test隔离/来源/许可核验。
- [x] Signed A/B BIT_FOR_BIT_REPRODUCIBLE；APK及source manifest哈希固定。
- [x] 迁移说明、已知限制、发布说明、密钥备份指南；源码归档排除secrets。
- [x] 本地release commit/tag，实际Git记录留证；未push/创建GitHub Release。
- [ ] 用户将keystore+signing.properties备份到至少两个独立安全位置（发布文件不含这些秘密）。
- [ ] 主手机production安装：DEFERRED_DATA_PROTECTION，不自动卸载旧Debug。
