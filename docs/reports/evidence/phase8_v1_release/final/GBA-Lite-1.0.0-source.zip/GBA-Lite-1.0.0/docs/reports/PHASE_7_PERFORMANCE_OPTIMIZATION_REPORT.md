# Phase 7 Performance Optimization Report — 2026-10-09

> 历史专项候选报告：当前Phase7状态 superseded by [Final Consolidation权威](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)（2026-10-10，code13）。下方原候选结果/失败/哈希保持，不代表当前版本重新测试或人工通过。

本轮审计、最小修改及功能回归已完成，生成独立 **0.7.6 / code10** 候选。**功能回归 PASS；模拟器方向信号 MIXED，未证明吞吐改善或整体中性；Physical ARM A/B PENDING；Phase7 NOT READY。** 不将本轮描述为“性能已修复”，也不将理想成功链中的性能条件改写为 PASS。

## A. Baseline

冻结0.7.5/code9 两包、既有报告及用户 >40分钟稳定游玩、基本存储和退出保留进度反馈。修改前保存97份生产源码/构建/依赖锁快照及哈希；93份保持不变，只有下列四份生产文件变化。此前工作区已有修改保留，没有 reset。证据位于 `evidence/phase7_performance_optimization/`。

Code9 Debug SHA256：`96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`；unsigned Release：`b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`。本轮未覆盖这些归档。

## B. Scope

仅处理明确、可局部证明的重复 GL 状态设置，以及 TouchControls 相同值 setter 的无效 invalidate。UI冻结，无布局/配色/图标/按键手感改动。版本及 About 元数据同步更新。先完成 [审计](PHASE_7_PERFORMANCE_OPTIMIZATION_AUDIT.md) 和 code9 同条件模拟器采样，再改生产。

## C. Current Performance Uncertainty

任务文档“真机未执行”的上下文已过期：code9此前真实 ARM192单元已完成，视口匹配，预设秒级CV条件未满足，分类仍 BLOCKED_ENVIRONMENT。不能据此认定 code9 回归。本轮不重复物理 A/B，也不触碰用户手机、私有备份或真实游戏/存档。

## D. Compose Audit

Player 没有按帧/FPS写入根 Compose MutableState；按键反馈保存在 View。没有运行时重组计数证据，**不声称根重组减少**。AndroidView.update 会重复赋同一 profile/selectedKey，原 setter 无条件 invalidate，代码路径明确。新增相等值守卫减少此路径重绘请求；编辑标志变化自身 invalidate，保留编辑轮廓刷新。

## E. Hidden Work Audit

暂停/设置/编辑器条件分支只在显示时组合，存档缩略图 IO 解码属于可见存读档分支，没有发现隐藏全屏 UI 轮询。100ms触控反馈动画保持。

## F. Viewport Audit

没有改变 viewport、缩放、TextureView尺寸或画面位置。模拟器前后16组合均 x360/y0/1620×1080；历史真机 code9 x367/y0/1620×1080。此前转译模拟器视口异常没有确证根因，未借此修改生产。Fit/Integer、四种显示模式及旋转实际画面回归通过。

## G. Renderer Pacing Audit

独占 EGL context 的 HandlerThread 上，program/texture/sampler/vertex pointers/enables/viewport/outputSize 设置在稳定帧重复。移到既有 applySettings 失效边界；settings、resize、fault、context recreation 仍重新设置。每个稳定 draw 减少9个重复 GL调用，有 outputSize 时10个。计数来自源代码，不是 GPU profiler 测量。

每帧 copy/upload、clear/draw/swap、Choreographer、swap interval 完全保持。FrameSource 没有序号，未跳过“重复帧”或增加 API；未改变高倍率 pacing。

## H. Metrics/Logging Audit

Debug 每120draw 的 glFinish 诊断和 JNI metrics 保持。它们可能影响调试测量，但当前无隔离因果证据，本轮不删日志、改 Debug门槛或把 Debug采样换算成 Release结果。

## I. Audio Audit

Audio/native 未修改。现有 PCM复用缓冲、ring4096、高倍率 drain 和回到1×恢复保持。没有证明 FF合成可安全省略，未优化音频采样、路由、Oboe callback、ring容量或音质。五次非零PCM/played增量恢复检查通过，人工听音仍未单独确认。

## J. Thread/Lock Audit

Session/Core/native锁、sensor50Hz轮询、生命周期契约未修改。没有采集锁等待分布、GC或 contention证据，未重构锁/线程或减少传感器更新。

## K. IO/Persistence Audit

没有每帧数据库或PNG写入路径；autosave45秒和可见缩略图 IO 调度保持。Save/Battery/State格式、Room schema3、DataStore、导入校验/ZIP/provenance保持。未合并checkpoint、推迟必要落盘或更改atomic写入。

## L. Implemented Optimizations

|生产文件|变化|
|---|---|
|renderer/src/main/java/dev/gbalite/renderer/OriginalSurface.kt|重复 GL状态初始化移至已有失效边界|
|feature-player/src/main/java/dev/gbalite/player/TouchControls.kt|profile/previewWidth/selectedKey相等值不 invalidate；editing变化自行刷新|
|app/build.gradle.kts|0.7.6 / versionCode10|
|app/src/main/java/dev/gbalite/app/UnifiedSettings.kt|About版本文字同步|

另有**测试专用** `PlayerExperienceTest.kt`：旧测试等待 Text“菜单”，但 code9菜单已经是 Canvas 的 contentDescription及stateDescription。冻结 code9对照复现同一入口超时，保留失败日志；测试改用既有 player-menu tag及倍率stateDescription，速度、hold/release、倒带、后台断言全部保留。没有为迎合测试更改生产UI。

## M. Rejected/Deferred Optimizations

Compose scope重构、实际帧去重、viewport调整、renderer pacing、Debug GPU统计删除、音频 synth/drain调整、sensor轮询/锁重构、autosave/缩略图调度均因证据不足或行为风险未修改。mGBA0.10.5/Oboe1.9.3 vendor内容通过原官方清单审计；Core API、Audio、Session及安全边界不变。

## N. Regression

|检查|结果及证据|
|---|---|
|完整 JVM|75份用例结果 PASS：common57、Debug9、Release9；66个不重复方法。Gradle部分未变任务 UP-TO-DATE，未冒称全部重新运行。build-jvm.log/jvm-release.log/jvm-common.log、integrity-jvm-summary.json|
|Host native|audio1 + core7 =8 PASS；host-native.log|
|JNI|17 PASS，含倍率pacing、RTC/传感器、Battery/State、生命周期和倒带；regression/jni.log|
|API36 Activity / ZIP / library|4 PASS；regression/activity-zip.log|
|Actual Surface|四模式、Fit/Integer、24旋转组合、后台/EGL恢复/重建、shader compile/link/setup fallback、Sharp/LCD pattern/raw截图 PASS|
|Touch / UI|多点/滑动/斜向、编辑选中、横屏编辑工具可操作、暂停/外部恢复、横屏紧凑菜单 PASS|
|Persistence / FF / Rewind|Quick+1–4槽、Battery后台/重建/退出继续、2/4/8×、hold/release、倒带松手及后台 PASS；旧选择器失败和code9对照独立保留，修复后重测PASS|
|API36应用回归合计|上述13项原批次通过 + FF重测1 =14 PASS，不把旧失败计成通过|
|游戏/声音恢复短测|Hyperspace Roll已审计官方SHA；60秒游戏循环、100次输入、实际非黑Surface，五次PCM恢复 PASS；不是新长测/人工听音/游戏通关证明。regression/gameplay-result/result.json|
|API29 targeted|x86_64 compat TEST_ONLY：5次SAF打开/存读档/旋转/Home/恢复/退出循环及PCM暂停恢复，2测试 PASS；api29/result.json。不称物理ARM覆盖|
|APK / provenance|105 PASS；permissions=[]，无ROM/ZIP/BIOS/test-provider/sanitizer进入交付包，依赖/vendor/许可证清单保持；apk-provenance-audit.md|

本轮未发现 hard-stop 产品回归。旧Text selector错误是 code9可复现的测试定位问题，不是黑屏/ANR/粘键/音频永久失败，故没有回退生产修改。没有放宽产品性能门槛。

## O. Performance Directional Result

同一 API36软件图形、同一测试probe SHA、landscape/Fit/Black，code9→code10各16组合，1秒预热/3秒单元，全部原始数据保留。**7组合上升、9组合下降；MIXED_DIRECTIONAL_SIGNAL / NO_RELIABLE_THROUGHPUT_IMPROVEMENT_ESTABLISHED。** 原采样公式布尔值前后均8/16；4/8×在转译模拟器未达门槛，不改为PASS。

例如 Original1×51.06→59.94fps，Original4×99.57→138.43；Sharp4×128.41→115.32，GBA Color2×113.41→103.52，LCD2×117.72→110.60。单次短采样、Debug及ARM转译使其只提供方向参考；未作重复配对或显著性检验。不能确认收益，也不能由其判定物理 ARM回归。[全部16单元](evidence/phase7_performance_optimization/directional-comparison.json)。

前后portrait/landscape/player/pause截图保存。相同尺寸、选定UI区域排除系统时钟/动态游戏，以RGB差>4比较，差异像素0；不是整图逐像素一致证明。[抽样对比](evidence/phase7_performance_optimization/ui-comparison.json)。

## P. Candidate Identity

两份候选独立保存在 `evidence/phase7_performance_optimization/candidate/`，不替换code9。

|候选|字节数|SHA256|
|---|---:|---|
|GBA-Lite-0.7.6-performance-code10-debug.apk|19844074|5f2a5d93b499cd363b80cffdf42f31e91a0f078a934a45446e2fe9dc65216418|
|GBA-Lite-0.7.6-performance-code10-release-unsigned.apk|16420751|3de879ea549a7dd5fef767869470b27af3b6d4e03d1a9814fe171008da759abe|

Debug沿用开发证书 SHA256 `3660dfb189306e49d973a7f91c9cbc1cb35cc93921f0292e8db28b3fa10b4094`。Release UNSIGNED，无production keystore/AAB/商店发布；API29 compat包只作测试。code10分类 **FUNCTIONAL_REGRESSION_PASS / PERFORMANCE_UNQUALIFIED**，不替代已人工通过的稳定code9。

## Q. Remaining Risks

实际性能改善没有被证明；缓存GL状态依赖renderer独占上下文，后续若加入其它GL使用者需重新审查失效边界。现有生命周期/fault覆盖通过，不等于覆盖所有设备驱动。真机多OEM/API26/29 ARM、实体USB/rumble、完整RTC/传感器游戏及正式音质专项原缺口继续保留；不扩大既有人工反馈。

## R. Physical ARM Status

**新code10 Physical ARM A/B = DEFERRED_BY_USER_FOR_NEW_CANDIDATE / PENDING。** 建议以后使用匹配viewport/ROM/亮度/路由、重复且控制温度的code9/code10真实ARM配对测试；本轮不启动。code9此前192单元及CV阻塞证据完整保留。用户>40分钟反馈继续算code9人工通过，不能自动转移为code10通过。

## S. Phase7 Status

审计/最小优化/构建/功能回归/证据整理 **COMPLETE**；理想“方向改善或中性”尚未成立，因此整体优化收益 **INCONCLUSIVE**。**Phase7 NOT READY；Performance既有技术分类 BLOCKED_ENVIRONMENT；code10性能未认证；Phase7.5 code9 USER_CONFIRMED_PASS / READY；Phase8 NOT STARTED；V1 Release NOT READY。**

本轮可以交付功能通过的待性能验收候选，不宣称code9慢、性能修复完成、正式性能PASS或Phase7最终关闭。
