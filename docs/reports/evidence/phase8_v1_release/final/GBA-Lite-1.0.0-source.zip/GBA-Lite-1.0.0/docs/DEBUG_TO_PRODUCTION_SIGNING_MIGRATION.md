# Debug → Production Signing Migration

旧开发包与V1正式包的package均为dev.gbalite.app，但证书不同。Android会拒绝直接覆盖安装；这是正常签名保护，不是APK损坏。

**不要为安装V1直接卸载现有Debug或清除其数据。** 卸载/清除可能删除游戏库元数据、Battery存档、即时存档、截图、设置和应用私有复制的ROM。SAF原文件仍在并不代表存档得到备份。

当前产品没有完整save/state/library导入导出迁移功能。Phase8没有临时添加迁移能力，也不承诺能无损迁移。保留现有Debug应用，在空白备用设备或干净模拟器体验正式包；本轮未卸载/清除主手机，主手机production安装延期保护数据。

如以后确需迁移，先为实际设备建立并验证可靠备份及恢复方案，再由用户明确授权处理旧安装。不要假设Android通用备份或单纯复制ROM能够保存全部进度。

首次装好正式版后，未来同签名且版本号递增的正式版可正常更新；production keystore必须长期安全保存。
