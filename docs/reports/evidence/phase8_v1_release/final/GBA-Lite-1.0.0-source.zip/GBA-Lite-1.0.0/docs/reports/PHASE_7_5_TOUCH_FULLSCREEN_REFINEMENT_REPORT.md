# Phase 7.5 Touch & Fullscreen Refinement — 2026-10-09

> 历史专项候选报告：当前Phase7状态 superseded by [Final Consolidation权威](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)（2026-10-10，code13）。下方原候选结果/失败/哈希保持，不代表当前版本重新测试或人工通过。

**实现及本任务功能回归完成；READY_FOR_EMULATOR_PREVIEW / MANUAL_ACCEPTANCE_PENDING。** 本轮只处理横屏全屏及方向键连续输入。按用户“先展示模拟器、同意后再打包”的要求，只有开发测试包，没有生成交付APK或code11 Release。补充JNI pacing检查两次未达转译模拟器阈值，原始失败保留，不能宣称全套自动检查全部通过。

## A. Scope

MainActivity统一系统栏生命周期；Player横屏控制层采用精确安全区；TouchControls新增按pointer保存的方向状态；input模块新增纯函数ContinuousDpad及单测。mGBA、Core API、Session、Renderer pipeline、Audio、Save/State、Game ID、Room/DataStore、ZIP校验、权限、依赖、视觉主题及Pause/Settings信息架构未改。

版本元数据与About同步为 **0.7.7/code11**。code10已被性能候选占用，不复用其身份。新增测试只验证本任务行为，不放宽原性能或存档断言。

## B. Baseline

code9的用户真机通过记录及归档保持；code10两份性能候选、哈希和报告保持。修改前六份直接涉及文件快照见 `evidence/phase7_5_touch_fullscreen/code10-source-snapshot/`、baseline.json。本轮以包含code10最小优化的当前源码为基线，不重复调整Renderer性能逻辑。

检查发现：MainActivity原本已经执行横屏hide(systemBars)、edge-to-edge及cutout模式，并非完全未实现沉浸；控制层和MENU仍使用safeDrawingPadding，且effect销毁会主动show系统栏。D-pad确实按十字形排除角落，独立方向阈值造成输入空挡。

## C. Landscape Fullscreen

保留WindowCompat.setDecorFitsSystemWindows(false)和横屏Player专用systemBars hide，使用BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE。foreground进入effect依赖，返回前台重新应用；effect切换不再先show再hide，避免Player内部状态变化时系统栏闪回。退出Player、竖屏和普通设置页面由下一effect正常show，未将全App改为fullscreen。

横屏Surface继续fillMaxSize，无系统栏padding。自动验证landscape/reverse landscape status和navigation不可见，Surface宽高等于decor窗口，Pause可操作并恢复、竖屏状态栏恢复。普通Activity打开及recreate回归通过。

## D. Insets / Cutout

保留API30+ALWAYS/API28–29 SHORT_EDGES的既有cutout策略。只有横屏TouchControls和MENU从safeDrawing改为displayCutout∪mandatorySystemGestures；背景与Surface full bleed，必要按钮避让保留。普通页面及竖屏padding未修改。

自动临时show系统栏后，Surface与触控层bounds均保持；再hide恢复。此项验证由controller直接触发，不冒称实际边缘swipe/自动超时经过人工验收。

项目API36模拟器分别完成：默认手势导航、模拟hole cutout+手势导航、模拟hole cutout+三键导航，每环境均横屏/反向横屏通过。模拟器overlay原状态已恢复。不是实体挖孔硬件或全OEM驱动证明。

原API36横屏Surface2340×1080、Fit viewport x360/y0/1620×1080；本轮log和实际Surface验证仍同尺寸同viewport。改善主要在系统栏生命周期与控制层安全区，不虚报Surface扩大。四模式、Fit/Integer、24旋转组合actual color回归通过，保持3:2及无stretch/crop。

## E. D-pad Resolver

保持SilverControlPainter、视觉十字大小/位置/银灰材质/凹刻及按压表现。触控采用当前几何中心和半宽归一化的单一连续区域，方形bounds各轴扩15%，透明角落现在可输入斜向；不绘制隐藏命中区。

atan2按Android Y向下分为8个45°sector。输出RIGHT→RIGHT+DOWN→DOWN，另外七条正反转向同样连续。保留既有InputRouter按聚合状态差分更新，不重复释放/按下仍持有的RIGHT或其他按钮。

## F. Dead Zone / Hysteresis

首次中心半径12%为NONE；已有方向在中心最多保持80ms，离开中心马上解析新向量。View延迟任务在驻留到期时释放方向，即使没有新MotionEvent也不会无限保持。UP/CANCEL、失焦、关闭输入会取消延迟任务并清空状态。

sector边界加入7°迟滞。JVM覆盖所有8个中心角、边界±0.1°及迟滞±0.1°、正反连续过渡、中心穿越/80ms超时、越界和非法数值、差分事件。不是四个重叠矩形按键。

## G. Multi-touch

D-pad仅接受在命中区ACTION_DOWN/POINTER_DOWN开始的pointer，其状态按source独立保存；A/B/L/R等可见按钮在区域冲突时优先命中，D-pad不从其他pointer夺权。已有方向pointer越出区域释放，松手/取消/缺失pointer/失焦清除。

仪器测试覆盖RIGHT→DOWN同时A、B、L、R，以及A+B两指保持；抬起方向pointer只释放方向，保留另一个按钮。所有八条转向、四斜向、整圈旋转和多点路径无NONE空挡、无残留。trace保存在continuous-dpad-traces.txt。

Player暂停/编辑器/后台通过acceptingInput关闭触控并清空pointer状态，恢复后必须新落指才能接管D-pad。方向已按住时关闭输入、失焦、CANCEL及松手均有直接自动断言；既有Pause和实际Home音频/Surface恢复回归通过。

## H. Layout Editor Compatibility

编辑器保留原选中/拖动命中方式；连续游戏命中区由当前profile的中心/size和View尺寸计算，未写死屏幕坐标。profile变化会释放旧游戏pointer状态；编辑拖动自身不被这个释放打断。横屏编辑工具不遮挡预览、拖动、保存、重新打开回归通过。schema及横竖屏独立profile格式未改变。

## I. Automated Tests

|检查|结果|
|---|---|
|JVM full / Input|79份结果PASS：common61、Debug9、Release9；70个不重复方法，含新增4个resolver方法。部分未变Gradle任务UP-TO-DATE|
|Activity|3测试PASS|
|D-pad instrumentation|原十字测试按新透明角落斜向要求更新；8条过渡、4斜向、多点、中心穿越、失焦等PASS；扩展整圈/A+B复测PASS|
|Fullscreen|默认、hole+gesture、hole+threebutton各横屏/反向横屏PASS；Surface和controls临时系统栏bounds稳定|
|Player / Pause / Editor|暂停恢复、横屏compact、编辑器拖动/保存PASS|
|Actual Surface / Orientation|四模式、Fit/Integer、24组合旋转、EGL/生命周期/颜色PASS|
|Background / Save / State|实际Home暂停恢复，Battery、后台recreate、Quick+四槽、退出继续PASS|
|APK / provenance|105项PASS；当前Debug为code11开发包；检查使用的现有unsigned Release仍为code10，不代表已构建code11 Release|
|Host native全量|复用上一轮8项PASS；所有native库与code10逐字节一致|
|补充JNI smoke|核心启动/输入/释放PASS；pacing4×两次FAIL，213.37fps及206.28fps，原门槛保持，未改为PASS|

主要功能批次11项通过；另保存扩展D-pad、截图及三种系统栏环境复测日志。初次构建有跨模块nullable属性smart-cast编译错误，改为局部val后Debug/Release Kotlin及全部JVM检查通过；保留初次日志。

## J. Screenshots

证据目录：`docs/reports/evidence/phase7_5_touch_fullscreen/`。

- landscape-fullscreen.png
- reverse-landscape-fullscreen.png
- dpad-normal.png
- dpad-diagonal-pressed.png
- cutout-gesture/、cutout-threebutton/同名截图

已查看横屏、斜向按压和模拟挖孔三键导航截图。粉色游戏区域是项目合法持久化测试probe的输出，非用户ROM、非界面背景改色。测试截图保持既有银灰按键及掌机主题。

## K. Regression

本任务列出的黑屏、Surface裁切、触控偏移、系统栏恢复循环异常、方向粘键、A/B失效、斜向丢失、Pause/后台方向残留及编辑保存失败均未在上述测试中发现。实体机部分待用户验证，不自动继承code9人工通过。

补充JNI4×pacing两次失败独立保留于jni-smoke.log和jni-pacing-isolated-retry.log。关闭另一个项目模拟器再试仍失败，故不能宣称“减负解决”。这些测试运行在未重建的core-mgba独立instrumentation包中，不执行本轮Player/D-pad；交付Debug所有native库与code10逐字节一致。本轮未改pacing逻辑，当前根因未确认，记录 **TRANSLATED_EMULATOR_PACING_UNRESOLVED**，不据此声称物理性能回归或通过。Phase7既有性能阻塞继续保留。

## L. Candidate Identity

源码/开发包身份 **0.7.7 / code11**，开发Debug SHA256 `8fd99cd4b9c1474aafb1707953e9102383895fefa5c4ac3d0d19ff90adfa7015`。该包只用于项目模拟器测试，不作为交付归档。code11 Release和交付包尚未构建，待用户查看效果同意后再打包。code9/code10归档不覆盖，不创建production keystore/AAB/商店发布。

## M. Manual Acceptance

**PENDING_USER。** 展示模拟器截图后，后续真机重点验收：横屏系统栏消失/铺满；实体挖孔避让；边缘swipe临时系统栏自动隐藏；RIGHT→DOWN及整圈手感；斜向；A/B多点；Pause/Home/旋转后无粘键。用户既有code9超过40分钟稳定及存储/退出保留反馈继续有效，但不补写成本轮新验收。

## N. Known Risks

80ms/12%/7°参数已自动测试，真实操作手感仍需人工确认；用户极端自定义重叠布局中其他可见按钮优先于D-pad。模拟cutout/三键环境不等于实体设备。系统swipe transient自动隐藏、API26/29实际设备和多OEM未在本轮人工验证。JNI转译pacing失败尚未解释，不将所有检查概括为全PASS。

本轮可审阅效果，尚未正式交付/人工通过。**Phase7 NOT READY；Phase7.5 code9 USER_CONFIRMED_PASS保留，本轮 refinement人工待验；Phase8 NOT STARTED。**
