# 横屏虚拟按键边缘留白调整 — 2026-10-10

> 历史专项候选报告：当前Phase7状态 superseded by [Final Consolidation权威](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)（2026-10-10，code13）。下方原候选结果/失败/哈希保持，不代表当前版本重新测试或人工通过。

按用户澄清“虚拟按键离边缘太远”执行，候选源码 **0.7.9/code13**。仅开发包用于模拟器预览，尚未打包交付 APK；旧 code12 人工验收包保留、哈希未变。

横屏控制层水平方向只避让 displayCutout 的实际安全区，去除 mandatorySystemGestures 的额外侧边留白；上下方向继续原手势保护。默认方向键、L/R、A 靠近安全区边缘，按键中心仍按自身半径约束，避免整个按键被挤出。横屏拖动及布局校验允许 x=0..1，解决小按键原先被 8% 下限挡住的问题。竖屏仍 x=.08.. .92，不改变画面 Renderer、3:2、背景、Audio 或存档。

只对完整匹配旧默认控件集合的横屏布局应用新默认，保留 opacity，不改文件 schema；自定义控件位置/大小保留。已有自定义布局如仍有旧留白，可以拖到边缘，或在横屏编辑器“恢复默认”并保存。不会自动重置自定义布局。

验证：input JVM 14 tests、0 failures；API36 模拟器无新增挖孔 overlay 及 hole overlay 两环境正反横屏边缘/安全区/拖动保存通过。专项五个不同方法覆盖沉浸系统栏恢复、D-pad 连续方向/多指、schema1 自定义布局、编辑器比例及 opacity 保存/重建。首轮编辑器比例失败来自本轮尝试给预览追加上下手势 insets，已恢复原 ControlPreview 代码，原断言复测通过；失败原日志保留，不改门槛。Audio/Core 本轮哈希与 code12 一致，未重复无关 native 性能测试。

模拟器冷启动在旧 code12 截图就出现 system/System UI 未响应提示，原始带弹窗截图与测试日志保留。最终以下预览为 Android UiAutomation.takeScreenshot(Window) 获取的实际应用窗口，独立于 OS 弹窗，无截图编辑；中间洋红色是 persistence.gba 测试夹具画面。环境异常不作为产品音频/性能通过证据，测试结束恢复原 hole overlay 关闭与手势导航设置。

[正向横屏应用窗口](evidence/landscape_control_edge_refinement/landscape-edge-controls-window.png)；[反向横屏应用窗口](evidence/landscape_control_edge_refinement/reverse-landscape-edge-controls-window.png)。

[修改前快照](evidence/landscape_control_edge_refinement/baseline.json)、[结果与源码核验](evidence/landscape_control_edge_refinement/final-summary.json)。布局效果待用户确认；Phase7 NOT READY、物理性能独立状态及既有人工反馈保持，Phase8 未开始。
