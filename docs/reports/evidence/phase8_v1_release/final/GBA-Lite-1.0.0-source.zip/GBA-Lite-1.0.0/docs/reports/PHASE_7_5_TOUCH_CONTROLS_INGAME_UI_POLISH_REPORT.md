# Phase 7.5 — Touch Controls & In-Game UI Polish

后续按用户明确要求更新为银灰参考风格，最新安装候选见
[Silver controls](PHASE_7_5_SILVER_CONTROLS_REPORT.md)；本页保留上一轮验证与APK身份。

2026-10-08。定向补丁；产品源码提交 `3be62165504ae0b1f638833a3675b634f42791fc`。
用户明确确认按任务文档执行；不是重新开展整个 Phase 7.5。
实现完成，实机验收 **PENDING_USER**。Phase7/7.5 **NOT_READY**，Phase8 **NOT_STARTED**。

## A. 基线与改动范围

工作目录 `D:/GPT/projects/gba-emulator`，起始 `0e8d425`，工作区干净。
已阅读 PROJECT_SPEC、ARCHITECTURE、上一轮 Phase7.5 报告及本次任务书。
沿用 app / feature-player / input，没有增加模块、依赖、权限或 UI 系统。
版本保持 **0.7.5 / code8**，通过文件名和 SHA 区分本次补丁与上一轮候选。

修改 MainActivity、PlayerViewModel、UnifiedSettings、Player、TouchControls；
增加 ControlPreview、TransientNotice。input 中仅修改 InputProfile 的新默认值。
PrivateInputProfiles 的 schema1、方向文件名、AtomicFile 读写策略不变。
Core/JNI、GameId、Save/State、数据库、renderer/audio 内部、Gradle/NDK、签名流程不变。
设计决定见 [ADR-021](../adr/ADR-021-touch-controls-ingame-polish.md)。

## B. 六张图的对应决定

附件顺序与任务书图号不同，按内容对应：

| 实际附件 | 决定 |
|---|---|
| 1：竖屏暂停菜单 | 保留两列；加独立外部遮罩恢复路径 |
| 2：竖屏游戏 | 去掉画面左右8dp/上下4dp；按键采用纯十字，新默认适度下移 |
| 3：横屏游戏 | 默认40%整体不透明度，图标菜单48dp触控目标 |
| 4：编辑器大保存提示 | 居中、1.8秒、无布局占位、无关闭按钮的成功反馈 |
| 5：DELTA 十字结构 | 只借鉴几何结构；未复制皮肤、商标、图案或品牌 |
| 6：其他产品横屏示意 | 只参考画面优先、半透明原则；未使用宣传图素材 |

附件2的重叠文字对应 PlayerViewModel 原本的 App 截图成功文案，
并非仅凭截图猜测系统 Toast。本轮将它纳入成功轻提示；不修改 Android 系统 UI。

## C. 成功悬浮提示

TransientNotice 是 Box 上的独立视觉 Overlay，safeDrawingPadding 后居中；
小型圆角卡片、淡入淡出、1.8秒自动消失。连续事件更新序号并刷新时长，不叠加。
无 clickable/pointerInput，不拦截拖动、滑杆、返回。TalkBack 使用 Polite liveRegion，
不主动请求焦点。截图提示由当前可见 Player/暂停 Dialog 单独承载，避免重复公告。

保存成功仅在 AtomicFile 写入完成后触发；恢复默认的编辑态提示明确“保存后生效”。
错误继续持久显示，游戏中设置页也能看到保存错误，不自动消失或假报成功。
保存前、提示期间的编辑器 bounds 完全一致；提示期间实际拖动和连续保存通过。

定向触摸测试发现初版 Material Surface 会阻挡卡片正下方的按钮，点击计数为0；
已改成纯绘制 Box，同位置真实点击通过。失败原始日志保留，不以其他位置拖动
通过代替卡片自身区域的验证。

## D. 画面尺寸 / Fit / Integer

竖屏父容器仅保留系统安全区；TextureView 行全宽、aspectRatio(1.5)。
同一 API34/1080px 宽度下 Surface 从1036px扩大至1080px，约 **+4.25%**；
不裁切源内容、不改变截图240×160、滤镜或 renderer 缩放规则。
Integer 继续按原规则留边，不为铺满而改成非整数倍。
四模式、两种缩放、24个方向/模式组合、资源生命周期、真实像素颜色及细线测试通过。
不能据此声称旧黑屏/EGL/host GPU 根因已修复。

## E. 纯十字 D-pad 与命中

去除方形底板，以完整十字 Path 绘制边缘/面层，保留圆轴和方向符号。
十字臂半宽为半径0.46，保留拇指操作范围及可触发既有斜向规则的臂区。
运行态四角透明且不命中；编辑态仍支持外接矩形选中/拖动，选中描边只在编辑时可见。
原 dpad dead zone、斜向阈值、InputRouter 与 GBA 按键协议不变。

实际 MotionEvent 验证四角像素透明/不触发、上下左右、连续移动释放旧方向、
斜向、方向+A、分指释放、ACTION_CANCEL、失焦释放及编辑拖动。
另复用现有多点输入、旋转/后台回归，不用截图替代输入验证。

## F. 新默认坐标与兼容

按控制区高度归一化下移0.08，避免单设备绝对像素：

| 控件 | 旧 y | 新 y |
|---|---:|---:|
| D-pad | 0.43 | 0.51 |
| A | 0.35 | 0.43 |
| B | 0.53 | 0.61 |

保留 x、大小、A高B低、L/R及Start/Select坐标；运行几何继续按实际安全区域夹紧。
只有缺省配置或明确恢复默认采用新值。读取既有 schema1 文件时不比较默认、
不判断个性化、不迁移覆盖；包括用户保存过的旧默认也原样保留。
历史 JSON（旧位置、100%透明度）的字节保留与重建读取已验证。

## G. 横屏透明度与持久化

新横屏默认0.40，竖屏维持0.65；每方向独立文件，schema不变。
按键整体使用 saveLayerAlpha 一次合成，避免多层paint叠加成约80%实际不透明度。
按下最多增强剩余可见度的35%，松开100ms淡回；只改变视觉，不修改命中或输入。
实际像素Alpha验证40%对应约102/255；预览按同比缩放最小尺寸，不制造另一套几何。
横屏编辑滑杆与真实profile一致；保存58%、Activity重建后恢复、竖屏文件不变已验证。

## H. 菜单键与无障碍

横屏仅三横线图标，48×48dp触控目标，contentDescription“菜单”。
底色与图标采用profile透明度；竖屏保留“菜单”文字及快进状态。
安全区内顶中放置，与两侧L/R分开；反横屏/真实握持舒适度待用户。

## I. 暂停遮罩与状态机

满窗 Dialog 内独立遮罩消费完整点击。只有一级root且非saving时调用同一个resume：
先释放输入并关闭菜单，再通过原Session.setPaused(false)恢复；不重开核心或音频流。
面板空白区也消费点击；下层TouchControls未获得pointer。
二级存读档/显示/设置等外部点击不恢复，不改变正在进行的业务动作。
Back保持原逐层导航语义，显式“继续”保留。
测试验证按下遮罩尚不恢复、抬起后恢复、下层无pointer、面板内空白和二级外部保持暂停。

## J. 横屏暂停面板与编辑器

横屏3列×2行，单项最小64dp、12dp内边距、图标+短标题；最大宽720dp，
居中悬浮，六主操作、截图与设置均保留。竖屏两列与说明保留。
安全区约束最大高度，内容可滚动；不会直接铺满整个横屏。

ControlPreview 按目标游戏控制区比例居中留边，避免任意拉伸。
预览中的24/36dp最小按键及文字/描边也按预览缩放，实际配置不被改变。
横屏预览按隐藏系统栏后的可用窗口计算，仍预留刘海；单个/整体缩放及方向独立保存保留。
小屏320dp/1.3字体的布局保存可达回归通过；实际OEM挖孔/手势细节仍需人工确认。

## K. 自动化与原始证据

所有原始日志位于本机 ignored `evidence/phase7_5_touch_ui/`，未上传测试ROM、APK或图片。
完整结果与SHA见 `candidate-and-evidence.json`；Debug/Release为普通arm64，
API26/29/34的compat包仅供本机验证，禁止交给用户安装。

| 批次 | 结果 / 说明 |
|---|---|
| 初始旧0.7.0基线 | 失败；误用AVD已有版本，保留 baseline-api34.log |
| 旧0.7.5初次基线 | surface尚未挂载即断言失败；修正等待实际视图，不放宽时限 |
| 旧0.7.5最终游戏/编辑基线 | 各1/1 PASS，同设备、同合法测试画面 |
| API34新增初批6项 | 4通过/2失败；固定按钮误调用滚动，未改产品断言 |
| API34修正6项 | 6/6 PASS，34.934秒 |
| API34功能/渲染补充7项 | 7/7 PASS，183.746秒；包括24组合旋转、存读档、后台与快进倒带 |
| API29初次定向4项 | 4/4 PASS，40.677秒 |
| API36普通arm64初次7项 | 7/7 PASS，55.784秒 |
| API34提示去重补充8项 | 8/8 PASS，46.946秒 |
| API34新编辑器9项初批 | 8通过/1失败；预期比例误含刘海区域，精度不变，改用真实安全区 |
| API34编辑器安全区隔离复测 | 1/1 PASS，7.525秒，含58%保存与重建恢复 |
| 后续多AVD并行9项 | ADB/AVD中断，INCOMPLETE；保留各原始日志，不计PASS |

最终 API34 单设备十项复测通过：`final-ten-gesture-api34.log`，10/10，51.8秒。
确认批次 `final-ten-confirmation-api34.log` 同样10/10通过，46.536秒。
API36最终普通 arm64 Debug 同样10/10通过，69.411秒，见
`final-ten-arm64-api36.log`，没有使用compat包替代交付APK。
其中布局保存测试明确拆分按下/抬起，并在按下期间关闭成功提示，验证页面重组后
仍能完成保存；保存58%后重建页面恢复、另一方向配置保持一致。
此前整批9项及10项曾在保存等待上失败，诊断日志完整保留；单项通过不用于覆盖它们。
`notice-hit-before-fix-api34.log` 是提示触摸阻挡的真实失败证据。

最终普通 arm64 Debug/unsigned Release、AndroidTest、全项目 JVM 测试及 lintDebug
构建通过，46秒，见 `final-notice-build-unit-lint.log`。
66个独立 JVM 用例，另有Debug/Release变体重复执行；app lint零错误、20警告，
feature-player零错误、8警告。警告保留，未改变工具链或降低检查等级。
最终源码/APK审计105项通过，见 `final-notice-apk-source-audit.md`；
3064个受保护基线文件仅 InputProfile 新默认值发生本轮明确授权的变化。
主源码和所有依赖/工具版本冻结；不关闭测试、不放宽原性能门槛。

本轮本地提交已经完成，但最终 GitHub 同步为 **BLOCKED_NETWORK**：
默认 Schannel、HTTP/1.1 和启用证书校验的 OpenSSL 均在 TLS 握手/接收阶段失败。
GitHub connector 查询本轮收尾提交返回 Ref not found，未将远程CI计为通过。
失败摘要见本机 `remote-sync-failure.txt`；本地APK和上述测试结果不受影响。

## L. 前后截图与交付

[真实截图对比页](evidence/phase7_5_touch_ui/comparison.html)
包含同API34游戏竖屏/横屏、横屏暂停与编辑保存前后；原始PNG保持不变。
红色来自许可的内部persistence测试画面，不代表黑屏或商业游戏通过。
截图证据区分 before、after早期批次、after-final、API29/API36，不覆盖历史失败。
导出目录中的 `landscape-editor-failure.png` 是保留的历史失败诊断，元数据明确标注
`retained-failure`，不会出现在前后对比页或当作通过证据。

[新人工验收 Debug APK](evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-touch-ui-debug.apk)
及 [SHA256SUMS](evidence/phase7_5_touch_ui/manual-handoff/SHA256SUMS.txt)。
unsigned Release仅归档审计，不可直接安装；原上一轮候选保留。
最终 Debug SHA256：`a477cc3fed2ea95f70d7ebb6b657fdfdf57717131477ef6f4c0fa545e061a492`。
最终 unsigned Release SHA256：`f872dff04f8c56af44059c88aa50bd51118fdcad17e4db2866152e5aefac1985`。
本轮提示触摸修复之前的候选另存 `pre-notice-hit-fix/`，不作为本次安装包。
沿用开发证书 SHA256 `3660dfb189306e49d973a7f91c9cbc1cb35cc93921f0292e8db28b3fa10b4094`。
覆盖安装，不卸载/清数据。安装后已有布局仍保留，只有手动恢复默认再保存才换新默认。

## M. 未测范围 / 总阶段影响

实机主观握持、持续多点手感、真实音频、热量、电池、Bluetooth HID和OEM挖孔适配
均 **PENDING_USER**；模拟器和合成事件不能代替这些项目。
API26因本机AVD连接失败为 **NOT_TESTED**，不计为通过。
历史加速性能门槛 **OPEN/NOT_PASS**，本轮没有重跑或放宽；
Phase7游戏广度、历史State缺档、完整RTC/sensor游戏等独立缺口保持原状态。
未触及Phase7B Advanced Hardening，没有生产Stable、正式签名或Phase8推进。

本轮实现与自动化完成不等于最终验收完成。合并验收见
[Phase7 + Phase7.5 人工清单](PHASE_7_AND_7_5_MANUAL_ACCEPTANCE.md)。
