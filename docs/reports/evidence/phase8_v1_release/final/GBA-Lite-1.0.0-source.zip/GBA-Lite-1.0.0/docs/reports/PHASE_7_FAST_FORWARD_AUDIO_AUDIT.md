# Phase 7 Fast-Forward Audio Audit — 2026-10-09

审计先于生产修改。当前源码0.7.7/code11，包含code10性能及code11触控全屏细化；文档code9基线前提已过期。旧候选/报告保持，快进音频本轮使用code12。用户先预览再交付APK的要求仍有效。

## Current path / root behavior

mGBA blip输出32768Hz stereo I16，每帧读取至复用2048-frame pcm_；Core::loop只在speed_==1调用AudioOutput::push。Core::control切换倍率时stop Oboe，只有1×且非倒带才restart；Core::start也仅1×启动。高倍率生成的PCM仍被drain但丢弃。因此FF静音是明确native bridge策略，不是当前ring积压的测量结果。不能只取消mute而把全部PCM以1×速率写入。

## Existing bounded ring / consumer

PcmRing<4096>是单producer/consumer，满时拒绝新样本，pop补零；read/write各由单线程持有。只能双方停止后clear。Oboe固定32768Hz stereo I16，低延迟Shared，callback不等待emulator。stop→close等callback完成后clear。当前1×ring需保留，避免这轮改变普通声音。

## Speed / reset / lifecycle

speed_由Core::control检查1/2/4/8，是Core控制mutex下的唯一requested倍率；pacing使用同一值。Session暂停/存读档会暂时pause（Core pause将speed重置1），Session resume重新应用所选倍率。control返回1×清blip并audioRates；pause、rewind、reset、ROM退出已有stop边界。State只允许暂停时import。线程同步继续使用原Core控制mutex，callback不得获取它。

## Selected minimal change / risks

Audio模块加入连续phase的整数decimation：输出输入每第N个stereo frame，N直接来自requested speed_，跨块保持phase，无热路径分配，无保调DSP。1×保留原PcmRing及样本路径。FF采用独立有界最新PCM ring：atomic packed stereo+序号，producer不修改consumer游标，覆写只用atomic，consumer验证序号、超出窗口丢旧样本，避免修改现有非atomic SPSC数组引入竞态。固定2048frame最多62.5ms队列，不阻塞producer；读写循环有界，不互相等待。

每次倍率/lifecycle切换保留stop/close边界，清ring和processor phase并清blip，再按当前非倒带倍率start。暂停/倒带/后台依旧无输出，State/ROM不携带processor状态。Debug-only记录输入/压缩输出/队列丢弃/填充/ratio及已有underrun；无UI或生产逐帧日志。

风险：decimation有aliasing，高倍率音质降低；8×实际不足requested时可能欠供，优先核心而不降低ratio追赶音调。FF新ring需要并发压力、最新样本、长期计数/边界及UBSan；Oboe stop/start过渡和1×恢复需真实PCM与生命周期测试。模拟器pacing本来存在失败，不冒称物理性能通过。人工音质与click/pop待听音验收。

## Gate

pipeline和静音根因明确，可以实施上述局部修改。mGBA/vendor、Core API契约、Session存档流程、Renderer、Input、UI及schema不改。没有证据支持复杂DSP或音频驱动actual倍率，因此选择requested倍率并说明best-effort边界。
