# Phase 7 Fast-Forward Audio Refinement — 2026-10-10

> 历史专项候选报告：当前Phase7状态 superseded by [Final Consolidation权威](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)（2026-10-10，code13）。下方原候选结果/失败/哈希保持，不代表当前版本重新测试或人工通过。

## 人工验收 APK 交付更新 — 2026-10-10

用户已授权打包。0.7.8/code12 普通 ARM64 Debug 与 unsigned Release 构建完成；两包当前版本审计 105 PASS，Debug 沿用旧开发签名。人工验收 PENDING，物理性能结论不变，Phase7 NOT READY。此更新取代下方历史“交付 APK 暂缓”状态。

[可安装 Debug APK](evidence/phase7_fast_forward_audio/manual-handoff/GBA-Lite-0.7.8-fast-forward-audio-code12-debug.apk)；[验收说明](evidence/phase7_fast_forward_audio/manual-handoff/人工验收说明.md)。Debug SHA256 `9c7242fa5cc09c30a8ed7fba2ad46e604a106759a03e4844da855fe588e40248`；unsigned Release SHA256 `bdd7bafa595bcd9f55987de98fd45e2ffdbc772ff55d215f565eb85d9211a084`。

本轮生产实现及自动功能回归完成，候选 **0.7.8/code12** 可预览。**人工音质验收 PENDING；物理 ARM 性能未验证；Phase7 NOT READY；Phase8 NOT STARTED。** 用户“先展示效果，确认后构建交付 APK”的要求优先：只构建用于模拟器测试的开发 Debug 与 instrumentation APK，未构建 code12 交付包或 unsigned Release APK。Release native AAR 与 Kotlin 编译已通过。

## A. Scope

仅调整 Audio PCM 压缩、FF 有界队列、native bridge 音频启动/清理以及 Debug 测试指标。版本/About 标记同步到新候选，不增加设置项。无 mGBA/vendor、Core API 语义、Save/State、Game ID、Room/DataStore schema、Renderer、Input、window/insets、Player 布局、权限或网络改动。此前性能/触控改动保留。

## B. Baseline

实际实施前源码为 **0.7.7/code11**，文档中的 code9 前提已过期。已先输出 [修改前审计](PHASE_7_FAST_FORWARD_AUDIO_AUDIT.md)，保存九个编辑点的原文件与哈希。[baseline.json](evidence/phase7_fast_forward_audio/baseline.json)。code11 开发 Debug SHA256 `8fd99cd4b9c1474aafb1707953e9102383895fefa5c4ac3d0d19ff90adfa7015`。

冻结 code9/code10 四个 APK 本轮重新核验一致；code9 用户反馈 >40 分钟稳定、存储及退出进度保留继续有效，不能自动转为 code12 人工音质通过。[完整性记录](evidence/phase7_fast_forward_audio/source-integrity.json)。快照覆盖本轮编辑点，不能冒称完整仓库前后哈希证明。

## C. Existing FF Mute Behavior

真实静音原因在 native bridge：start/control 只在 speed==1 启动 Oboe，loop 仅在 speed==1 推送 PCM。高倍率 PCM 仍被读取后丢弃。因此不是测量到队列满后偶然静音，也不能只取消静音而把高速 PCM 全量按正常速率播放。

## D. Current Audio Pipeline

mGBA blip → 32768 Hz stereo I16、复用 2048-frame 输入 → 1× 原 PcmRing<4096>，或 FF FastForwardAudioProcessor → LatestPcmRing<2048> → Oboe Shared low-latency callback。输出采样率保持 32768 Hz。倍率/生命周期切换使用原 Core control mutex，并先 stop/close 等 callback 退出，再清队列、phase、blip，再启动对应倍率。

## E. Selected Resampling Strategy

整数 decimation：每 N 个 stereo frame 输出一对，phase 跨输入块连续，N=1/2/4/8。固定预分配压缩缓冲，无逐帧 allocation、DSP 库或 production 热路径日志。1× 原样本及 ring 路径保留。已知 128 Hz PCM 输出频率 128/256/512/1024 Hz，32768 输入 frames 输出 32768/16384/8192/4096。允许 aliasing；本轮未加抗混叠滤波、保调或过渡 fade。响度与 click/pop 必须听音确认。

## F. Ring Buffer Policy

仅 FF 使用最新窗口队列，容量 2048 frames，即队列自身最多 62.5 ms，另有设备/Oboe 缓冲，不能视为端到端延迟保证。atomic 64-bit packed stereo+sequence，编译要求 lock-free；producer 不修改 consumer read 游标。consumer 超窗跳过旧数据，序号不符时剩余补零，不 spin/retry，不获取 Core mutex。两边循环有界，无等待彼此的队列写入。1× 仍使用原 4096-frame SPSC，满时拒绝新样本。clear 只在 producer 与 callback 停止后执行。

## G. FF Multiplier Mapping

ratio 来自 Core 已验证的 requested speed，和 pacing 使用同一状态，AudioOutput 只在停止边界接收该值。选择 requested 而非抖动的实际 FPS 推算倍率，避免音调来回变化；2/4/8× 均开启输出。实际执行不足 requested 时仍按 requested 压缩，可能欠供和间断，特别是 8× best-effort；不为补音频限制核心或无限积压。本轮不证明所有设备能持续 4×/8×。

## H. 1× Recovery

FF→1× 清两个 ring、processor phase 与 blip，回原样本路径。已验证多次 1→2→1、1→4→1、1→8→1、2→4→8→4→2→1；测试有非零输出、有限 fill 与当前 ratio。原 stop/start 未测量几十毫秒端到端听感，不以这些断言冒称无爆音人工 PASS。

## I. Pause / Background / Rewind

暂停、真实 Home、倒带停止输出并清队列；前台恢复按实际 Core 当前 speed 发声。UI hold 进入 2×、释放回 1×，toggle 进入/退出，以及 FF→Pause→Resume、FF→Rewind→1、FF→Rewind→FF→1 已测。Pause 菜单继续时 Player 重应用已选倍率。Session 的原 Home/存档暂停路径可能恢复为 1×；本轮保留该既有语义，音频跟随实际 Core 而非独立复制 UI 倍率。

## J. Save / Load / Exit

FF 下 Quick 与 Slots 1–4 保存/读取、raw state import/export、退出/销毁已测，操作后输出有声，实际倍率与音频一致，无旧队列继承。原 Session state 流程暂停并恢复至 1×，没有为本任务修改它。销毁停止 Oboe、清音频 state；原 ROM 加载重新初始化 Core。没有修改存档格式或新增存储字段。

## K. Performance Impact

API36 转译模拟器、Debug、一组短方向采样：16 cells、每项 1 秒预热+3 秒采样。早期 after cells 与 host 编译重叠，不是受控物理 ARM A/B。视口全部一致。以下只描述方向，不能宣称性能 qualified 或无 meaningful regression。旧 FF 静音时 underrun=0，与新开启输出的数字不能直接当音质退化对比。

|Mode|Requested|Before actual|After actual|Relative|Underrun before→after|
|---|---:|---:|---:|---:|---:|
|ORIGINAL|1×|1.008×|1.005×|-0.27%|0→1|
|ORIGINAL|2×|2.007×|1.996×|-0.53%|0→1|
|ORIGINAL|4×|2.867×|2.775×|-3.23%|0→81|
|ORIGINAL|8×|2.681×|2.563×|-4.41%|0→104|
|SHARP|1×|1.014×|1.011×|-0.25%|0→1|
|SHARP|2×|1.988×|1.999×|+0.56%|0→16|
|SHARP|4×|2.554×|2.556×|+0.05%|0→81|
|SHARP|8×|2.502×|2.509×|+0.28%|0→105|
|GBA_COLOR|1×|1.013×|1.008×|-0.50%|1→1|
|GBA_COLOR|2×|1.849×|1.833×|-0.84%|0→17|
|GBA_COLOR|4×|2.436×|2.547×|+4.57%|0→83|
|GBA_COLOR|8×|2.576×|2.426×|-5.82%|0→103|
|LCD|1×|1.001×|1.000×|-0.02%|0→2|
|LCD|2×|1.971×|1.954×|-0.89%|0→14|
|LCD|4×|2.579×|2.582×|+0.13%|0→86|
|LCD|8×|2.489×|2.521×|+1.28%|0→104|

4/8× 实际约 2.4–2.9×，压缩后欠供，因此高倍率 underrun 多；没有改变既有 pacing 门槛。相对变化约 -5.82% 到 +4.57%，单轮混合环境不支持归因。CPU 指标本轮未获得；无物理性能通过结论。[原数据及范围](evidence/phase7_fast_forward_audio/ff-performance.json)。

另做普通 1× OLD→NEW→NEW→OLD，每轮 2 秒预热、3×10 秒，所有窗口非零 PCM 持续推进。OLD 首轮 FPS 59.740/59.728/59.738，underrun 0/1/0；**NEW 首轮 FPS 59.523/59.010/58.846，underrun 5/11/18，总 34，保留异常**。NEW 复测 59.732/59.742/59.730、0/0/0；OLD 反向对照 59.740/59.735/59.729、0/0/0。异常未复现，根因未确认，不能直接归因环境或宣布 1× 音质完全无退化。四轮原 JSONL/log 均保留。code12 人工普通声音及物理性能待验收。

## L. Automated Tests

- JVM 79 个 variant test results，0 failure/error（70 个独立方法，公共模块重复计数已区分）。[XML 汇总](evidence/phase7_fast_forward_audio/jvm-results.json)。部分任务 UPTODATE，无伪称全部重新执行。
- 应用功能专项 10 tests：新 FF 音频矩阵、旧 FF/Rewind、Pause、四模式/24 次旋转 Renderer、真实 Home/Foreground、存档、连续 D-pad/多指、Activity 3 tests 均 PASS。
- 独立 1× cadence 四轮 tests 均通过持续 PCM 断言；异常计数依旧公开，不由断言 PASS 掩盖。
- before/after performance 各 1 个 sampler test 正常完成，**不计正式性能资格 PASS**。
- APK/provenance 105 checks PASS。审计对象为 code12 开发 Debug 与既有 code10 unsigned Release，**不是 code12 Release APK**。无新增权限/网络/ROM/BIOS/测试 provider 泄漏。[审计](evidence/phase7_fast_forward_audio/apk-provenance-audit.md)。

## M. Native/JNI Regression

Host 2 项 Audio（新 PCM/phase/最新窗口/200000-frame 并发）+既有 7 项 mGBA native，共 9 PASS。JNI 完整 suite 18 tests PASS；新 JNI 单项及 Activity 矩阵验证输入/输出/ratio/drop/fill/underrun，所有倍率 played PCM 非零。压力条件出现 stale drop（应用记录 842），fill 仍有界。代码11 旧 4× pacing 失败 213.37/206.28 记录保留，本轮完整 suite 单次通过不能证明旧失败根因消除。

UBSan：新增 host processor/ring 路径使用 undefined trap 运行通过；Android sanitized test APK 新 JNI 路径 1 PASS，随后恢复普通 OFF native/test APK。ASan 仍 DEFERRED。首次 MSVC PDB C1902、NDK host 链接/Clang18 与 VS18 STL compatibility 失败保留原日志；host 测试使用 /Z7，UBSan 测试 shim 将 unavailable verbose_trap 映射为 builtin_trap（保持 trap），仅测试构建生效，不改生产工具链。Release native 动态符号检查无 ForTest/ASan/UBSan 符号。[核验](evidence/phase7_fast_forward_audio/release-native-integrity.json)。

## N. Candidate Identity

**0.7.8 / versionCode12**，开发 Debug SHA256 `9c7242fa5cc09c30a8ed7fba2ad46e604a106759a03e4844da855fe588e40248`，与当前 app-debug.apk 一致。

本轮 11 个生产文件 canonical path/SHA256 清单合成 source hash `57437a99a3262e35e8e0d6cbed5d5e399f7b86bf4f3566699f9a9e0548da8bae`，范围不冒称整个仓库。unsigned Release SHA256 **null / DEFERRED_USER_PREVIEW_FIRST**，无 code12 交付 APK。Release native/Kotlin 编译 PASS 不等于 Release APK 审计或交付完成。[候选清单](evidence/phase7_fast_forward_audio/candidate-hashes.json)。冻结旧包不覆盖。

## O. Known Limitations

整数抽样有混叠，8× 为 best-effort；实际速度不足 requested 时音频可能断续。未加入 fade，click/pop 需人工听音。1× 首轮 34 underrun 异常未确认根因，不能闭合无退化 gate。模拟器 PCM 非零/压缩比例不等于扬声器实听音质。物理 ARM 本轮未测试，旧物理矩阵重复性环境阻塞仍存在，不把旧 code9 人工通过转移给新候选。

## P. Manual Acceptance

**READY_FOR_AUDIO_PREVIEW / MANUAL_AUDIO_ACCEPTANCE_PENDING；最终接受 gate 未闭合。** 已生成实际 production processor 处理的同一合成旋律 1/2/4/8× WAV（6/3/1.5/0.75 秒），只作倍率效果预览，**不是模拟器录音、ROM 音频或真机验收**。[试听元数据](evidence/phase7_fast_forward_audio/audio-preview.json)。

效果确认后再构建交付 APK。最终需实听 1× 正常、2/4× 有声加速、8× best-effort、4/8→1× 无残留高音/持续爆音、Pause/Home 无输出、Rewind 静音与释放恢复。已有长时间稳定/基本存储反馈不重复索取。**Phase7 NOT READY；Phase7.5 code9 原人工通过保留，新 touch/fullscreen/audio 候选专项验收各自待定；Phase8 NOT STARTED。**
