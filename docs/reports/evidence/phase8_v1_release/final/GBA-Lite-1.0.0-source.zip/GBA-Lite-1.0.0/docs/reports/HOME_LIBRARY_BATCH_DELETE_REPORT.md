# 首页 / 游戏库长按多选批量删除

2026-10-09。产品提交 `0fa992595268b230fff0fbb46080d7e57b8d1c4a`。
用户明确请求：首页和游戏库长按游戏后多选批量删除。

首页最近游戏、继续上次游戏卡片及游戏库条目均支持长按进入多选；随后点击条目
切换勾选，不启动游戏。顶部显示数量、取消、删除；支持全选当前可见列表及取消全选。
搜索过滤后全选仅作用于当前结果，其他已选项目保留。首页/游戏库切换保留选择，
进入设置或返回键退出多选。配置重建保留选择、页面和搜索。

删除前确认数量与范围：移除库记录及应用内ROM副本，原始ROM、正常存档、即时
存档、截图保留。取消确认保留勾选。后台顺序删除并统一刷新两页；期间禁重复提交、
添加和启动游戏。部分失败时逐项继续处理，报告成功/失败数量，只留下失败项供重试。
未更改数据格式、数据库schema或模拟核心。沿用既有 LibraryRepository.remove。

## 验证

- 最终 API34 4/4通过，32.233秒：三个新增批量删除测试及原首页/游戏库/详情流程回归。
- 真实继续卡片：长按不启动；与最近条目共享选择；Activity重建仍保留；退出多选后
  正常点击恢复游戏。
- UI：两页长按、搜索全选、跨页选择、零选择禁删除、取消确认、返回退出、状态恢复。
- 存储：两个成功一个受控失败；仅失败项保留并可重试；逐项验证原文件、正常存档、
  即时存档与截图字节保留。所有故障注入和删除均针对随机唯一测试ID。
- 首批2项失败是测试宿主已有Compose内容及未标记最近游玩的测试元数据问题；
  修正测试夹具后2/2通过（13.365秒），原失败日志保留。
- 普通 arm64 Debug/unsigned Release、AndroidTest、全项目JVM测试及lintDebug通过，47秒。
- 105项源码/APK审计通过；Debug保持原开发证书，0.7.5/code8。

本机原始日志在 `docs/reports/evidence/phase7_5_touch_ui/`：
`batch-delete-api34-tests.log`（原失败）、`batch-delete-api34-tests-2.log`、
`batch-delete-final-api34-tests.log`、`batch-delete-final-build-unit-lint.log`、
`batch-delete-final-audit.md`、`batch-delete-final-signature.txt`。
实际截图在 `batch-delete/`，列表中的Batch Alpha/Beta等是测试元数据。
本轮未重跑API26/29/36或远程CI，不将历史结果写成本轮结果。

## 安装验收

[最新普通arm64 Debug APK](evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-batch-delete-debug.apk)
包含此前银灰按键补丁，覆盖安装并保留数据。
[SHA256校验](evidence/phase7_5_touch_ui/manual-handoff/BATCH-DELETE-SHA256SUMS.txt)。

Debug SHA256：`01c01c5c9a98e242f4d0de76fb0efadd3fc1c9ca4ae2d7d030ea790756117c29`。
unsigned Release SHA256：`4f36b4e03cb829b0f6367d35c4d546bc3e2103f2ec012c345b7670e3e5dcb6b7`。
unsigned Release仅审计归档，不能直接安装；compat仅本机测试。

人工验收仍PENDING_USER；历史Phase7缺口不变，Phase7/7.5 NOT_READY。
