# ADR-021 — Touch controls and in-game UI polish

2026-10-08. The user explicitly approved executing the supplied touch-controls
document after reviewing the six screenshots. This is a focused Phase 7.5 patch.

This supersedes ADR-020's unchanged-default-position decision for **unsaved
defaults and explicit reset only**. Portrait D-pad/A/B centers move down by 0.08
of the control area's height. Shoulder/system buttons retain their coordinates;
runtime geometry continues clamping to the safe view bounds. Landscape defaults
use 0.40 opacity; portrait retains 0.65. Existing schema-1 direction-specific
files are read exactly, including saved historical defaults. No migration,
schema increment, personalization inference, or overwrite on rotation is needed.

D-pad painting and runtime hit testing use the same cross (arm half-width 0.46
of radius). Transparent corners reject gameplay touches; editor-only square
selection bounds retain drag accessibility. The existing directional dead zone,
diagonal rule, multi-pointer router and core button protocol remain unchanged.
Opacity composites each entire button once; it does not accumulate per paint
layer. Press feedback raises visibility without changing touch geometry.

Layout previews letterbox to the intended control-area aspect and scale physical
minimum dimensions with the preview. Landscape preview reserves cutouts rather
than the settings page's visible system bars. Actual device cutouts and comfort
remain subject to manual acceptance.

Successful layout/screenshot feedback uses a non-interactive centered overlay
with a refreshable 1.8-second timer and polite accessibility semantics. Only the
visible page/dialog hosts the screenshot notice. Persistent errors retain their
existing presentation. Editor reset is explicit about requiring save.

The full-window pause dialog consumes the outside gesture. Only root pause, when
not saving, calls the existing resume path; child pages stay paused on outside
tap. Blank panel space consumes taps. Root landscape uses compact 3-by-2 cards;
portrait retains two columns. Tall text/short windows scroll within safe bounds.

Core/JNI, renderer internals, audio, persistence identities and formats,
permissions, dependencies, toolchain and production signing remain unchanged.
Phase 7/7.5 readiness and historical performance/GPU gaps are not waived.

A real pointer test found that Material Surface intercepted touches underneath
the success notice card. TransientNotice now uses a drawing-only Box; the test
clicks a real button directly underneath the card. The failed original run is
retained with the validation evidence.
