# Phase 7 Compatibility / Stability / Security Report

## Phase8 V1 Stable — 2026-10-10（当前发布权威）

**Phase7 READY；Phase8 COMPLETE；V1.0.0/code14 STABLE。** 只提升版本元数据，无业务逻辑变化；正式签名Release、隔离fresh-install/smoke、最终回归、105项审计及bit-for-bit复现通过。APK `26b4f57da47aea63daac7ad91fa270dd77820b3c1bcb3cad8f430ccd0ac01659`；certificate `ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f`；source manifest `985315f45e50acb18914d82d5ab770e82cb4a08439baf09fad21a7f264519956`。本地交付/commit/tag，未push或创建GitHub Release；旧Debug不能覆盖迁移，主手机数据保留。见[Phase8权威报告](PHASE_8_V1_RELEASE_AND_STABLE_PROMOTION_REPORT.md)。下方Phase7收口仍是code13历史冻结依据，其Phase8尚未开始状态已由本节取代。

## Final Consolidation — 2026-10-10（唯一当前权威）

**当前基线0.7.9/code13；Phase7 READY；Phase8 UNBLOCKED_TO_START / NOT STARTED；V1 NOT RELEASED。** 用户已明确选择code13收口，并在后续直接回复闭合人工专项与性能风险处置。下方所有旧结论仅代表历史候选/时点。

本轮无生产改动/版本bump/交付构建。Debug13 SHA256 `b168192b7d0a64d2ff49e0d25113679c413a3884763a4733ed24bcd0d1036036`；code13 Release/交付包未构建，现存Release仍code12。91份源码冻结核验通过。

完整JVM80结果（71独立方法）、code13应用9测试、105项审计通过（Debug13+Release12）。未变native复用host9/JNI18/targeted UBSan；历史失败、34underrun、code10 MIXED/UNQUALIFIED、code11转译pacing UNRESOLVED均保留，不声称新CI或性能提升。

**人工USER_CONFIRMED_PASS：** code9 >40min稳定/基本存储/退出保留；code12正反横屏、D-pad转向/绕圈/斜向/方向+A/B/无粘键、1×/2×/4×/8×音频及切回/Pause/Home/Rewind；code13新增边缘布局。未补写设备/API/客观热量数据。

**Physical ARM Performance = ACCEPTED_RISK。** 用户停止正式A/B并接受未认证风险，另确认无明显卡顿、掉速或异常发热；正式A/B NOT_CERTIFIED，不能标VALIDATED。相关性能退化或native/性能路径变更时重开。**无剩余Phase7 hard blocker。** API26/29实机、第二OEM、RTC/sensor完整游戏缺口保留；USB未测、Rumble/ASan延期，API29短黑帧MONITORED、Phase2原fixture缺失ACCEPTED_RISK。

[最终A–U报告](PHASE_7_FINAL_CONSOLIDATION_AND_READINESS_REPORT.md) · [直接反馈](evidence/phase7_final_consolidation/manual-feedback-20261010.json) · [冻结状态](evidence/phase7_final_consolidation/final-state.json) · [风险处置](evidence/phase7_final_consolidation/risk-disposition.md)。Phase8可以开始，本轮未开始签名/RC/发布；候选改变须重新评估相关边界。

---

以下全部保留为历史候选/执行记录；当前状态 superseded by final consolidation。


## 横屏按键留白预览 — 2026-10-10

最新工作源码 0.7.9/code13，减少横屏虚拟按键侧边留白，保持自定义布局及竖屏/Renderer/Audio；input JVM 14 项通过，横屏与反向横屏（包含模拟挖孔）、拖动保存及专项回归通过。仅模拟器开发包预览，code13 未交付 APK；code12 已交付包及原哈希保留。布局人工确认 PENDING，既有 Phase7 NOT READY/物理性能状态不变。见[本轮记录](LANDSCAPE_CONTROL_EDGE_REFINEMENT_REPORT.md)。

## 人工验收 APK 交付更新 — 2026-10-10

用户已授权打包。0.7.8/code12 普通 ARM64 Debug 与 unsigned Release 构建完成；两包当前版本审计 105 PASS，Debug 沿用旧开发签名。人工验收 PENDING，物理性能结论不变，Phase7 NOT READY。此更新取代下方历史“交付 APK 暂缓”状态。

[可安装 Debug APK](evidence/phase7_fast_forward_audio/manual-handoff/GBA-Lite-0.7.8-fast-forward-audio-code12-debug.apk)；[验收说明](evidence/phase7_fast_forward_audio/manual-handoff/人工验收说明.md)。Debug SHA256 `9c7242fa5cc09c30a8ed7fba2ad46e604a106759a03e4844da855fe588e40248`；unsigned Release SHA256 `bdd7bafa595bcd9f55987de98fd45e2ffdbc772ff55d215f565eb85d9211a084`。

## Fast-Forward Audio Refinement — 2026-10-10（最新候选技术状态）

当前源码候选 **0.7.8/code12**：2/4/8× 开启加速音频，采用整数 PCM 压缩和 FF 专用 2048-frame 最新窗口队列；1× 保留原样本路径，Pause/Home/Rewind 停止输出，返回 1× 清 phase/旧 PCM。79 个 JVM variant 结果、9 个 host native、18 个 JNI、10 个应用功能 tests 与相关 host/Android UBSan 通过。ASan DEFERRED；Release native 无测试接口。用户先预览后交付 APK 的要求保持，仅开发/测试包，code12 unsigned Release/交付 APK 尚未构建。

**FUNCTIONAL_REGRESSION_PASS / READY_FOR_AUDIO_PREVIEW；人工音质及物理 ARM 性能 PENDING。** 1× 对照首轮新候选出现 34 underruns、后续新候选复测和旧候选反向对照均 0；原异常保留、根因未确认，不能宣布普通音频完全无退化。转译模拟器短性能信号不作为性能 qualified；高倍率实际不足 requested 会欠供。旧 code9/code10 APK 哈希保持，code9 >40 分钟稳定/基本存储/退出进度人工通过保持，不转移为 code12 音质通过。**Phase7 NOT READY；Performance BLOCKED_ENVIRONMENT 既有结论保持；Phase8 NOT STARTED。**

详见[完整音频报告](PHASE_7_FAST_FORWARD_AUDIO_REFINEMENT_REPORT.md)、[修改前审计](PHASE_7_FAST_FORWARD_AUDIO_AUDIT.md)及[候选身份](evidence/phase7_fast_forward_audio/candidate-hashes.json)。下方历史候选和人工记录保持，其“最新”仅表示当时状态。


## Performance Optimization Pass — 2026-10-09（最新候选技术状态）

按新文档完成审计、两项局部优化和回归，独立候选 **0.7.6/code10**。Renderer移除稳定帧重复GL状态设置；TouchControls跳过相同属性的invalidate；Audio/Session/native/存储/安全边界及UI保持。75份JVM结果、8项host native、17项JNI、14项应用回归、声音恢复短测和API29两项五轮生命周期回归通过。旧菜单Text定位失败在冻结code9复现，原日志保留；只修复测试定位，原断言重测通过。

**code10 = FUNCTIONAL_REGRESSION_PASS / PERFORMANCE_UNQUALIFIED。** 模拟器16组合方向信号7升9降，不能宣称改善或整体中性。新候选真机ARM A/B按文档延期，未触碰用户手机。冻结code9包及人工>40分钟稳定/基本存储/退出保留记录保持，不自动转移为code10人工通过。**Phase7 NOT READY；既有Performance BLOCKED_ENVIRONMENT；Phase7.5 code9 USER_CONFIRMED_PASS / READY；Phase8 NOT STARTED。** 下方历史code9物理矩阵仍有效，但不代表code10已验证。

详见[完整优化报告](PHASE_7_PERFORMANCE_OPTIMIZATION_REPORT.md)及[修改前审计](PHASE_7_PERFORMANCE_OPTIMIZATION_AUDIT.md)。两包哈希、所有原始采样、失败对照和复测均独立归档。


## 人工长时间游玩反馈 — 2026-10-09（最新人工证据）

用户明确反馈：运行游戏**超过40分钟保持稳定**，能够进行存储操作，退出后保留刚刚的进度。本次记录为 **MANUAL_GAMEPLAY_STABILITY=USER_CONFIRMED_PASS、BASIC_SAVE_OPERATIONS=USER_CONFIRMED_PASS、PROGRESS_RETENTION_AFTER_EXIT=USER_CONFIRMED_PASS**。这是直接人工反馈，替代此前这些项目“未记录”的状态；不由自动采样推断。

时长仅明确为>40分钟，不补写精确分钟或宣称已确认≥45分钟。机型/API、游戏类别、Quick/四槽/Battery/checkpoint具体机制、强杀/冷启动步骤、声音、温升、电量、快进/倒带、输入及实体外设细节未单独提供，仍保留未记录。这不否定本次稳定游玩及存储体验通过。

**独立技术状态仍为 Performance=BLOCKED_ENVIRONMENT，Phase7=NOT READY；Phase7.5=USER_CONFIRMED_PASS / READY，Phase8=NOT STARTED。** 人工稳定体验不能关闭A/B预设重复性条件和未启动的独立正式实机用例；也不将未反馈的专项体验补成PASS。当前人工侧已获得>40分钟稳定游玩和基本存储/退出进度保留证据，≥45分钟时长及专项细节保持未确认；不重复要求用户完成已经反馈的部分。

[原始反馈与分类](evidence/phase7_performance_coverage/manual-feedback-20261009/feedback.json)。下方A/B记录仍是当前技术结论，旧章节的人工PENDING/NOT_RECORDED仅代表反馈前状态。

## Physical ARM Performance A/B — 2026-10-09（当前技术结论）

**Performance = BLOCKED_ENVIRONMENT。Phase7 = NOT READY。Phase7.5 = USER_CONFIRMED_PASS / READY。Phase8 = NOT STARTED。V1 Release = NOT READY。** 本节取代下方暂停及此前未连接设备时的状态说明；用户原有总体真机验收通过仍保留，不补写人工长测细节。

### 完成范围与冻结候选

PLG110 / API36 / arm64-v8a 已执行真实 ARM 连续 OLD→CODE9→CODE9→OLD，各轮3次重复，四种显示模式×1/2/4/8×，**192个10秒采样单元完整导出**，每单元2秒预热。吃饭前64个完整单元及重连补取的13个中断单元单独保留，不混入连续矩阵。没有改生产代码、UI、native、权限、工具链、存储格式或schema，也没有构建新APK、bump版本或启动Phase8。

候选仍为 **0.7.5/code9**；Debug SHA256 `96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`，unsigned Release SHA256 `b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`。生产源码、两包及格式/依赖锁哈希再次核验未变，merged permissions=[]证据沿用同一冻结APK审计。[完整性核验](evidence/phase7_performance_coverage/physical-ab-reconnect-20261009/final-integrity.json)。

### 性能结果与判定边界

|显示模式|OLD 4×实际倍率均值|CODE9 4×实际倍率均值|CODE9相对差|
|---|---:|---:|---:|
|Original|4.0026×|4.0024×|-0.006%|
|Sharp|4.0042×|4.0025×|-0.041%|
|GBA Color|3.9372×|3.9424×|+0.130%|
|LCD|3.9422×|3.9442×|+0.052%|

所有192行记录的原FPS公式布尔值均为true；这只是characterization采样结果，**不等于独立正式测试执行通过**。采样均值、重复均值CV和轮间漂移没有显示meaningful regression；但预先固定的秒级CV≤10%条件被最后一次OLD重复破坏：Original1×=20.209%，GBA Color4×=13.911%。不能删掉异常桶/重复、放宽阈值或仅凭均值宣布PASS；也未确认生产回归或根因。8×继续best-effort，全部高倍率原始数据保留。

控制变量审查：192行视口均为x367/y0/1620×1080，ROM SHA匹配，16份环境dump中固定亮度1584/manual mode、扬声器路由和媒体音量0一致。电量68–80%、电池温度32.4–35.2°C，省电关闭，USB持续连接充电，thermal由0变化到1（LIGHT）。30秒恢复间隔不能证明完全热恢复。OLD/CODE9音频underrun总增量分别38/34；不据此给人工听音PASS。异常可能涉及调度/计数追赶或温度，尚无根因证据。详见[分析与全部16组合](evidence/phase7_performance_coverage/physical-ab-reconnect-20261009/performance-analysis.md)、[控制审查](evidence/phase7_performance_coverage/physical-ab-reconnect-20261009/review.json)、[192行CSV](evidence/phase7_performance_coverage/performance-physical-ab.csv)。

### 手机恢复与正式用例边界

连续矩阵结束后成功恢复并核验冻结code9、**原665个普通文件全部哈希一致**，原亮度1555和自动模式1恢复。私有ROM/存档备份仍在项目外私有目录，未放入公开证据。见[恢复结果](evidence/phase7_performance_coverage/physical-preflight/restore-result-reconnect-20261009.json)。

随后尝试执行未修改的 `RendererExperienceTest#everyModeFastForwardRewindStateImagesAndPerformance`，ADB已不可访问该设备，最初的亮度命令即失败；instrumentation没有启动，记为 **NOT_EXECUTED_DEVICE_DISCONNECTED**，不记产品FAIL，也不伪造PASS。追加恢复尝试亦未开始数据操作；上面成功恢复结果仍有效。[未执行记录](evidence/phase7_performance_coverage/physical-formal-reconnect-20261009/result.json)。既有转译模拟器正式门槛失败保留原样。

### 其余收口与最终阻塞

|项目|当前分类|
|---|---|
|API26|EMULATOR_BEHAVIOR=PASS_WITH_NOTE；REAL_ARM=NOT_TESTED；ACCEPTED_COVERAGE_GAP|
|API29|EMULATOR_BEHAVIOR=PASS_WITH_NOTE；20-cycle行为通过；短黑帧MONITORED；REAL_ARM=NOT_TESTED/ACCEPTED_COVERAGE_GAP|
|真实ARM / Second OEM|API36性能矩阵已执行，未冒充API26/29实机覆盖；第二OEM仍NOT_TESTED/ACCEPTED_COVERAGE_GAP|
|Action|AUTOMATED_PASS，仅已有完整游戏自动链路|
|Audio-heavy|AUTOMATED_PASS，仅pipeline alive；人工听音PENDING_USER|
|Save-heavy|PARTIAL_AUTOMATED；完整游戏原生电池存档触发/冷启动读回仍未证明|
|RTC/Sensor完整游戏|NO_APPROVED_COMPLETE_GAME_AVAILABLE；既有探针覆盖保留，真实体验PENDING_USER|
|Phase2 State|HISTORICAL_FIXTURE_UNAVAILABLE / ACCEPTED_RISK；格式未变，不重造历史fixture|
|USB / Rumble / ASan|USB NOT_AVAILABLE；Rumble DEFERRED；ASan DEFERRED/NOT_COMPLETE；零权限/native冻结|

上轮JVM75、host native8、JNI17、Activity/ZIP4、APK审计105及API26/29已有结果保留；本次只追加真实ARM采样/控制审查和源码/APK/格式锁完整性验证，未冒充重新执行这些整套检查。

**Remaining technical blocker = performance稳定性定性（并保留独立正式实机用例未执行的边界）。人工侧已获>40min稳定游玩、基本存储与退出进度保留反馈；≥45min时长及听音、温升/触感、可用实体外设细节尚未单独确认。** 尚不能标TECHNICAL_CLOSEOUT_COMPLETE或READY_WITH_PENDING_MANUAL，不能仅等待长测就直接Final Phase7 READY。按文档第42节，不继续扩大测试范围；后续需稳定测量条件及可访问设备，保留当前诚实的BLOCKED_ENVIRONMENT结论。Phase7.5验收继续有效。

## Physical ARM Performance A/B — 2026-10-09（此前暂停记录）

用户连接 PLG110 / API36 / arm64-v8a 后已开始真实 ARM A/B，随后明确要求暂停并保存记录。当前 **PAUSED_BY_USER / INCOMPLETE**：已保存四次完整重复、64 / 192 个计划样本；第二轮 CODE9 第二次重复期间断连，部分结果未能拉取。电脑采样进程已退出，手机端停止未确认。原数据备份已保存，但原数据及自动亮度恢复因断连尚待执行。最后确认安装为 code9，断连后未重新核验。

回来重连后优先恢复与核验，再按用户要求继续。性能定性仍待完整平衡矩阵，不宣布 PASS；Phase7 NOT READY、Phase7.5 USER_CONFIRMED_PASS、Phase8 NOT STARTED 保持。下方“未连接/未执行真机”的描述仅代表此前轮次，已由本记录更新。详见[暂停检查点](evidence/phase7_performance_coverage/physical-ab/PAUSE_CHECKPOINT.md)、[状态记录](evidence/phase7_performance_coverage/physical-ab/user-pause.json)与[证据哈希清单](evidence/phase7_performance_coverage/physical-ab/pause-evidence-manifest.json)。

## Performance & Coverage Closeout — 2026-10-09（此前收口记录）

**Phase7 — NOT READY。Phase7.5 — USER_CONFIRMED_PASS / READY。Phase8 — NOT STARTED。V1 Release — NOT READY。**

本轮按 `PHASE_7_PERFORMANCE_AND_COVERAGE_CLOSEOUT.md` v0.1 执行。用户明确要求后续任务文档默认按内容执行；原有真机总体验收 PASS 保留，但不补写不存在的机型、时长或专项记录。用户本轮确认“暂时没有，保留性能环境阻塞”。所有既有失败证据保留；本节取代下一节的前一轮状态说明。

### Frozen production / delivery

本轮只修改 Android 测试、采样/验证脚本和报告，没有修改生产代码、UI、native、权限、工具链、Game ID、Save/State 格式、Room/DataStore schema 或 ZIP 限制。没有构建新交付 APK、bump 版本、正式签名、AAB、keystore 或发布。

|项目|冻结值|
|---|---|
|当前候选|0.7.5 / versionCode9|
|Debug SHA256|`96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`|
|unsigned Release SHA256|`b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`|
|Debug certificate SHA256|`3660dfb189306e49d973a7f91c9cbc1cb35cc93921f0292e8db28b3fa10b4094`|
|mGBA / Oboe|`26b7884bc25a5933960f3cdcd98bac1ae14d42e2` / `b15f5e39c01a7ada306d959e5129620b145fb8b4`|
|存储与权限|Room2.7.2/schema3、DataStore1.1.7、raw State7/metadata1；permissions=[]|

[baseline](evidence/phase7_performance_coverage/baseline.json)、[source integrity](evidence/phase7_performance_coverage/source-integrity.json)、[APK audit](evidence/phase7_performance_coverage/apk-provenance-audit.md)记录实际哈希与独立权限/来源检查。Git/worktree 的既有 code9 未提交修改保留，没有重置或发布。

### Performance: BLOCKED_ENVIRONMENT

未连接真实 Android ARM 设备；用户明确暂不提供专用测试设备。已准备[真机执行协议](PHASE_7_PHYSICAL_ARM_PERFORMANCE_PROTOCOL.md)和 `scripts/phase7_performance_coverage.py performance --serial ... --dedicated-arm-test-device`。在测试前固定工程阈值：1×至少0.95×、2×至少1.8×，旧4×达到3.8×时新包稳定下降≥15%视为可疑；8×best-effort；重复样本与轮间漂移阈值10%。正式 `59.7275 * min(speed,4) * .85` 断言保持原样。

采样工具支持 OLD→CODE9→CODE9→OLD、四显示模式和1/2/4/8×，统一横屏/FIT/黑背景/同一ROM，记录每秒FPS、actual multiplier、display FPS、underrun delta、温度/thermal status/电量/省电状态和真实视口，并在失败时尝试恢复code9。真机工具已准备，**未执行真机A/B**，没有生成假physical CSV。

复核已有64条转译模拟器A/B：Original4×旧228.181→152.616FPS、新178.215→120.586FPS，均值相对差−21.53%；旧/新轮间漂移分别39.69%/38.57%（分母为各自两轮均值）。旧、新视口也不一致；短聚合样本没有轮内方差。现有正式Original4×失败157.8502075<203.0735保留。这是可疑下降与不稳定环境的共同证据，不能证明无回归，也不能确认生产根因；没有以“旧包也失败”制造PASS。详见[性能分析](evidence/phase7_performance_coverage/performance-analysis.md)。本轮采样器执行成功仅验证工具链路，不代替产品性能门槛。

### Coverage final classification

|项目|本轮最终分类|证据与边界|
|---|---|---|
|API26|EMULATOR_BEHAVIOR=PASS_WITH_NOTE；REAL_ARM=NOT_TESTED；FINAL=ACCEPTED_COVERAGE_GAP|复用并校验前一轮Activity、SAF、持久化、触控、Home/实际画面及PCM记录，无已知API26专项生产崩溃；早期测试设施/缓存失败保留。[API26](evidence/phase7_performance_coverage/api26-final.md)|
|API29|EMULATOR_BEHAVIOR=PASS_WITH_NOTE；HISTORICAL_SHORT_BLACK_FRAME=MONITORED；REAL_ARM=NOT_TESTED|20/20恢复端点实际红画面与焦点通过；没有持续不可恢复黑屏复现；没有根因修复声明。真实ARM为ACCEPTED_COVERAGE_GAP。[API29](evidence/phase7_performance_coverage/api29-final.md)|
|Second OEM|NOT_TESTED / ACCEPTED_COVERAGE_GAP|没有第二品牌实机，不要求额外购买。|
|Action|AUTOMATED_PASS（仅自动链路）|Blob Goes3D完整自制游戏600s输入运行，690次输入，Quick/四槽/FF/倒带/Home/退出/Continue通过；不是人工体验PASS。|
|Audio-heavy|AUTOMATED_PASS（仅pipeline alive）|Hyperspace Roll600s运行，1,075次输入，五处新PCM恢复检查通过；保留underruns，人工听音PENDING_USER。|
|Save-heavy|PARTIAL_AUTOMATED|两款完整游戏Quick/四槽/checkpoint/Continue通过；专用fixture有电池存档往返，完整游戏原生高分写入与冷启动读回未被证明。|
|RTC/sensor完整游戏|NO_APPROVED_COMPLETE_GAME_AVAILABLE|完成来源、许可证、构建前提和实际外设使用审计；两个已批准游戏不具备确认的RTC/motion/light用途，其余候选不满足许可/完整游戏条件。现有探针/host/JNI覆盖保留，未伪造新完整游戏RTC测试。|
|Phase2 State|HISTORICAL_FIXTURE_UNAVAILABLE / ACCEPTED_RISK|不再扩大搜索，不重造fixture；格式不变，现代兼容性证据保留；找到真实原始fixture再复核。|
|USB / Rumble / ASan|USB=NOT_AVAILABLE；Rumble=DEFERRED；ASan=DEFERRED/NOT_COMPLETE|Synthetic HID不能冒充真实USB；零权限不变；native未变，不扩大sanitizer范围。|

游戏数值与原始记录见[category coverage](evidence/phase7_performance_coverage/game-category-coverage.md)和[results](evidence/phase7_performance_coverage/game-category-results.json)；候选与来源见[RTC/sensor audit](evidence/phase7_performance_coverage/rtc-sensor-candidate-audit.md)。首次Blob持续音频断言不适用于事件音效的失败、修正理由与重试证据均保留于[execution notes](evidence/phase7_performance_coverage/execution-notes.md)。所有ROM仅为既有批准本地语料，没有下载或使用商业ROM。

### Targeted regression / remaining gates

本轮完整JVM75次执行、host native8项、APK/provenance105项、Activity/ZIP4项、JNI17项均通过；更新后的性能采样器1项/16个模式倍率组合执行成功，其中8个组合记录的原门槛布尔值为false。这是采集器PASS，不是产品性能PASS。记录见[final regression](evidence/phase7_performance_coverage/final-regression.log)和[采样原始行](evidence/phase7_performance_coverage/performance-harness.jsonl)。API26/29已通过的最小行为证据复用且哈希校验，未重复大规模campaign；未重跑完整UI验收、全部fuzz/迁移或新60min模拟器长测。

**Remaining technical blocker = performance classification。PHYSICAL_LONG_RUN = PENDING_USER / MANUAL_LONG_RUN_PENDING。** 人工≥45min真实游玩、听音、温升、触感、USB与RTC/sensor完整游戏真实硬件体验单列PENDING_USER；硬件不可用仍按NOT_AVAILABLE/accepted gap记录。不使用本轮自动测试或原有总体PASS填补人工长测。

已完成其余可执行技术项及明确风险分类，但不能标记TECHNICAL_CLOSEOUT_COMPLETE或READY_WITH_PENDING_MANUAL，因为性能仍阻塞。用户只反馈长测目前还不能直接Final Phase7 READY；性能定性解决后再结合正常真实游玩反馈进行最终判定。[人工反馈模板与风险处置](evidence/phase7_performance_coverage/coverage-disposition.md)。Phase7.5验收通过继续有效；Phase8仍禁止启动。

## Remaining Hardening Closeout — 2026-10-09（前一轮记录）

**Phase 7 — NOT READY。Phase 7.5 — USER_CONFIRMED_PASS / READY。Phase 8 — NOT STARTED。V1 Release — NOT READY。**

本节按 `PHASE_7_REMAINING_HARDENING_CLOSEOUT.md` v0.1 执行，覆盖当前 code9。以下历史章节和失败日志全部保留，不覆盖本节的当前状态。本轮没有修改生产代码、UI、native、权限、工具链、Save/State 格式、Game ID、Room schema 或 ZIP 安全边界；没有重新生成交付候选、bump 版本、正式签名、制作 AAB 或开始 Phase8。

### Frozen code9 baseline

| 项目 | 冻结值 |
|---|---|
|版本|0.7.5 / versionCode9|
|普通 arm64 Debug SHA256|`96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`|
|unsigned Release SHA256|`b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`|
|Debug certificate SHA256|`3660dfb189306e49d973a7f91c9cbc1cb35cc93921f0292e8db28b3fa10b4094`|
|mGBA0.10.5|`26b7884bc25a5933960f3cdcd98bac1ae14d42e2`，upstream 未修改|
|Oboe1.9.3|`b15f5e39c01a7ada306d959e5129620b145fb8b4`|
|Room / DataStore|Room2.7.2，schema3；DataStore1.1.7|
|格式|raw mGBA State7、State metadata schema1，保持不变|
|Git / worktree|基于 `b29b01cae9269c1b461d4f8fc9dab4525f6a898f` 的未提交 code9 工作区；不是声称该 HEAD 已包含全部交付修改|

[初始冻结清单](evidence/phase7_closeout/apk-sha256.json)记录实际包、生产源码哈希和 Git 状态；[最终完整性检查](evidence/phase7_closeout/final-source-integrity.json)确认交付包、普通 Debug 及冻结生产源码均未变化。配置/格式文件另有哈希记录。本轮只增加测试采样器、调整测试定位器、执行脚本并更新收尾文档。API26/29 编译的是 **TEST-ONLY 兼容测试包**，不是新的正式候选。

### Performance A/B

结论：**BLOCKED — measurement environment unstable；原正式性能断言 FAIL，疑似候选减速仍未关闭。** 未放宽门槛，也未因为旧包失败而判 PASS。

同一 API36 x86_64/arm64 translation 模拟器按 OLD→CODE9→CODE9→OLD 执行四模式、FIT、1/2/4/8×，每格预热1000ms、采样约3000ms，共64条测量。旧包为归档0.7.0/code7、同证书，SHA256 `a0cc12c18cab69a6294cdf95fafd516899cb957a1090f9897463b304aef24051`。记录 actual multiplier、display FPS、audio underrun delta、实际时长和环境信息。

|轮次|原门槛失败格数 /16|underrun delta 合计|
|---|---:|---:|
|OLD1|0|2|
|CODE9-1|8|3|
|CODE9-2|11|17|
|OLD2|8|3|

旧包自身吞吐明显漂移，例如 Original/4× 从228.18降至152.62 FPS；code9 的高倍速总体更低，这个观察不能忽略。两包竖屏 viewport 分别1035×690与1080×720，像素负载也不相同。模拟电量/温度一致不能证明宿主实际热状态稳定，逐样本宿主负载及 power-saving mode 未记录，不能据此可靠隔离真实产品开销与翻译/调度/GPU 波动。

另跑**未修改的正式性能测试**，code9 在 Original/4× 为157.8502075 FPS，低于203.0735 FPS门槛，仍 FAIL。JNI 的 FF/rewind 功能 PASS 不覆盖此性能失败。8× 为尽力模式，但没有把其原测试断言静默取消。需要稳定环境或物理 ARM 的重复受控测量，再决定是否修复生产代码；如修复须生成新候选并重验。

见 [A/B 方法及全部比较](evidence/phase7_closeout/performance-ab.md)、[64条原始 CSV](evidence/phase7_closeout/performance-metrics.csv)、[正式失败指标](evidence/phase7_closeout/formal-performance-metrics.txt)。后置 live-cache 校验因 API36 模拟器已不在线而未完成，该限制另行记录；没有宣称实际缓存已校验。

### API26/29 compatibility / API29 SAF monitor

|覆盖|本轮结果|边界|
|---|---|---|
|API26|启动/重建、SAF、Library/player 实际红帧及触控、battery/四槽/Quick/Resume、多点共5项完成通过；独立旋转/Home/前台循环1/1通过；独立非静音PCM/后台停止/恢复1/1通过；冷启动Status:ok|EMULATOR / x86_64 / PASS_WITH_NOTE；分次证据，不声称原六项一次全部通过|
|API29|6/6 PASS210.559s，包含20次SAF→player→旋转→Home→前台→实际红帧循环；独立PCM/Home/恢复1/1 PASS14.042s；冷启动Status:ok|EMULATOR / x86_64 / PASS_WITH_NOTE|
|API26/29真实ARM|NOT_TESTED|不把模拟器结果写成REAL_ARM PASS|

API29全部20次观察到实际画面与前台焦点恢复，观察用时3949–5156ms（中位4461ms），包含测试同步/任务启动，**不是连续黑帧持续时间**。没有复现持续不可恢复黑屏；历史短黑帧仍 **MONITORED**，未改 renderer/lifecycle，不能写 ROOT_CAUSE_FIXED。FD88–99、JVM线程35–38波动，短窗口未见线性FD增长，记录的 activeSurfaces 均为1；不替代长测泄漏证明。

SAF 使用真实 UI 发出 ACTION_OPEN_DOCUMENT，再以测试 provider 截获返回；没有独立自动操作外部 DocumentsUI。PCM 用原生 played/nonzero 计数，验证后台停止及返回后增长，**不等于人工听音**。

保留所有测试基础设施失败：TEST_ONLY 安装拒绝、提前关闭 shell pipe 的 UiAutomation EPIPE、显式 Intent 创建另一 Activity、0字节的旧 stress 探针缓存。最终测试使用匹配 launcher 的 Intent 和哈希正确的 bringup 探针；产品严格拒绝无效缓存，没有放宽导入校验、清数据或改生产生命周期。详见 [API执行说明与日志路径](evidence/phase7_closeout/api-compatibility.md)及 [API29逐循环汇总](evidence/phase7_closeout/api29-monitor-summary.json)。

### Second OEM / Game Category Coverage / RTC-Sensor Complete Game

第二 OEM 仍 NOT_TESTED；当前用户未记录机型/API，不按文档中的示例猜成 OPPO/Android16。保留单 OEM 覆盖缺口，没有 multi-OEM verified 结论。

action / audio-heavy / save-heavy 仍 **PARTIAL**。既有 Blob Goes3D 与 Hyperspace Roll 的约10分钟脚本证据保留，但不能补成20–30分钟实际操作/听音，也没有完整 save-heavy 游戏多次冷启动的人工记录。本轮未新增、下载、复制或上传 ROM，没有用自动探针补写完整游戏 PASS。已尝试核对合法候选，现有未批准资产不作为替代，见 [游戏清单与缺口](evidence/phase7_closeout/game-coverage.md)和原许可审查。

RTC/tilt/gyro/solar 完整游戏仍 **MISSING_COMPLETE_GAME_COVERAGE**。当前 host/JNI/外设生命周期与 manual fallback 测试通过，保留历史10分钟RTC探针结果，但不冒充完整游戏。USB 本执行环境无物理硬件；code9 Bluetooth、传感器逐项结果 NOT_RECORDED，历史 Bluetooth 人工证据保持原范围。Rumble **DEFERRED — V1 zero-permission policy**，没有 VIBRATE。见 [RTC/外设覆盖边界](evidence/phase7_closeout/rtc-sensor-coverage.md)。

### Long-run / Final Manual Evidence

用户先回复「真机验收通过」，补问后明确回复「**真机验收没有记录。暂时保持通过**」。按此保持 **overall manual PASS**，Phase7.5 **READY**；机型、API、游戏类型、连续时长、温度、电量、充电、亮度和逐项异常均不猜测。

文档要求的30–60分钟（推荐≥45分钟）真实完整游戏长测仍 **NOT_RECORDED**，分类游戏人工记录亦未补齐。它们不能由 UI PASS、模拟器 stress、probe/JNI 或 PCM 计数代替；也没有据此宣称发生真实丢档/黑屏。见 [长测证据状态](evidence/phase7_closeout/long-run.md)及 [人工验收清单](PHASE_7_AND_7_5_MANUAL_ACCEPTANCE.md)。

### Historical State Gap / Risk Disposition

搜索项目内包括 ignored evidence 的 State/SS/SAV、state.bin/proof.json 与 Phase2 APK 命名候选，排除第三方源码/.git/build；没有找到原始 Phase2 State。`test-save-v1.sav` 是 battery，不是历史 raw State。结论 **HISTORICAL_FIXTURE_UNAVAILABLE**，没有造 fixture。格式保持不变，当前 host/JNI/存档/metadata/恢复回归为替代路径证据；不声称原 Phase2 writer 已实测。搜索范围与结果见 [搜索记录](evidence/phase7_closeout/phase2-state-search.json)。

书面决定 **C7-2026-10-09**：根据任务文档允许的范围，Phase2缺档、第二OEM、API26/29真实ARM、RTC/sensor完整游戏作为明确 **ACCEPTED_RISK** 覆盖缺口保留；有替代核心路径证据，但仍可能存在历史 writer、厂商GPU/音频或完整游戏行为差异，获得原资产/设备/合法游戏后重验。USB缺硬件 NOT_AVAILABLE；Rumble DEFERRED；综合ASan仍 NOT_COMPLETE/DEFERRED，历史失败保留，native未改，不重跑所有 sanitizer。性能与有记录长测未被豁免，分类人工覆盖继续未完成。逐项缺失、理由、残余风险和重验触发条件见 [Risk Disposition / Closeout Decision](evidence/phase7_closeout/risk-disposition.md)。

### Final Targeted Regression

|项目|本轮证据结论|
|---|---|
|JVM full|75次执行，0failure/error/skip，包含Debug/Release重复执行次数|
|Host native|8/8 PASS（audio1、mGBA7）|
|JNI|17/17 PASS42.196s，含PCM、State/battery、FF/rewind、外围/RTC/关闭所有权|
|API36应用定向|首轮15项有4失败；3项旧测试定位器问题修复后重跑通过，14项不同的非性能行为最终通过；原性能项仍失败|
|Activity / navigation / Input / actual Surface|当前稳定标签定位后通过；多点/滑动、暂停/继续、传感器、真实Surface、背景与模式回归保留通过证据|
|Save / State|UI实际四槽/Quick、battery后台、改名同Game ID、重建和Continue恢复通过；未修改格式|
|ZIP security smoke|fresh JVM RomImport / Phase7LiteProtection 断言通过，保留安全边界；不再重复完整专项mutation campaign|
|APK / provenance|105/105 PASS，交付哈希及生产源码最终一致|
|API26/29新增专项|上述模拟器实际Surface、20次循环及PCM证据通过；不替代真实ARM|

旧测试修复只涉及 `player-menu` 稳定标签及 Material 合并语义按钮；仍要求唯一启用可点击节点、真实存档 manifest 更新和恢复断言。正式性能/安全断言完全保持。首轮失败及两次定位器复测分开保存，没有把日志改写成全套一次 PASS。

汇总见 [final-regression.log](evidence/phase7_closeout/final-regression.log)，JVM/native/JNI/审计/各API原始日志均在 [phase7_closeout 证据目录](evidence/phase7_closeout/)。

### Final Decision

**Phase 7 — NOT READY。** 当前阻断是未关闭的性能门槛与缺少独立记录的真实长测/分类游戏人工验收；不是撤销用户的整体验收通过。未出现新的已确认生产 native crash、丢档或ZIP绕过证据，也不能据此证明所有真实硬件项目通过。

**Phase 7.5 — READY；overall manual — PASS；Phase 8 — NOT STARTED；V1 Release — NOT READY。目前不进入 Phase8。** code9/version/hash 保持原交付值。后续先完成稳定受控性能调查以及有记录的合法完整游戏长测；若确认并修复产品回归，再生成新候选、做受影响回归。没有开始 production keystore、Release签名、AAB或商店发布。

---

以下为保留的历史收尾记录，状态、旧候选和旧 UI 验收描述仅代表其原时点。

> 2026-10-08 Phase7.5 后续更新：用户要求先完成7.5再合并验收；Round A+B UI已实现，
> Phase7/7.5仍NOT_READY，Manual PENDING_USER，Phase8 NOT_STARTED。
> 当前0.7.5候选、定向结果与合并清单见 [7.5报告](PHASE_7_5_UI_UX_POLISH_REPORT.md)。
> 下文7.5未启动、0.7.0候选及旧CI属于本报告历史收尾时点，不是当前交接包。

2026-10-08 最新剩余缺口执行（以下历史章节不作为当前阻塞清单）：
代码提交 `280782965cc2ceb4a3354ba8e26cdde1072aaae7` 已推送到用户指定仓库；
[Remote CI run37751328064](https://github.com/tritantan36-design/gba-emulator/actions/runs/37751328064)
真实SUCCESS，build397秒，artifact11537839324；JVM/lint/普通构建/host/审计通过。
API26/29 TEST-ONLY x86_64最小覆盖PASS_WITH_NOTE；API29 SAF黑帧恢复风险MONITORED。
Blob Goes 3D完整homebrew脚本10分钟PASS616.727s；Hyperspace Roll10分钟session PASS626.748s，升级脚本限制保留，覆盖PARTIAL。
游戏广度仍有限：action/audio-heavy/save-heavy PARTIAL，RTC/sensor完整游戏MISSING，物理体验待用户。
Phase2真实历史资产不可用，justified NOT_TESTED；原有renderer根因未强行关闭。
用户要求最后交付人工测试；普通Debug候选/校验值/清单/空白回填已准备，PENDING_USER。
**Phase7A / Phase7 NOT READY；7B Lite PASS；Advanced Hardening DEFERRED；7.5/8 NOT STARTED。**

当前决策与执行范围以[剩余缺口报告](PHASE_7_REMAINING_GAPS_CLOSEOUT_REPORT.md)、
[游戏执行](PHASE_7_GAMEPLAY_EXECUTION_REPORT.md)、
[CI记录](PHASE_7_REMOTE_CI_EXECUTION_REPORT.md)及
[最终人工清单](../PHASE_7_FINAL_MANUAL_ACCEPTANCE_CHECKLIST.md)为准。

---
以下为历史关闭点/证据，旧无remote、旧候选SHA、未执行API26/29等描述不代表当前状态。

Updated: 2026-10-08, Asia/Shanghai. **FINAL CLOSEOUT — NOT READY**.

## Latest final-gate summary

| Gate | Latest status |
|---|---|
|Phase7A-0|PASS_WITH_NOTE / infrastructure READY|
|Phase7A automatic gates|BLOCKED; actual Remote CI unavailable without remote/first commit|
|Phase7A|NOT READY|
|Phase7B Lite|PASS within practical fixed-fixture scope|
|Advanced Hardening|DEFERRED — PRE_PUBLIC_RELEASE_HARDENING|
|Remote CI|BLOCKED; no run ID/commit/result/artifacts|
|Manual Acceptance|PENDING_USER; checklist prepared, automatic prerequisites incomplete|
|Remaining coverage|API26/29 app, representative legal gameplay, Phase2 State NOT_TESTED|
|Remaining renderer risk|Host NVIDIA stall MONITORED/root cause OPEN; software QA MITIGATED|
|Second physical OEM|NOT_TESTED, justified nonblocking limitation under original gate|
|Final Decision|Phase7 NOT READY;7.5/8 NOT STARTED; Release unsigned|

Current candidate API36 minimal regression **5/5 PASS73.303s**, cold relaunch PASS;
installed SHA matches normal candidate. Other valid checks reused without new long-run.
See [final closeout](PHASE_7A_FINAL_CLOSEOUT_REPORT.md),
[evidence index](evidence/phase7/INDEX.md), and
[manual checklist](../PHASE_7_FINAL_MANUAL_ACCEPTANCE_CHECKLIST.md).
Earlier report sections below retain historical runs; latest candidate metadata is
evidence/phase7/7a-final-closeout/candidate-apks.json. Original failures are retained.


Subsequent independently authorized Phase7B Lite: **PASS within practical scope**;
see [Lite report](PHASE_7B_LITE_PRACTICAL_ROBUSTNESS_REPORT.md) and ADR-019.
Advanced Hardening is **DEFERRED — PRE_PUBLIC_RELEASE_HARDENING**. 7A/manual/CI
gates are not waived; Phase7 remains NOT READY,7.5/8 NOT STARTED. Earlier7A APK
hashes and specialist execution statements below describe their historical candidates;
current7B APKs/evidence are in the Lite report. The pre-Lite version of this report is
preserved at evidence/phase7/7b-lite/prior-phase7-report.md.

This report consolidates the Phase7A ordinary QA report, Phase7A-0 infrastructure
report and preserved earlier specialist findings. It does not authorize Phase7B,
Phase7.5 or Phase8. Only actual executed checks are described as passing.

## A. Baseline

Phase0–6 approved reports retained. Baseline version0.6.0/code6; current0.7.0/code7.
Frozen core/toolchain/format details: `PHASE_7A_COMPATIBILITY_STABILITY_RELEASE_QA_REPORT.md`
sectionA and `evidence/phase7/baseline.json`. PROJECT_SPEC/ARCHITECTURE unchanged.

## B. Changed Code

Phase7 fixes periodic A/B/C checkpoint rotation, narrow importer cleanup, artwork
cache eviction/low-memory handling and native control-lock yielding; ADR017.
JNI Debug test declarations isolated from Release. Phase7A-0 changes only scripts,
documents and development SDK/AVDs, no product/core/permission/ABI change; ADR018.
All prior modifications retained. No source rollback, upload or Git commit made.
Resumed7A adds acknowledgement of the existing ordered ViewModel lifecycle
commands; tests distinguish their completion from a periodic-checkpoint PAUSED
state. Strict background zero-frame assertion retained; no native/Session policy
change. This post-infrastructure observation correction is recorded in ADR017.

## C. Compatibility Matrix

See `PHASE_7_COMPATIBILITY_MATRIX.md`; individual passing probes do not establish
all-game compatibility. Internal legal assets only. New targeted retests are not
mislabelled as a full suite on the new emulator target.

## D. Test ROM Corpus

Self-authored ROMs and pinned selected MIT shifter tests;70/70 expected shifter
cases passed. Full upstream suite/toolchain and broader legitimate gameplay
categories incomplete. No commercial ROM/BIOS collected or bundled.

## E. Android API Matrix

Current normal candidate API36 targeted5/5 PASS73.303s; software GPU, official ARM
translation. The following7A-0 three-test timings belong to older candidates.

7A-0 primary API34 official Google image with actual ARM bridge is operational.
API34/API36 minimal instrumentation3/3 each passed; real SAF, orientation, restart
and evidence collection verified. API31 earlier targeted, RTC, upgrade and resource
results retained. API26 x86 boots but original arm64 APK cannot install; API26 ARM
cannot boot on x64 host. API29 has no matching ARM ABI. These gaps are NOT_TESTED,
not product passes. Details:7A-0 report sectionsE–N.

## F. Multi-device Results

Only one physical OEM/API36 phone available. Emulator API coverage does not
constitute additional physical OEM coverage. Physical second-device coverage NOT_TESTED.

## G. Long-run Results

Phone long-run USER_STOPPED, last valid sample815002ms/14 cycles, not60min PASS.
No phone restart. API34 Emulator run started2026-10-08 around00:02+08 and failed
at1226261ms (20min26s),20 cycle samples, final incomplete event. Instrumentation
FAIL1228.019s: background frames2482→2483 at a periodic-checkpoint/lifecycle boundary.
Original log/metrics preserved. Acknowledged checkpoint/Home regression passed
54.829s/8 cycles with the same strict five-second invariant. Full retry started
2026-10-08 around00:31:51+08, FAILED3006.396s; metrics3004375ms/48 cycle samples,
incomplete event. Home/onStop wait timeout with Session RUNNING; logs show PAUSED
then onStop delayed approximately101s, GPU/frame completion stalls approximately99s.
Root cause not established; no matching host sleep events returned, AC standby0.
Same official API34 image now uses SDK software/Google SwiftShader for isolation;
no driver/Windows setting/app changes.50-cycle explicit Home and100 actual shader
changes targeted tests PASS337.991s.50 Home cycles verify actual lifecycle
acknowledgement then five seconds of zero frames;100 mode changes cover all four
modes/context52 and actual nonblack bitmaps.

Completed software/Google SwiftShader API34 run: **PASS**, instrumentation
3614.31s; metrics3612378ms (60min12.378s),62 samples,60 cycle samples and final
complete event. Start approximately2026-10-08 01:38:38+08; complete02:38:51+08.
Evidence:7a-software-api34-sixty-minute.log and7a-software-api34-longrun-final-*.
This is one real elapsed mixed session including pauses, not combined attempts or
60 minutes of uninterrupted foreground CPU/physical gameplay.50 orientation/Home/
ROM-switch cycles (150 orientation transitions) completed.120 mode selections mean
90 effective changes; the separate100 actual-change test supplies that stress gate.
The loop's rewind branch is conditional and was not individually traced/counted;
do not claim60 executed rewind actions. Existing independent rewind checks remain
separate functional evidence. No new full15/43-test suite is claimed.
Captured app/PID/event/crash evidence contains no observed app FATAL/native crash/
ANR; this is the captured window, not all-driver certification. Actual final-game
PNG was saved and inspected: colored internal test frame and touch controls visible.
The old host/NVIDIA stall remains unresolved; software PASS does not erase it.

## H. Memory / Heap

Completed API31 100 IO evidence: RSS start/peak/end275744/280020/276812KiB.
Failed API34 run RSS261512/269280/259528KiB; native heap27890928/32165328/28861792
bytes; Java27899928/27899928/6681712bytes; PSS163764/168229/160192KiB
(start/sampled peak/end). The completed independent software run is below.
Translated native-heap0 readings mean unavailable;
not zero-allocation or proof of no leak. No physical thermal certification.

Completed software long-run (start / sampled peak / end):

| Metric | Start | Sampled peak | End |
|---|---:|---:|---:|
|RSS KiB|246300|269620|269476|
|Native heap bytes|27697856|32336704|28567456|
|Java used bytes|7713168|16086592|7322568|
|PSS KiB|148622|168205|165707|
|FD|151|160|157|
|OS threads|40|53|46|
|JVM threads|32|49|43|

Source:7a-software-api34-longrun-final-summary.json. Sampling at cycle boundaries
can miss transient peaks, including between state/ROM resets. Native heap and
Java used return near their measured baselines; RSS/FD/threads finish above start.
Finite bounded observations are not proof of zero leaks or a complete allocation
profile. Per-core underrun sampled peak1146, final0 after stop is a counter reset,
not zero underruns or a human audio-quality PASS; counters reset on ROM changes.
Final Session STOPPED, rewindBytes0. Pre-runner-teardown renderer snapshot still
shows1 texture/1 program/2 buffers/1 Surface: no claim all GL objects had already
been released. Passive query after runner teardown found no application PID;
process termination is not proof of earlier per-object teardown. No physical
thermal/battery, comprehensive ASan or fuzz evidence is added.

## I. FD / Thread

Completed100 IO bounded-growth assertions passed: FD143/144/140, OS threads47/47/44,
JVM43/43/41. Latest API31 repeat also finished100 IO in579893ms. Completed software
long-run FD151/160/157, OS40/53/46, JVM32/49/43. Failed first API34 FD153/160/125,
OS threads39/49/47, JVM31/45/44. No general absence-of-leaks claim.

## J. Lifecycle Stress

Existing recreate/pause/foreground/exit, controlled process death and selected
Home audio/frame checks passed. API34 original sensor/orientation/Home/exit failure
retested unchanged and passed. Checkpoint/Home contention passed8 cycles after
adding actual lifecycle acknowledgement. Later50 Home/checkpoint cycles PASS
337.991s alongside100 actual mode changes; complete software run also verifies
50 Home/foreground/ROM-switch cycles and150 orientation transitions. Host-GPU
failed run/stall retained; not resolved by software PASS.
No forced Session foreground override used to create a pass.

## K. Renderer Stress

Original/Sharp/GBA Color/LCD and viewport/fallback coverage retained. Two previous
API31 settings/performance failures retested unchanged on API34 and passed as part
of3/3 targeted86.557s run. Fullscreen tutorial was observed/dismissed in infrastructure
setup. Historical black-screen original root cause remains unconfirmed. Host GPU
warnings recorded in7A-0; visible screenshots/smoke pass does not certify all drivers.
Separate100 actual mode changes PASS, all four modes/context52/nonblack bitmap
assertions;100 real changes are not confused with120 selections/90 changes in
the full long-run. Final pre-teardown GL counts remain1/1/2/1; no all-zero claim.

## L. Audio

Host PCM checks and API34/36 Home stop/foreground resume counters pass. Native
1x return and pacing assertions passed targeted API34. Real audible quality, latency
and Bluetooth/USB audio routing require physical acceptance; emulator is insufficient.

## M. Input

Prior synthetic touch/HID tests retained. Phase0–6 physical Bluetooth acceptance
is historical. Current Phase7 physical HID/manual feedback pending; USB NOT_TESTED.
No new Bluetooth permission; system handles pairing.

## N. Sensors / RTC

Existing scalar/RTC checks retained; independent API31 wall-clock check639.010s
passed. API34 sensor register/unregister/rewind lifecycle targeted check passed,
not proof of actual motion/light behavior. Rumble DEFERRED—V1 zero-permission policy.

## O. Library / ZIP

Existing ordinary ZIP/import/cancel/deadline tests and UI/Room1000-record/cache
stress passed. Real API34 SAF picker, GBA/ZIP import and cancellation/reopen verified.
API36 real SAF GBA import verified. These do not establish malformed/fuzz coverage.

## P. Persistence

Battery/state separation, Quick/Slot, A/B/C autosave and100 IO regression evidence
retained; normal injected write/commit failures passed. GameId/source/save formats
unchanged. Existing Phase7IoFailureTest XML:3/3 PASS in0.721s, already in the61
normal executions. Injected directory-fsync failure, actual missing-source rename
failure and injected ENOSPC preserve the previous committed manifest/battery.
No actual full-drive exhaustion or universal IO failure coverage is claimed.
Last completed checkpoint is the sudden-process-death guarantee, not retention
of every frame. No new execution was needed for this evidence correction.

## Q. Room / DataStore Upgrade

Explicit1→2→3 schemas, no destructive fallback. Actual Phase6 APK data upgraded
on isolated AVD, verification18.534s passed after seed12.570s. Controlled process
death/new PID recovery9.451s passed. Actual Phase3–5 native State reads passed;
Phase2 actual archived fixture unavailable. No user-phone downgrade/clear.

## R. Malformed ROM / ZIP

Historical advanced campaign is deferred. Subsequent7B Lite fixed ROM/ZIP
fixtures PASS; production import/native small-ROM boundaries fixed with regressions.
See Lite sectionsB–E. No new fuzz campaign or all-parser audit is claimed.

## S. Fuzz

NOT COMPLETE. Earlier raw native parser harness found a small-header bounds
failure at mGBA vfame.c:63; that historical raw-harness result did not establish
production adapter reachability. Lite subsequently added bounded owned backing for
the identified small-ROM detector reads and fixed-fixture JNI passes; this does not
close arbitrary-input parser audit or establish full fuzz safety.
Earlier JVM bounded mutation is not full fuzz PASS. No new fuzz run here.

## T. UBSan

Full-dependency UBSan NOT COMPLETE. Earlier fully instrumented one-shot halted on
signed-left-shift at mGBA util/hash.c:32; this finding remains open/deferred. Subsequent
existing Android bridge/audio/Oboe UBSan:JNI17/17 andActivity15/15 PASS. The pinned
mGBA target is not instrumented by that switch; see Lite sectionJ/build flags.

## U. ASan

NOT COMPLETE. Earlier Windows attempt lacked required runtime; earlier native
test crash evidence retained. No comprehensive ASan PASS, no new execution here.

## V. Native Hardening

Existing build flags/source remain. No new Release ELF specialist validation in
7A-0/resumed7A; advanced ELF validation is DEFERRED with its own future proof required.
Lite is PASS within its distinct practical scope. No security-policy bypass.

## W. Dependency / License / Provenance

Prior ordinary audit passes; pinned official sources/licenses and test manifests
retained. No unknown application.so, runtime networking/ads/analytics SDK added.
New emulator images are official SDK development components, not application payloads.

## X. CI

Pinned ordinary workflow configuration exists. Mandatory real remote CI BLOCKED:
no Git remote and no first commit/HEAD; run ID/result/duration/artifact unavailable. Local builds do not count as remote
CI. No source upload or remote repository creation authorized/performed.

## Y. APK Audit

Current post-Lite ordinary candidates: Debug `a0cc12c18cab69a6294cdf95fafd516899cb957a1090f9897463b304aef24051`;
unsigned Release `6e30e42213e043ee7408f4d2ccf520b2056189cb6629b9beab9a67d81c605905`.
Closeout SHA/permission dumps match archived and build-output APKs; no production
change/rebuild in this closeout. Build-output timestamps/UNAVAILABLE_NO_HEAD in
candidate-apks.json. No two-clean-build claim for this new SHA. The reproducibility
paragraphs below describe older7A candidates only.

Permissions empty; no ROM/ZIP/BIOS/test providers/Debug JNI probes in Release.
Prior two clean unsigned Release builds/hashes retained; prior SHA256
`079ad749f9b0dbb227b77a0854372729fae485329856ea459fb151144f387696`.
7A-0 did not change Release. Subsequent7A lifecycle acknowledgement requires a
new candidate: two clean builds bit-identical with unchanged dependencies;
`7a-lifecycle-ack-release-reproducibility.json`, SHA256
`77dbada49b1099b96ead34de3cc39eb92fc06f4e252ba1d33af685d3861d4fb7`.
New candidate ordinary APK/provenance audit PASS; lint0errors/4warnings;
Home audio/frame invariant PASS7.638s. Old source-set audit evidence retained.
Release unsigned; no production keystore or release authorization.

## Z. Manual Acceptance

**PENDING_USER**. Checklist prepared at docs/PHASE_7_FINAL_MANUAL_ACCEPTANCE_CHECKLIST.md;
automatic gates remain BLOCKED, not final-signoff ready. User agreed to inspect their legitimate local RPG;
agreement is not PASS. No game name/ROM/screenshots requested or collected.
Physical HID/sensors/OEM/audio/GPU/thermal/final gameplay cannot be substituted
by emulator results. Feedback requested without starting a new manual session.

## AA. Known Issues

Historical renderer root cause unconfirmed; official translated emulator performance
varies. Original API31 failures preserved despite all five targeted API34 retests
passing. SDK download fallback/host graphics/script UI limitations recorded in7A-0.
Historical upstream/full-dependency findings remain open; Lite production boundary
fixes and fixed-fixture retests are recorded separately. Host/NVIDIA99-second graphics
stall remains unconfirmed despite completed software isolation; no physical fix claim.

## AB. Risks

API26/29 arm64 coverage, broader legal gameplay and physical routing/HID coverage
incomplete; single OEM. Native8x best effort. No long-term physical thermal/battery
certification, no real remote CI, no comprehensive sanitizer result, unsigned Release.

## AC. Unfinished

| Gate | Status |
|---|---|
|7A-0 Emulator infrastructure|PASS_WITH_NOTE / READY|
|Paused five ordinary failed assertions|Targeted API34 PASS; original failures preserved|
|60-minute mixed stability/resource analysis|Software API34 PASS3614.31s; two host failures retained; phone stopped|
|Home/checkpoint and real shader changes|50 cycles /100 changes PASS337.991s|
|API26/29 application coverage|NOT_TESTED—official available image/ABI limits|
|Remote CI|BLOCKED—no remote/first commit/HEAD; configuration is not a run|
|Final physical/manual acceptance|PENDING_USER; prepared checklist, untested hardware|
|Phase2 historical raw State|Fixture unavailable|
|7B Lite practical robustness|PASS; full scope/evidence in Lite report|
|Advanced Hardening / full-dependency findings|DEFERRED — PRE_PUBLIC_RELEASE_HARDENING; historical findings retained|
|V1 signing/release|NOT READY; unsigned|

## AD. 是否允许进入 Phase 8

**NOT READY — 不允许进入 Phase 8。**

7A-0基础设施就绪只支持继续Phase7A，不等于Phase7完成。缺失的CI、兼容性、
人工证据不能改写为PASS。7B Lite通过不补齐7A门槛。Phase7.5/8均未启动，V1 Release仍未就绪。
