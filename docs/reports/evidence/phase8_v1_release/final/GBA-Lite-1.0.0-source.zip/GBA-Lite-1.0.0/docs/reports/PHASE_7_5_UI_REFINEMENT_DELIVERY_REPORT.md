# Phase 7.5 UI refinement delivery — 2026-10-09

用户确认统一打包本批 UI 修改。候选为 0.7.5 / versionCode 9，普通 arm64-v8a Debug，沿用之前的开发签名，可覆盖 code8。它是人工验收包；生产签名未配置。unsigned Release 仅审计归档。

## 本次内容

- 竖屏画面适度下移；紫、白、黑、红四种塑料外壳，颗粒、高光、扬声器孔和银灰倒角按键。
- 背景设置仅作用于竖屏外壳；渲染画面边距与横屏背景固定黑色。
- 横屏暂停主菜单按内容收窄；横屏键位编辑使用独立页面，暂停画面预览与工具区分开，支持拖动、大小、透明度、保存和取消。
- 设置最外层保留分类图标；二层条目使用 18sp 半粗体，分组标题 16sp 半粗体；选中项显示勾。
- 外设按手柄、动作感应、光照感应、时钟与震动整理；设备可用性与游戏检测分别显示；无游戏时校准和手动动作入口禁用。
- 控制页专注触控布局，手柄说明归外设；自动保存与恢复归存档。
- 包含此前首页及游戏库长按多选批量删除；原 ROM、存档和截图保留。

## 验证

- Debug、unsigned Release、全项目 JVM test、Lint、AndroidTest 编译和依赖导出：BUILD SUCCESSFUL，1m58s。外设测试定位同步后额外 AndroidTest 编译通过（9s），产品 APK 未再次修改。
- JVM XML：75 次执行，0 失败、0 错误、0 跳过；包含 Debug / Release 重复范围，不代表 75 个不同用例。
- Lint：app 0 错误 / 21 警告；feature-player 0 / 8；renderer 0 / 2。警告包含冻结依赖更新建议、ABI、Configuration 尺寸、Modifier 参数、ViewConstructor、UseKtx 等；未压制警告或升级依赖。
- 最终 code9 候选，API36 / emulator-5574：单次 **19/19 PASS，132.11s**。TouchUiPolishTest 13、BatchDeleteGamesTest 3、PeripheralExperienceTest 2、横屏黑色边距与设置保存 1。
- APK / 来源审计：105 项 PASS、0 FAIL；arm64 only、权限为空、交付包无 ROM / BIOS、无测试 provider / instrumentation 类及 sanitizer 泄漏。
- apksigner 验证通过。证书 SHA256：`3660dfb189306e49d973a7f91c9cbc1cb35cc93921f0292e8db28b3fa10b4094`，与之前候选一致；模拟器已成功覆盖升级至本候选。
- Debug 原生桥二进制与 batch-delete 候选相同；源码工作区变化、包大小、SHA256、Lint 与 JVM 统计保存于本机 metadata。

## 安装包

[可安装 Debug APK](evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-ui-refinement-code9-debug.apk)，19,844,078 bytes。

SHA256：`96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`。

unsigned Release：16,420,755 bytes；SHA256：`b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`。

本机证据位于 `docs/reports/evidence/phase7_5_touch_ui/`，包括 `ui-refinement-delivery-build.log`、`ui-refinement-delivery-device-tests.log`、`ui-refinement-apk-audit.md`、`ui-refinement-signature.txt`、`ui-refinement-delivery-metadata.json`。APK 和证据未上传公开仓库。

## 验收边界

2026-10-09，用户在本 APK 交付后回复「真机验收通过」，本批 code9 交付整体人工验收记录为 **USER_CONFIRMED_PASS**，本批 UI 交付完成。

机型/API、游玩时长、蓝牙手柄和传感器等逐项数据未提供，记录为未记录；不补填独立硬件测试结果。[合并验收记录](PHASE_7_AND_7_5_MANUAL_ACCEPTANCE.md)同步更新。历史性能门槛及 Phase7 其他独立缺口仍沿用原报告状态，本次整体验收不构成那些开放项的独立关闭证据。
