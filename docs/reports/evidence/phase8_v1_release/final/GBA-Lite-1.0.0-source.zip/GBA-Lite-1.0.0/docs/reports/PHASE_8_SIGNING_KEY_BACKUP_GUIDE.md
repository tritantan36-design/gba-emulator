# Production Signing Key Backup Guide

长期升级身份已创建，未将私钥或密码放入仓库、报告、证据、APK或source archive。

- Keystore：D:/GPT/secure/gba-lite-signing/gba-lite-release.jks
- 凭据：D:/GPT/secure/gba-lite-signing/signing.properties
- Alias：gba-lite-release；RSA4096；证书CN=GBA Lite。
- 创建日期：2026-10-10（Asia/Shanghai）；有效期结束：2054-02-25。
- 证书SHA256：`ac0f13a8cfe4cf1dddee8132b02c34c4013163708662e6f0c3522c6ceba10d5f`。

**用户需要将keystore和signing.properties安全备份到至少两个独立位置。** 使用受控、加密且独立的存储，分别验证可读性并妥善保管访问凭据。不要把它们上传Git、复制到evidence或随APK交付。备份执行尚未由用户确认，本轮只提供指南。

Production keystore是未来升级身份。丢失后可能无法用同package identity正常升级已安装正式版本；后续版本应复用此密钥，不能每次重新生成。

本机目录已去除继承权限，仅当前用户与SYSTEM有完整访问。构建脚本从外部配置读取密码，通过环境传递至官方keytool/apksigner，不打印秘密。
