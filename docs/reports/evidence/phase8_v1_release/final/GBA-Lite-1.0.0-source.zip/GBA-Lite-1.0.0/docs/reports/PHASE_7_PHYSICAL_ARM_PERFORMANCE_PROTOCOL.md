# Phase 7 physical ARM performance protocol

Frozen production: 0.7.5 / code9. This protocol is prepared, not a physical test result.
The formal renderer performance assertion remains unchanged. No production APK is rebuilt.

Use a dedicated arm64 Android test device with USB debugging enabled. The instrumented
test opens a generated project probe and changes test settings/private save files.
OLD → CODE9 → CODE9 → OLD includes an in-place package downgrade; do not use the user's
only installation containing valuable saves. No clear-data or uninstall command is used.
Code9 restoration is attempted in `finally`, including on test failure. Both candidate
packages retain the existing debug certificate. Review platform downgrade compatibility
and keep an independent backup before choosing the dedicated device.

1. Build only `:app:assembleDebugAndroidTest`; retain frozen OLD and code9 APKs.
2. Run `adb devices -l`, select the exact dedicated device serial. Battery must be above
   50%, battery saver off. Keep brightness constant, charging disconnected if feasible,
   comparable starting temperature, other apps idle, and audio output route unchanged.
3. From the repository, run with the configured Python runtime:

   ```powershell
   python scripts/phase7_performance_coverage.py performance --serial DEVICE_SERIAL --dedicated-arm-test-device
   ```

   The explicit option authorizes test-package installation and candidate replacement
   on that selected test handset. Already existing evidence is never overwritten.
4. All four modes run at 1/2/4/8×, landscape, FIT and black background, same generated
   ROM and production-default audio. Each cell warms up 2s and measures 10s; three
   repetitions per candidate round, 30s recovery between rounds. Total ~40 minutes.
   Check the device has actually returned to a comparable temperature before interpreting
   a round; a fixed 30s delay alone does not establish thermal recovery.
5. Preserve logs, environment dumps, JSONL, CSV and restoration outcome. Each sample
   records before/after battery, power saver and available thermal status. The renderer
   snapshot includes the real viewport: compare dimensions across candidates. Review
   Oboe output route/sample counters separately if output differs.

Predeclared engineering thresholds (stored before sampling in evidence): 1× minimum
0.95 actual multiplier; 2× minimum 1.8; 4× new consistently ≥15% lower is suspicious
when OLD reaches ≥3.8×; 8× best effort. Maximum per-cell repeated CV and between-round
relative drift are 10%. These thresholds never replace the formal FPS gate.

Analysis outputs means, relative difference, within-round repeated CV and between-round
drift. `analysis.json` conservatively remains BLOCKED_ENVIRONMENT until the environment
and viewport controls have been reviewed. Then document exactly one outcome:
PASS_NO_MEANINGFUL_REGRESSION, PASS_WITH_NOTE, REGRESSION_CONFIRMED, BLOCKED_ENVIRONMENT.
Do not infer PASS from OLD also failing. A repeatable regression requires reproduction
and cause investigation; investigate UI composition, viewport, pacing and audio/session
scheduling before touching the frozen native core.

No physical device was connected when this protocol was prepared. This is separate
from PENDING_USER real gameplay/listening/thermal/touch acceptance.
