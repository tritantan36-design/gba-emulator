# Phase7 + Phase7.5 合并人工验收

> 当前收口基线为code13，code12交互/音频专项及code13边缘调整均USER_CONFIRMED_PASS；下方code9整体与>40min反馈继续有效。当前判定见[唯一权威](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)，不要求重复已有长测/基础存储。

2026-10-10：用户对code12正反横屏、D-pad各专项和1×/2×/4×/8×及切回/Pause/Home/Rewind音频回答“都没问题”；另确认无明显卡顿/掉速/异常发热，code13边缘调整通过，停止正式A/B并接受未认证风险。见[直接反馈](evidence/phase7_final_consolidation/manual-feedback-20261010.json)。

2026-10-09。本次 code9 APK 整体真机验收：**USER_CONFIRMED_PASS**。

2026-10-09 新增人工长时间游玩反馈：**超过40分钟游戏运行稳定，能够进行存储操作，退出后保留刚刚进度**。这三项记为 USER_CONFIRMED_PASS；具体存档机制与精确分钟未提供，不补写≥45分钟、四槽/Quick/Battery独立测试或强杀冷启动结果。声音、温升/电量和实体外设细节仍未单独记录。原始反馈见 [记录](evidence/phase7_performance_coverage/manual-feedback-20261009/feedback.json)。

用户在交付后的回复为「真机验收通过」。本批交付验收完成；用户未提供机型/API、游玩时长及逐项结果，下面保留为未记录，不据此推断各硬件项目独立通过。
2026-10-09 Remaining Hardening 补问后，用户明确回复「真机验收没有记录。暂时保持通过」。按此保留 overall manual PASS；不补写逐项记录，也不据此豁免 Phase7 性能与有记录长测的要求。
本次安装普通 arm64-v8a Debug 0.7.5 / code9；unsigned Release 仅校验归档，不能直接安装。
不要安装 compat / TEST-ONLY 包。不要为签名冲突卸载或清除旧数据，先反馈错误。

本次候选包含此前批量删除、四种游戏机外壳、横屏紧凑菜单及独立编辑页、设置分组与字号调整。
[安装新的普通arm64 Debug APK](evidence/phase7_5_touch_ui/manual-handoff/GBA-Lite-0.7.5-ui-refinement-code9-debug.apk)。
版本为0.7.5/code9，沿用旧开发证书，可覆盖升级；旧候选保留归档。
Debug SHA256：`96a0f0fd83112b26979312365c1a8b89829d2e7bb8c870cd7c0ecf570d47b148`。
Release SHA256：`b30e07482b1c75ade84b4fe955ebdcce8a3edb52d33d434d4fefb1700fd0fea5`。
同目录 UI-REFINEMENT-SHA256SUMS.txt 可核对。源码工作区清单与包身份见本机 `ui-refinement-delivery-metadata.json`，交付记录见 [本轮报告](PHASE_7_5_UI_REFINEMENT_DELIVERY_REPORT.md)。无需提供 ROM 或 BIOS，使用自己的合法本地游戏。

建议顺序：安装并核对版本 → 首页/游戏库/设置浏览 → 一次30–60分钟实际游玩，穿插存读档、快进、倒带、旋转及后台 → 回填。
逐项明细未单独提供，表中 NOT_RECORDED 不影响上述整体验收结论；若补充记录，可填写 PASS / FAIL / NOT_AVAILABLE，失败附复现步骤。
缺少硬件或游戏不算通过。实际游玩时长、游戏类型、充电/亮度及中断情况单独记录。

| 项目 | 操作与通过条件 | 结果 |
|---|---|---|
| 长按多选/批量删除 | 首页最近游戏、继续卡片和游戏库可长按多选；搜索后全选范围准确；取消/返回不删除；确认后两页更新，原ROM及全部存档/截图保留 | NOT_RECORDED |
| 四种竖屏外壳 | 紫/白/黑/红塑料外壳、颗粒与银灰倒角按键；背景设置仅改变竖屏，横屏始终黑色；颜色重开保持 | NOT_RECORDED |
| 横屏独立编辑 | 左侧暂停画面预览和拖动、右侧调节工具、顶部保存；互不遮挡；保存重开一致，取消丢弃未保存改动 | NOT_RECORDED |
| 设置分组与字号 | 外设分手柄/动作/光照/时钟与震动；控制专注触控布局，自动恢复归存档；子页无重复分类图标，条目放大加粗，选中显示勾 | NOT_RECORDED |
| 保存轻提示 | 保存布局后中央短提示自动消失，页面不位移，期间滑杆/拖动可用；失败不报成功 | NOT_RECORDED |
| 新默认/旧布局 | 先确认升级后自定义布局未变；需要新默认时，再按方向手动“恢复默认”并保存 | NOT_RECORDED |
| 纯十字键 | 透明四角不触发；上下左右、斜向滑动、方向+A/B、多指松开、旋转/后台不粘键 | NOT_RECORDED |
| 银灰控件/透明度 | 十字键三角凹刻，A/B银灰圆面，L/R镜像肩键，SELECT/START/MENU小圆钮；横屏默认40%；调整透明度、重开及旋转后保持，竖屏不受影响 | NOT_RECORDED |
| 外部继续/紧凑暂停 | 一级面板外点击继续且不误按游戏键；二级外部不恢复；横屏六主项及截图/设置均可用 | NOT_RECORDED |
| 刘海/安全区/预览 | 画面3:2无裁切；编辑器与游戏键位/大小对应，挖孔及手势区不遮挡关键按键 | NOT_RECORDED |
| 启动/SAF/ZIP | 系统文件选择器导入合法 GBA / 单游戏 ZIP，重复不多条，取消不留半条 | NOT_RECORDED |
| 首页 | Continue 清楚、最近游戏可达，不遮挡状态栏 | NOT_RECORDED |
| 游戏库 | 搜索/排序/详情/重命名正常，长名称不挤出操作 | NOT_RECORDED |
| 详情/移除 | 主按钮明显，管理操作有层级；移除不丢存档 | NOT_RECORDED |
| 空/加载/错误 | 提示和操作明确、可取消/重新选择 | NOT_RECORDED |
| 设置导航 | 7分类；二级只有顶部返回，底栏只在根页；系统返回逐级正确 | NOT_RECORDED |
| 设置实际生效 | 显示、输入、外设偏好重开保持；关于/许可可读 | NOT_RECORDED |
| 小屏/大字体 | 调大字体，文字不覆盖按钮，全部操作可滚动到 | NOT_RECORDED |
| 竖屏控件 | D-pad/A/B/L/R/Start/Select清楚，菜单可达，视觉与点击位置一致 | NOT_RECORDED |
| 横屏/反横屏 | 同一风格，无黑屏、画面比例变化或遮挡 | NOT_RECORDED |
| 多点/滑动 | 方向滑动、A+B、L+R，多指松手/旋转/后台无粘键 | NOT_RECORDED |
| 布局编辑 | 竖/横独立；拖动、单个/整体大小、透明度、默认、保存重开一致 | NOT_RECORDED |
| Pause | 六操作易找，暂停画面冻结，继续恢复；返回子页不误恢复 | NOT_RECORDED |
| 基本存储操作（机制未区分） | 用户确认能够进行存储操作；不推定具体槽或Battery机制 | USER_CONFIRMED_PASS |
| 退出后保留进度 | 用户确认退出后保留刚刚的游戏进度；强杀/冷启动细节未提供 | USER_CONFIRMED_PASS |
| Quick Save/Load | 保存后改变进度，再读取，缩略图/时间/进度对应 | NOT_RECORDED |
| 四个手动槽 | 分别保存读取，不互相覆盖；空槽不可读 | NOT_RECORDED |
| 游戏内 Battery | 游戏内保存、退出重开仍在，旧即时存档不回滚正常存档 | NOT_RECORDED |
| 自动恢复 | Home返回、退出冷启动 Continue 恢复最近成功 checkpoint | NOT_RECORDED |
| 快进 | 2/4/8×持续与按住，恢复1×及声音正常，8×尽力模式 | NOT_RECORDED |
| 倒带 | 按住倒带、松手继续，无粘键/黑屏，Battery不回滚 | NOT_RECORDED |
| 四显示模式 | Original/Sharp/GBA Color/LCD、Fit/Integer、黑白背景实际正常 | NOT_RECORDED |
| 真机音频 | 正常游玩、快进切回、后台无杂音/重叠音频/后台持续出声 | NOT_RECORDED |
| 蓝牙手柄 | 配对、触控合并、断开重连无粘键 | NOT_RECORDED |
| USB HID（如有） | 连接、输入、断开重连 | NOT_RECORDED |
| RTC（支持游戏） | 时间推进、后台/State/重开符合游戏预期 | NOT_RECORDED |
| Tilt/Gyro（支持游戏） | 校准、方向、旋转及后台恢复正确 | NOT_RECORDED |
| Solar（支持游戏） | 手动值和真实光照（设备支持时）正确 | NOT_RECORDED |
| 截图 | 保存私有游戏截图，不混入触控和菜单；缩略图正确 | NOT_RECORDED |
| 30–60分钟游玩 | 稳定性及存储反馈；声音、热量/电池等专项分别记录 | USER_CONFIRMED_STABILITY_PASS（>40分钟）；精确时长及专项细节未记录 |
| 视觉/舒适度 | 字体、对比、按钮反馈、单手/双手触感是否接受 | NOT_RECORDED |

请分别记录 platformer / action / audio-heavy / high-load-3D / save-heavy / RTC-sensor 的类型与实际分钟。
已补入用户>40分钟实际游玩稳定性与基本存储反馈；现有模拟器/探针结果不能替代未单独反馈的真机 HID、声音、热量、触感或完整游戏类型。
本次模拟器加速性能门槛未全部通过，旧包对照也失败；仍为独立开放项，不能仅以视觉验收代替。
已知限制：API26/29真实ARM与第二OEM未测；API29历史SAF短暂黑帧仍MONITORED；
Phase2历史State缺档；action/audio-heavy/save-heavy覆盖PARTIAL，RTC/sensor完整游戏MISSING。
Rumble仍DEFERRED，保持零权限。这些独立开放项的接受或关闭情况未单独记录。

回填模板：

```text
日期/机型/OEM/API：
安装包SHA256：
实际游玩游戏类型/分钟/中断：
充电/亮度/热量电池：
上表各项结果（失败注明最短复现步骤）：
缺少的游戏类型或硬件：
UI视觉/触控舒适度是否接受：
已知限制是否接受（逐项）：
最终人工结论：PASS / FAIL / 尚未完成
```

本批 code9 UI 交付已获用户真机验收通过。Phase7 历史独立开放项仍需按各自证据判断；Phase8 NOT_STARTED。
