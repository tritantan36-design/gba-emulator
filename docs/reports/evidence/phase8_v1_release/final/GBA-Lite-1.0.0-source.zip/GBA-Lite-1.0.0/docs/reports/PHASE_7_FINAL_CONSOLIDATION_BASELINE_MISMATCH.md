# Phase 7 Final Consolidation — BASELINE_MISMATCH

2026-10-10。**预检停止，不是最终收尾报告。** 未修改生产源码、未 bump 版本、未构建 APK、未重跑测试、未冻结或更新最终权威结论。

本轮输入文档第 2 节明确：“如果当前源码已经高于 0.7.8 / code12，必须 STOP，先输出差异说明”；第 45 节要求 candidate identity mismatch 时先输出 BASELINE_MISMATCH。当前高于该基线，因此未生成正式 A–U readiness closeout 或宣布 Phase7 READY。

## 核验结果

|对象|真实身份/状态|
|---|---|
|当前源码、About、开发 Debug|0.7.9/code13|
|code13 普通开发 Debug SHA256|`b168192b7d0a64d2ff49e0d25113679c413a3884763a4733ed24bcd0d1036036`；与上一轮记录匹配|
|code13 交付包 / unsigned Release|未构建|
|已交付普通 Debug|0.7.8/code12；SHA256 `9c7242fa5cc09c30a8ed7fba2ad46e604a106759a03e4844da855fe588e40248`，本轮核验不变|
|已归档 unsigned Release / 当前 Release build output|0.7.8/code12；SHA256 `bdd7bafa595bcd9f55987de98fd45e2ffdbc772ff55d215f565eb85d9211a084`，本轮核验不变|

不能把 build/outputs 下 Debug13 与 Release12 当作同一当前候选的两包，也不能把 code12 报告的“current app-debug”沿用到当前构建输出。

## code12 → code13 差异

上一轮用户明确要求横屏虚拟按键靠近状态栏/挖孔侧边缘，已执行以下授权变化：

- Player：横屏左右仅避让实际 displayCutout；mandatory gesture 只用于上下方向。
- InputProfile：横屏默认 DPAD/L 位于左安全边缘，A/R 位于右安全边缘；横屏 x 校验允许 0..1，竖屏仍 .08.. .92。
- TouchControls：横屏拖动 x 可到 0/1；按键中心继续按其半径限制，避免画出边界。
- PrivateInputProfiles：只升级完整匹配旧默认的横屏控件集合，保留透明度；自定义布局不重置，原 schema 保持。
- Gradle 与 About：0.7.9/code13。

共六份生产文件变化，ControlPreview 尝试变化已回退，最终与 code12 快照一致。相关 input 单测/仪器测试及上一轮报告另存，不能把本轮预检称为重新跑过。Audio/Core 九份 code12 文件哈希均保持。[精确差异](evidence/phase7_final_consolidation/code12-to-code13.diff)、[核验 JSON](evidence/phase7_final_consolidation/baseline-check.json)、[上一轮记录](LANDSCAPE_CONTROL_EDGE_REFINEMENT_REPORT.md)。

## 已读取与保留的证据

已交叉读取当前权威状态、code10 性能清理、code11 触控全屏、code12 音频及交付更新、code13 边缘留白记录与 code9 人工反馈。旧报告正文仍有其历史“最新”和“未交付”描述，应按日期及顶部交付更新理解；最终整合时需明确候选范围而非删除旧证据。

code9 >40 分钟稳定、基础存储与退出保留进度继续 USER_CONFIRMED_PASS，不补写 ≥45 分钟或独立 Quick/Battery/四槽、听音及温升通过。code10 功能通过、性能收益 INCONCLUSIVE 保留；code11 旧转译 pacing 失败 UNRESOLVED；code12 1× 首轮 34 underrun、后续未复现且根因未确认保留。最新对话尚未确认 code11/12 专项手感/音质或 code13 布局通过。

## 下一步基线选择

建议以**当前 code13 源码**整合，把 code9–12 作为历史/复用证据，并单独列出 code13 布局验收和构建边界。另一选择是仅收口冻结已交付 code12；此时 code13 工作源码保持，不回滚用户要求的修改，也不能把 code13 的结果计为 code12 测试。

本次停在文档规定的基线 gate。**Phase7 NOT READY；Phase8 不开始。** 尚未作正式 performance 三态风险接受决定，不能把未明确接受的 A/B 缺口自动写成 ACCEPTED_RISK。基线明确后再按原文档执行 readiness 矩阵及最小专项人工验收，不重复要求已确认的 >40 分钟稳定及基础存储测试。
