# Phase 7 Final Consolidation and Readiness — 2026-10-10

## A. Executive Status

**Phase7 READY；Phase8 UNBLOCKED_TO_START / NOT STARTED；V1 NOT RELEASED。** 本轮收口基线经用户明确选择为 **0.7.9/code13**，原文档 code12 前提已调整。整合、核验、矩阵和当前判定完成；后续直接人工反馈已闭合专项验收及性能风险处置门槛，READY不等于正式发布或性能认证。唯一当前权威是 [Phase7权威报告](PHASE_7_COMPATIBILITY_STABILITY_SECURITY_REPORT.md)顶部 Final Consolidation 区；其下及旧专项报告仅是历史候选证据。

## B. Current Candidate Identity

当前源码/普通 ARM64 开发 Debug **0.7.9/versionCode13**；Debug SHA256 `b168192b7d0a64d2ff49e0d25113679c413a3884763a4733ed24bcd0d1036036`。与上一轮预览包一致，当前开发 instrumentation 为相同 code13 测试构建。code13 交付 APK 和 unsigned Release **未构建**；build/outputs 中现存 Release 是 **0.7.8/code12**，不能配为同候选 Release。无 production keystore、正式签名或 AAB。

本轮不改生产源码、不 bump、不构建交付包；91份 authored main/debug/Gradle/许可输入清单及其 SHA256保存、结束核验一致（明确范围，不是整个Git仓库哈希）。[冻结清单](evidence/phase7_final_consolidation/frozen-production-sources.json)、[候选核验](evidence/phase7_final_consolidation/candidate-integrity.json)。

## C. Historical Candidate Chain

|候选|变化/结论|包与人工边界|
|---|---|---|
|0.7.5/code9|原UI与人工稳定基线|整体用户通过、>40min稳定/基本存储/退出保留；原Debug/unsigned Release冻结|
|0.7.6/code10|重复GL状态与相同setter清理|功能通过；MIXED_DIRECTIONAL_SIGNAL / NO_RELIABLE_THROUGHPUT_IMPROVEMENT_ESTABLISHED / PERFORMANCE_UNQUALIFIED|
|0.7.7/code11|横屏沉浸与连续D-pad|功能证据、原JNI转译4×失败UNRESOLVED；仅开发包，人工专项未确认|
|0.7.8/code12|快进音频压缩/有界队列|已交付普通Debug、unsigned Release归档；人工听音未确认|
|0.7.9/code13|横屏控件侧边余量/边缘拖动|当前源码/开发预览包；保留自定义布局，未交付、未人工确认|

已交付 code12 Debug SHA `9c7242fa5cc09c30a8ed7fba2ad46e604a106759a03e4844da855fe588e40248`；unsigned Release `bdd7bafa595bcd9f55987de98fd45e2ffdbc772ff55d215f565eb85d9211a084`，不变。code12→13 六份生产差异为先前用户授权，见 [基线差异说明](PHASE_7_FINAL_CONSOLIDATION_BASELINE_MISMATCH.md)。本轮用户回复“以当前 code13 收口（推荐）”解除该预检stop，原说明保留。

## D. Consolidated Functional Changes

保留code10最小GL缓存与View setter guard；code11统一系统栏生命周期和连续方向解析；code12按requested speed做整数decimation、FF最新PCM窗口；code13左右只避让cutout，上下保留mandatory gestures，默认边缘控件及x=0..1拖动。竖屏、Renderer画面3:2、Audio、State/Game ID/Room/DataStore/ZIP格式均未被code13改动。旧默认整组才应用新横屏默认，自定义不重置。

## E. User Manual Evidence

直接反馈“真机验收通过”“真机验收没有记录。暂时保持通过”以及后来“运行游戏大于四十分钟稳定、能够存储、退出保留进度”，按真实范围保留code9 USER_CONFIRMED_PASS。未补写>=45分钟、独立Battery/Quick/四槽/强杀冷启动、声音、温升等专项PASS。

用户随后对已交付code12全屏/正反横屏、D-pad转向/绕圈/斜向/方向+A/B/无粘键，以及1×/2×/4×/8×声音、切回1×、Pause/Home静音、倒带恢复回答“都没问题”，记为USER_CONFIRMED_PASS。另明确“无明显卡顿、掉速或异常发热；code13 边缘调整也已通过”，补齐code13新增边缘布局验收。用户实测反馈不补写设备/API或客观性能数值，也不意味着本轮构建/交付code13 APK。[直接反馈记录](evidence/phase7_final_consolidation/manual-feedback-20261010.json)。

## F. Automated Regression Summary

本轮完整 JVM **80 variant结果、71独立方法、0 failure/error**（部分未变任务UPTODATE）。当前code13应用 **9 tests PASS，167.104秒**：Activity3、新快进音频、原FF/Rewind、四模式/24旋转实际画面、真实Home、Battery/Quick+Slots/Continue、Pause外部恢复。未为达成PASS改源码、测试门槛或断言。[JVM结果](evidence/phase7_final_consolidation/current-jvm-results.json)、[当前应用日志](evidence/phase7_final_consolidation/current-app-regression.log)。

复用code12 host native9、JNI full18、相关host/Android UBSan，以及code13上一轮Input14/五个不同控制专项方法。依据：Audio/Core9份源文件hash一致，code12/13 Debug三份native .so逐字节一致，旧证据清单85/26项全部hash校验一致。明确这些不是本轮重跑。code13原编辑器ratio失败已恢复原preview并按原断言通过，原日志保留；无全视觉/60min/fuzz/migration机械重跑。

## G. Renderer / Fullscreen

当前四模式Fit/Integer、24旋转、颜色/Surface/Home恢复通过；Surface full-bleed、3:2且不裁切/拉伸保持。code13正反横屏与模拟hole安全区、拖动保存、bars恢复使用已有当前二进制证据。code12正反横屏及code13边缘体验已有用户直接通过反馈；不外推所有挖孔/OEM。上一轮自有模拟器system/System UI ANR已在code12基线出现，原屏幕记录保留；不称产品ANR修复或实体无ANR认证。

## H. Input / D-pad

连续region、15%命中扩展、8向、12%dead zone、80ms中心保持、7°迟滞及pointer独立状态保持；resolver/multitouch清理自动通过。code13水平边缘范围与旧默认升级、custom profile保留有单测及拖动验证。code12手感、转向/绕圈/斜向、无粘键、方向+A/B及code13边缘调整实测USER_CONFIRMED_PASS。

## I. Audio / Fast-forward

1×原PCM路径；2/4/8×每N帧输出一对、连续phase；FF固定2048frame最新窗口（62.5ms是队列自身上限，不是端到端延迟）；不阻塞核心、不保调。requested映射保留，实际不足requested可欠供，8× best-effort。FF→1×清旧PCM/phase；Pause/Home/Rewind静音、存读档/Exit清理自动通过。**1×首轮34 underrun后续未复现，根因未确认**；不声明“1× audio no regression”。用户已对1×/2×/4×/8×及切回、Pause/Home静音、倒带恢复实际听感确认通过；自动34 underrun不确定性仍保留。

## J. Persistence

当前Battery fixture后台/重建、Quick+Slots1–4、退出Continue回归通过；code13只改InputProfile边界/旧默认读取，不改游戏存档/schema。完整游戏原生电池存档写入与冷启动证据仍有限。Phase2原始State缺失沿用HISTORICAL_FIXTURE_UNAVAILABLE/ACCEPTED_RISK，禁止造fixture。

## K. Lifecycle

当前Pause/Home前后台、状态操作、退出恢复PCM通过，沿用原Core pause reset1及Player toggle重应用策略。code13控制insets无新增后台音频修改。历史API29有限端点/短黑帧MONITORED保持，不声称根因修复或覆盖所有OEM。

## L. Security / Provenance

本轮重新运行 **105 checks PASS**，scope **Debug13 + Release12**；current Release13未构建/未审计。两variants merged permissions=[]、无INTERNET，依赖/源码边界无ads/analytics/telemetry/cloud路径；交付/开发普通APK无bundled ROM/ZIP/BIOS、仪器test provider或sanitizer runtime/wrap泄漏。Debug JNI probes按Debug边界允许，Release12无测试声明。mGBA **0.10.5** pinned `26b7884bc25a5933960f3cdcd98bac1ae14d42e2`、Oboe **1.9.3** pinned `b15f5e39c01a7ada306d959e5129620b145fb8b4`，官方vendor文件清单/hash通过。app Apache-2.0、mGBA MPL-2.0、Oboe许可证保留。

历史Remote CI SUCCESS run37751328064/commit2807829记录保留，是2026-10-08历史提交，不冒称code13新CI。本轮不上传代码、不发布。[当前审计](evidence/phase7_final_consolidation/current-apk-provenance-audit.md)。

## M. Performance Classification

**Physical ARM Performance = ACCEPTED_RISK；正式A/B NOT_CERTIFIED / STOPPED_BY_USER。** 用户明确选择“停止正式A/B并接受未认证风险”，并补充“无明显卡顿、掉速或异常发热”。因此风险接受门槛闭合；没有当前code13受控physical OLD↔NEW认证，不标VALIDATED或NO_MEANINGFUL_REGRESSION。

历史code9物理192cell矩阵完成，但OLD秒级CV超出预设10%（Original1×20.209%、GBA Color4×13.911%），环境重复性资格未闭合，不能删异常/放宽门槛；code10方向MIXED不证明收益；code11旧4×213.37/206.28失败继续UNRESOLVED。translated emulator仅诊断，不独立决定物理PASS/FAIL。本轮按用户实际体验与明确风险接受闭合。若后续出现卡顿、掉速、异常发热或native/性能路径变更，重开相关资格；不得将这份风险接受作为性能提升证明。

## N. API / OEM Coverage Gaps

API26/29真实ARM、第二OEM NOT_TESTED，沿用ACCEPTED_COVERAGE_GAP；已有compat模拟器行为PASS_WITH_NOTE，不外推实机。API29短黑帧MONITORED，历史根因未修复。既有受限coverage disposition继续透明保留，不新造多OEM或完整游戏覆盖。

## O. Sanitizer / Fuzz Status

targeted UBSan host Audio及Android JNI PASS复用；ASan comprehensive DEFERRED、full-dependency UBSan/fuzz不全面，历史失败/编译workaround保留，不写fully sanitized。code13 native二进制相同，本轮不重复无关完整fuzz。

## P. Deferred Hardware Features

USB physical NOT_AVAILABLE/NOT_TESTED，Synthetic HID不是物理USB；Rumble DEFERRED_BY_PRODUCT_POLICY（V1零权限，无VIBRATE）。RTC/tilt/gyro/light已有host/JNI/probe/fallback，完整游戏兼容体验不完整。历史Bluetooth记录保持原范围，无新的code13独立实体外设PASS。

## Q. Readiness Matrix

|项目|状态|证据/边界|
|---|---|---|
|Core execution|PASS|code13 Activity/core 生命周期；未变 native/JNI 复用|
|Renderer|PASS|code13 四模式、Fit/Integer、24旋转、实际颜色/Surface|
|Audio 1×|PASS_WITH_NOTE|实际 PCM/恢复自动通过；初轮34 underrun未复现、根因未确认；人工听音另列|
|Fast-forward audio|PASS_WITH_NOTE|2/4/8× ratio/非零PCM、bounded queue、切换/cleanup通过；8× best-effort，人工另列|
|Input|PASS|80 JVM结果包含resolver；当前pointer/cleanup与历史HID范围区分|
|Continuous D-pad|PASS_WITH_NOTE|连续/斜向/多指自动通过，手感人工通过|
|Fullscreen|PASS_WITH_NOTE|正反横屏/模拟挖孔/临时bars及code13边缘通过，用户正反横屏及边缘体验通过，OEM范围有限|
|Save/State|PASS|当前Quick+1–4槽及state/lifecycle smoke；历史Phase2资产单列|
|Battery|PASS_WITH_NOTE|fixture后台/重建/退出往返，非所有完整游戏电池存档认证|
|Quick Resume|PASS|当前Continue/退出/后台恢复；用户已有退出保留反馈|
|ZIP security|PASS_WITH_NOTE|复用既有导入/安全/极限路径，不冒称本轮重跑fuzz全集|
|Lifecycle|PASS|当前Pause/Home/foreground/重建/停止PCM回归|
|API29 targeted|PASS_WITH_NOTE|已有x86_64行为循环；短黑帧MONITORED、根因未修复|
|API26 physical ARM|ACCEPTED_COVERAGE_GAP|实机未测，仅已有模拟器行为范围|
|API29 physical ARM|ACCEPTED_COVERAGE_GAP|实机未测，不能由compat APK替代|
|Second OEM|ACCEPTED_COVERAGE_GAP|无第二品牌验证，不称多OEM通过|
|Sensors / RTC|ACCEPTED_COVERAGE_GAP|host/JNI/probe与fallback有证据；完整游戏体验不完整|
|USB|DEFERRED|物理硬件NOT_AVAILABLE/NOT_TESTED；Synthetic HID不是USB PASS|
|Rumble|DEFERRED|V1 zero-permission 产品政策，无VIBRATE/实体振动验收|
|Performance|ACCEPTED_RISK|用户停止正式A/B并接受未认证风险；实际无明显卡顿/掉速/异常发热，非VALIDATED|
|Sanitizers|DEFERRED|targeted UBSan通过；ASan/full-dependency/fuzz未全面覆盖|
|Provenance|PASS_WITH_NOTE|105 checks：Debug13 + Release12；Release13未构建|
|Manual stability|USER_CONFIRMED_PASS|code9 >40min、基础存储、退出保留；不补写>=45min/专项机制|
|Manual interaction|USER_CONFIRMED_PASS|code12正反横屏/D-pad各专项及code13边缘调整直接通过|
|Manual audio|USER_CONFIRMED_PASS|code12 1×/2×/4×/8×、切回、Pause/Home/Rewind听感直接通过|
|Phase2 original State fixture|ACCEPTED_RISK|HISTORICAL_FIXTURE_UNAVAILABLE，现代路径通过但不造历史fixture|

## R. Accepted Risks

沿用既有书面C7-2026-10-09覆盖处置：Phase2真实fixture缺失、API26/29 ARM、第二OEM、完整RTC/传感器游戏缺口。接受缺口不是测试通过；在原资产/设备/合法完整游戏可用或出现相关回归时重验。USB不可用、Rumble/ASan延期透明记录。**正式ARM性能未认证风险已由用户明确接受**，依据是停止A/B的直接选择及无明显卡顿/掉速/热异常反馈；不靠旧overall或基线选择推断。[本轮处置](evidence/phase7_final_consolidation/risk-disposition.md)。

## S. Hard Blockers

**无剩余Phase7 hard blocker/readiness gate。** 三项原门槛已由直接反馈闭合：code12互动及音频专项、code13边缘布局USER_CONFIRMED_PASS；正式物理ARM资格按ACCEPTED_RISK闭合。历史失败与覆盖缺口仍保留，非全部PASS。code13 Release/交付包未构建属于后续artifact planning，不冒称正式RC已存在。

## T. Final Phase7 Decision

**Phase7 READY。** 当前code13功能自动回归通过、code12全屏/D-pad/音频和code13边缘人工通过，旧>40min稳定/存储反馈保持；正式ARM性能按明确ACCEPTED_RISK处置，覆盖缺口透明保留。当前Phase7.5触控/音频/边缘专项USER_CONFIRMED_PASS。V1 NOT RELEASED；旧报告只适用于历史候选/时点。

## U. Phase8 Entry Gate

**Phase8 UNBLOCKED_TO_START / NOT STARTED。** 可以进入Phase8，当前任务仅更新收口判定，不生成production keystore、production签名或AAB，不自动开始RC发布。后续正式候选构建/签名/交付按Phase8要求执行；code13现仅开发预览包，现存unsigned Release仍code12。出现相关回归或候选范围变化时重开对应验收/风险门槛。
