#pragma once
#include <array>
#include <atomic>
#include <algorithm>
#include <cstdint>
#include <cstring>

namespace gbalite {
// FF only. Producer may overwrite stale frames; each stereo pair + sequence is
// atomic, so the consumer never races ordinary sample memory. Neither side waits.
template<size_t Capacity=2048> class LatestPcmRing {
    static_assert(Capacity>0 && (Capacity&(Capacity-1))==0);
    static_assert(std::atomic<uint64_t>::is_always_lock_free);
    std::array<std::atomic<uint64_t>,Capacity> samples_{};
    std::atomic<uint64_t> write_{0},read_{0},dropped_{0};
public:
    size_t push(const int16_t* data,size_t frames) {
        const auto w=write_.load(std::memory_order_relaxed);
        const auto skip=frames>Capacity ? frames-Capacity : 0;
        for(size_t i=skip;i<frames;++i) {
            uint32_t pcm;std::memcpy(&pcm,data+i*2,sizeof(pcm));
            samples_[(w+i)&(Capacity-1)].store((uint64_t(uint32_t(w+i+1))<<32)|pcm,std::memory_order_release);
        }
        write_.store(w+frames,std::memory_order_release);
        return frames-skip;
    }
    size_t pop(int16_t* data,size_t frames) {
        auto r=read_.load(std::memory_order_relaxed);
        const auto w=write_.load(std::memory_order_acquire);
        if(w-r>Capacity) {dropped_.fetch_add(w-r-Capacity,std::memory_order_relaxed);r=w-Capacity;}
        const auto count=std::min<uint64_t>(frames,w-r);
        size_t copied=0;
        for(;copied<count;++copied) {
            const auto packed=samples_[(r+copied)&(Capacity-1)].load(std::memory_order_acquire);
            // A producer overtook this snapshot. Silence the rest until the next
            // callback can take its latest committed window; never spin/retry.
            if(uint32_t(packed>>32)!=uint32_t(r+copied+1)) break;
            const uint32_t pcm=uint32_t(packed);std::memcpy(data+copied*2,&pcm,sizeof(pcm));
        }
        read_.store(r+copied,std::memory_order_release);
        std::fill(data+copied*2,data+frames*2,int16_t{0});
        return copied;
    }
    size_t fill() const {
        const auto r=read_.load(std::memory_order_acquire),w=write_.load(std::memory_order_acquire);
        return w>r ? static_cast<size_t>(std::min<uint64_t>(w-r,Capacity)) : 0;
    }
    uint64_t dropped() const {return dropped_.load(std::memory_order_relaxed);}
    // Only when producer is stopped and Oboe close has joined the callback.
    void clear() {read_.store(0);write_.store(0);}
};
}
