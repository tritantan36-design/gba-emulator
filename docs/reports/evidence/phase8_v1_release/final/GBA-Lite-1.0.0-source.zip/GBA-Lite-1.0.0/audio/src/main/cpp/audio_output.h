#pragma once
#include "pcm_ring.h"
#include "latest_pcm_ring.h"
#include "fast_forward_audio.h"
#include <oboe/Oboe.h>
#include <memory>

namespace gbalite {
class AudioOutput final : public oboe::AudioStreamDataCallback {
    PcmRing<> ring_;
    LatestPcmRing<> fastRing_;
    FastForwardAudioProcessor processor_;
    std::array<int16_t,2048*2> compressed_{};
    std::atomic<unsigned> speed_{1};
    std::shared_ptr<oboe::AudioStream> stream_;
    std::atomic<uint64_t> underruns_{0};
#ifdef GBA_TEST_HOOKS
    std::atomic<uint64_t> played_{0},inputFrames_{0},outputFrames_{0};
#endif
public:
    ~AudioOutput() { stop(); }
    bool start();
    void stop();
    void setSpeed(unsigned speed) {processor_.reset();speed_.store(speed,std::memory_order_release);}
    size_t push(const int16_t* data,size_t frames) {
        const auto speed=speed_.load(std::memory_order_relaxed);
        size_t count=frames,accepted=0;
        if(speed==1) accepted=ring_.push(data,frames);
        else {
            count=processor_.process(data,frames,speed,compressed_.data());
            accepted=fastRing_.push(compressed_.data(),count);
        }
#ifdef GBA_TEST_HOOKS
        inputFrames_.fetch_add(frames,std::memory_order_relaxed);
        outputFrames_.fetch_add(count,std::memory_order_relaxed);
#endif
        return accepted;
    }
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t frames) override {
        if((speed_.load(std::memory_order_acquire)==1 ? ring_.pop(static_cast<int16_t*>(data),static_cast<size_t>(frames)) : fastRing_.pop(static_cast<int16_t*>(data),static_cast<size_t>(frames))) < static_cast<size_t>(frames))
            underruns_.fetch_add(1,std::memory_order_relaxed);
#ifdef GBA_TEST_HOOKS
        auto* pcm = static_cast<int16_t*>(data);
        uint64_t count = 0;
        for (int32_t i = 0; i < frames * 2; ++i) if (pcm[i] != 0) ++count;
        played_.fetch_add(count, std::memory_order_relaxed);
#endif
        return oboe::DataCallbackResult::Continue;
    }
    uint64_t underruns() const { return underruns_.load(); }
#ifdef GBA_TEST_HOOKS
    uint64_t playedForTest() const { return played_.load(); }
    std::array<int64_t,5> statsForTest() const {return {static_cast<int64_t>(inputFrames_.load()),static_cast<int64_t>(outputFrames_.load()),static_cast<int64_t>(fastRing_.dropped()),static_cast<int64_t>(speed_.load()==1 ? ring_.fill() : fastRing_.fill()),static_cast<int64_t>(speed_.load())};}
#endif
};
}
