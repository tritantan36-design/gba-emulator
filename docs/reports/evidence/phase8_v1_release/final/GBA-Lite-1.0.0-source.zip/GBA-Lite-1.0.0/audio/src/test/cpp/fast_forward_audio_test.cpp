#include "fast_forward_audio.h"
#include "latest_pcm_ring.h"
#include <cassert>
#include <vector>
#include <thread>
#include <cmath>
#include <iostream>
int main() {
    for(unsigned speed: {1u,2u,4u,8u}) {
        gbalite::FastForwardAudioProcessor p;
        std::vector<int16_t> input(32768*2),out(input.size());
        for(size_t i=0;i<32768;++i) {input[i*2]=int16_t(std::sin(i*2*3.141592653589793*128/32768)*12000);input[i*2+1]=-input[i*2];}
        size_t written=0;
        // Uneven input chunks exercise carried phase; period128Hz is exactly
        // divisible at all speeds, so sign crossings establish pitch ratio.
        for(size_t offset=0;offset<32768;) {
            size_t count=std::min<size_t>(137,32768-offset);
            written+=p.process(input.data()+offset*2,count,speed,out.data()+written*2);offset+=count;
        }
        assert(written==32768/speed);
        unsigned crossings=0;
        for(size_t i=0;i<written;++i) {
            assert(out[i*2]==input[i*speed*2]);assert(out[i*2+1]==input[i*speed*2+1]);
            if(i && out[(i-1)*2]<=0 && out[i*2]>0) ++crossings;
        }
        assert(crossings>=127 && crossings<=129);
        std::cout<<"speed="<<speed<<" input=32768 output="<<written<<" pitch="<<crossings*speed<<"Hz\n";
        p.reset();int16_t probe[6]={10,-10,20,-20,30,-30};int16_t dst[6]{};
        assert(p.process(probe,3,1,dst)==3);assert(dst[0]==10 && dst[4]==30);
    }
    gbalite::LatestPcmRing<8> ring;int16_t input[40],out[40];
    for(int i=0;i<20;++i) {input[i*2]=int16_t(i+1);input[i*2+1]=-input[i*2];}
    assert(ring.push(input,20)==8);assert(ring.fill()==8);assert(ring.pop(out,10)==8);assert(ring.dropped()==12);
    for(int i=0;i<8;++i) assert(out[i*2]==i+13 && out[i*2+1]==-(i+13));assert(out[16]==0);
    ring.clear();assert(ring.fill()==0);assert(ring.pop(out,2)==0);
    gbalite::LatestPcmRing<64> concurrent;std::atomic<bool> done{false};
    std::thread producer([&] {for(int n=1;n<=200000;++n) {int16_t pair[2]={int16_t(n%30000+1),int16_t(-(n%30000+1))};concurrent.push(pair,1);}done=true;});
    while(!done || concurrent.fill()) {
        const auto count=concurrent.pop(out,20);
        for(size_t i=0;i<count;++i) assert(out[i*2]==-out[i*2+1] && out[i*2]!=0);
        assert(concurrent.fill()<=64);
    }
    producer.join();std::cout<<"latest queue concurrency: PASS\n";
}
