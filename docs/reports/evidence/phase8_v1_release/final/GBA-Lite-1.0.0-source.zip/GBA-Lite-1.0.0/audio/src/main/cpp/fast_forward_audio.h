#pragma once
#include <cstdint>
#include <cstddef>

namespace gbalite {
// Integer requested-speed decimation, stereo pairs stay together across chunks.
class FastForwardAudioProcessor {
    unsigned phase_=0;
public:
    void reset() { phase_=0; }
    size_t process(const int16_t* input,size_t frames,unsigned speed,int16_t* output) {
        size_t count=0;
        for(size_t i=0;i<frames;++i) {
            if(phase_==0) {
                output[count*2]=input[i*2];output[count*2+1]=input[i*2+1];++count;
            }
            phase_=(phase_+1)%speed;
        }
        return count;
    }
};
}
