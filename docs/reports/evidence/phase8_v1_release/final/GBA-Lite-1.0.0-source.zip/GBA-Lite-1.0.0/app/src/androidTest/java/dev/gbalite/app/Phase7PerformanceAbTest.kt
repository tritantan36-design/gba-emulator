@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.core.*
import dev.gbalite.session.SessionState
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer

/** Characterization only: records the unchanged formal gate separately; never qualifies performance. */
class Phase7PerformanceAbTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    private val instrumentation get()=InstrumentationRegistry.getInstrumentation()
    private fun model()=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
    private fun open(name: String) {
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/$name.gba")
        instrumentation.uiAutomation.executeShellCommand("content query --uri $uri").use {fd ->
            android.os.ParcelFileDescriptor.AutoCloseInputStream(fd).bufferedReader().use {assertTrue(it.readText().contains("Row: 0"))}
        }
        instrumentation.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        foreground()
        compose.runOnUiThread {model().open(uri)}
        compose.waitUntil(15000) {!model().loading && model().playing && model().session.playerMetrics().frames>5}
        assertEquals(SessionState.RUNNING,model().session.state.value)
    }
    private fun foreground() {
        instrumentation.targetContext.startActivity(Intent(compose.activity.intent)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        compose.waitUntil(15000) {compose.activity.hasWindowFocus()}
    }
    private fun renderer(): dev.gbalite.renderer.RendererSnapshot {
        var result: dev.gbalite.renderer.RendererSnapshot?=null
        compose.runOnUiThread {
            fun find(view: android.view.View): dev.gbalite.renderer.OriginalSurface? {
                if(view is dev.gbalite.renderer.OriginalSurface) return view
                if(view is android.view.ViewGroup) for(n in 0 until view.childCount) find(view.getChildAt(n))?.let {return it}
                return null
            }
            result=checkNotNull(find(compose.activity.window.decorView)).diagnostics()
        }
        return checkNotNull(result)
    }
    private fun deviceState(): JSONObject {
        val battery=instrumentation.targetContext.registerReceiver(null,android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val power=instrumentation.targetContext.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
        return JSONObject().put("batteryLevel",battery?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL,-1))
            .put("batteryScale",battery?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE,-1))
            .put("batteryTemperatureTenthsC",battery?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE,-1))
            .put("plugged",battery?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED,-1))
            .put("powerSaver",power.isPowerSaveMode)
            .put("thermalStatus",if(android.os.Build.VERSION.SDK_INT>=29) power.currentThermalStatus else JSONObject.NULL)
    }
    @Test fun measureAllModes() {
        val original=model().displaySettings
        val orientation=compose.activity.requestedOrientation
        val args=InstrumentationRegistry.getArguments()
        val sampleMs=args.getString("phase7SampleMs","3000").toLong().also {require(it in 3000..30000)}
        val warmupMs=args.getString("phase7WarmupMs","1000").toLong().also {require(it in 1000..10000)}
        val evidence=File(compose.activity.filesDir,"phase7-closeout-performance.jsonl")
        evidence.writeText("")
        try {
            compose.runOnUiThread {compose.activity.requestedOrientation=android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
            compose.waitUntil(15000) {compose.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
            open("phase7-stress-a")
            for(mode in DisplayMode.entries) for(speed in listOf(1,2,4,8)) {
                compose.runOnUiThread {model().display(DisplaySettings(mode))}
                compose.waitUntil(5000) {renderer().let {it.mode==mode && it.draws>=2}}
                assertTrue(runBlocking {model().session.setSpeed(speed)})
                Thread.sleep(warmupMs)
                val environmentBefore=deviceState()
                val displayBefore=renderer();val before=model().session.playerMetrics();val started=SystemClock.elapsedRealtime()
                val temporalFps=org.json.JSONArray()
                var segmentStarted=started
                var segmentFrames=before.frames
                while(SystemClock.elapsedRealtime()-started<sampleMs) {
                    Thread.sleep(minOf(1000L,sampleMs-(SystemClock.elapsedRealtime()-started)).coerceAtLeast(1))
                    val now=SystemClock.elapsedRealtime();val frames=model().session.playerMetrics().frames
                    temporalFps.put((frames-segmentFrames)*1000.0/(now-segmentStarted).coerceAtLeast(1))
                    segmentFrames=frames;segmentStarted=now
                }
                val elapsed=SystemClock.elapsedRealtime()-started;val after=model().session.playerMetrics()
                val fps=(after.frames-before.frames)*1000.0/elapsed
                val display=renderer()
                assertEquals(1,display.activeSurfaces);assertEquals(1,display.textures)
                assertTrue(display.programs in 1..4)
                evidence.appendText(JSONObject().put("mode",mode.name).put("speed",speed)
                    .put("environmentBefore",environmentBefore).put("environmentAfter",deviceState())
                    .put("orientation","LANDSCAPE").put("background","BLACK")
                    .put("temporalFps",temporalFps)
                    .put("scaleMode","FIT").put("actualMultiplier",fps/59.7275).put("displayFps",(display.draws-displayBefore.draws)*1000.0/elapsed).put("originalGateFps",59.7275*minOf(speed,4)*.85).put("originalGatePassed",fps>59.7275*minOf(speed,4)*.85).put("elapsedMs",elapsed).put("frames",after.frames-before.frames).put("fps",fps)
                    .put("lateFramesDelta",after.lateFrames-before.lateFrames)
                    .put("underrunsDelta",after.audioUnderruns-before.audioUnderruns)
                    .put("renderer",display.toString()).toString()+"\n")
                assertTrue("Playback stopped in $mode at ${speed}x",after.frames>before.frames)
                // Measurements are retained even if device throughput varies; 8x is best effort.
                assertTrue(runBlocking {model().session.setSpeed(1)})
            }
        } finally {
            runBlocking {model().session.setSpeed(1);model().session.stop()}
            compose.runOnUiThread {model().exit();model().display(original)}
            compose.runOnUiThread {compose.activity.requestedOrientation=orientation}
        }
    }
}
