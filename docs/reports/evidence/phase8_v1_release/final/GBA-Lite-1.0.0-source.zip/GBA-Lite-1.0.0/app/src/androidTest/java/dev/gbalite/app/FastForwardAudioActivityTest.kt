@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.session.SessionState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.File
import org.json.JSONObject

class FastForwardAudioActivityTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    @Test fun holdTogglePauseHomeStateRewindExitPcm() {
        val i=InstrumentationRegistry.getInstrumentation()
        val m=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/bringup.gba")
        i.uiAutomation.executeShellCommand("content query --uri $uri").close()
        i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        compose.runOnUiThread {m.open(uri)}
        compose.waitUntil(15000) {m.playing && !m.loading && m.session.state.value==SessionState.RUNNING}
        val core=m.session.javaClass.getDeclaredField("core").apply {isAccessible=true}.get(m.session)!!
        val handle=core.javaClass.getDeclaredField("handle").apply {isAccessible=true}.getLong(core)
        val cls=Class.forName("dev.gbalite.mgba.JniBridge");val bridge=cls.getDeclaredConstructor().newInstance()
        fun played()=cls.getDeclaredMethod("playedForTest",java.lang.Long.TYPE).invoke(bridge,handle) as Long
        fun stats()=cls.getDeclaredMethod("audioStatsForTest",java.lang.Long.TYPE).invoke(bridge,handle) as LongArray
        val rows=File(i.targetContext.filesDir,"ff-audio-activity.jsonl").apply {writeText("")}
        fun audible(label: String) {
            val before=played();compose.waitUntil(5000) {played()>before}
            val s=stats();assertEquals(m.session.playerMetrics().speed.toLong(),s[4])
            assertTrue(s[3] in 0..(if(s[4]==1L) 4096 else 2048))
            rows.appendText(JSONObject().put("event",label).put("speed",s[4]).put("ringFill",s[3])
                .put("inputFrames",s[0]).put("outputFrames",s[1]).put("droppedFrames",s[2]).put("playedNonzero",played()).toString()+"\n")
        }
        fun silent(label: String) {
            val before=played();Thread.sleep(200);assertEquals(before,played());assertEquals(0L,stats()[3])
            rows.appendText(JSONObject().put("event",label).put("silent",true).toString()+"\n")
        }
        fun menu() {compose.onNodeWithTag("player-menu").performClick();compose.waitUntil(5000) {m.session.state.value==SessionState.PAUSED}}
        try {
            audible("normal")
            menu();silent("pause-normal")
            compose.onNodeWithText("快进 / 倒带").performScrollTo().performClick()
            compose.onNodeWithText("2×",useUnmergedTree=true).performScrollTo().performClick()
            compose.waitUntil(5000) {m.session.playerMetrics().speed==2};audible("toggle-2x")
            menu();silent("pause-ff");compose.onNodeWithText("继续",useUnmergedTree=true).performClick();audible("resume-ff")
            menu();compose.onNodeWithText("快进 / 倒带").performScrollTo().performClick()
            compose.onNodeWithText("快进（按住）",useUnmergedTree=true).performScrollTo().performClick()
            compose.onNodeWithText("按住快进 2×").performTouchInput {down(center)}
            compose.waitUntil(5000) {m.session.playerMetrics().speed==2};audible("hold-press")
            compose.onNodeWithText("按住快进 2×").performTouchInput {up()}
            compose.waitUntil(5000) {m.session.playerMetrics().speed==1};audible("hold-release")
            compose.onNodeWithText("完成").performClick();compose.onNodeWithText("继续",useUnmergedTree=true).performClick()
            for(speed in listOf(2,4,8,4,2,1)) {assertTrue(runBlocking {m.session.setSpeed(speed)});audible("matrix-$speed")}
            for(slot in listOf<Int?>(null,1,2,3,4)) {
                assertTrue(runBlocking {m.session.setSpeed(4)});assertTrue(runBlocking {m.session.saveState(slot)});audible("save-$slot")
                assertTrue(runBlocking {m.session.setSpeed(4)});assertTrue(runBlocking {m.session.loadState(slot)});audible("load-$slot")
            }
            assertTrue(runBlocking {m.session.setSpeed(4)});audible("pre-home-4x")
            i.uiAutomation.executeShellCommand("input keyevent KEYCODE_HOME").close()
            compose.waitUntil(5000) {m.session.state.value==SessionState.PAUSED};silent("home")
            i.targetContext.startActivity(Intent(i.targetContext,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            compose.waitUntil(10000) {m.session.state.value==SessionState.RUNNING};audible("foreground")
            assertTrue(runBlocking {m.session.setSpeed(4)});Thread.sleep(1000)
            assertTrue(runBlocking {m.session.setRewinding(true)});silent("rewind")
            assertTrue(runBlocking {m.session.setRewinding(false)});audible("rewind-release")
            assertTrue(runBlocking {m.session.setSpeed(8)});assertTrue(runBlocking {m.session.stop()})
            Thread.sleep(200);assertEquals(0L,played())
        } finally {runBlocking {m.session.stop()}}
    }
}
