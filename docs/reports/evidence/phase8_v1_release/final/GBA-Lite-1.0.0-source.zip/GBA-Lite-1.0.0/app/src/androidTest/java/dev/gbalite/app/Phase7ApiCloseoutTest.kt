@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Debug
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.core.*
import dev.gbalite.renderer.OriginalSurface
import dev.gbalite.session.SessionState
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import java.io.File

/** TEST ONLY: synthetic SAF result, actual TextureView pixels, lifecycle recovery. */
class Phase7ApiCloseoutTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    private val i get()=InstrumentationRegistry.getInstrumentation()
    private fun model()=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
    private fun waitFor(message: String,timeout: Long=15000,condition: ()->Boolean) {
        try { compose.waitUntil(timeout,condition) }
        catch(e: Throwable) {throw AssertionError("$message; lifecycle=${compose.activity.lifecycle.currentState}; lifecycleApplied=${model().lifecycleApplied.isCompleted}; loading=${model().loading}; playing=${model().playing}; message=${model().message}; state=${model().session.state.value}; metrics=${model().session.playerMetrics()}",e)}
    }
    private fun pressHome() {
        i.uiAutomation.executeShellCommand("input keyevent KEYCODE_HOME").use {p ->
            val reply=android.os.ParcelFileDescriptor.AutoCloseInputStream(p).bufferedReader().use {it.readText()}
            assertTrue("Home shell input reported an error: $reply",reply.isBlank())
        }
    }
    private fun open(letter: Char='a') {
        compose.waitForIdle()
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/phase7-stress-$letter.gba")
        i.uiAutomation.executeShellCommand("content query --uri $uri").use {p ->
            val reply=android.os.ParcelFileDescriptor.AutoCloseInputStream(p).bufferedReader().use {it.readText()}
            assertTrue("Test provider not ready: $reply",reply.contains("Row: 0"))
        }
        i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        // Provider wake-up and previous Home cycles can leave the OEM test activity
        // stopped. Restore the actual Activity; never override Session foreground.
        i.targetContext.startActivity(Intent(i.targetContext,MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        waitFor("Activity did not regain focus") {compose.activity.hasWindowFocus()}
        compose.runOnUiThread {model().open(uri)}
        waitFor("ROM load: ${model().message}") {!model().loading && model().playing && model().session.playerMetrics().frames>10}
        waitFor("Session running") {model().session.state.value==SessionState.RUNNING}
    }
    private fun surface(): OriginalSurface? {
        fun find(v: View): OriginalSurface? {
            if(v is OriginalSurface) return v
            if(v is ViewGroup) for(n in 0 until v.childCount) find(v.getChildAt(n))?.let {return it}
            return null
        }
        var result: OriginalSurface?=null
        compose.runOnUiThread {result=find(compose.activity.window.decorView)}
        return result
    }
    private fun actualFrame() {
        waitFor("Actual game Surface missing or black") {
            var ok=false
            compose.runOnUiThread {surface()?.let {s ->
                val d=s.diagnostics()
                val image=if(s.isAvailable && d.draws>=2) s.bitmap else null
                if(image!=null) {
                    val p=image.getPixel(image.width/2,image.height/2)
                    ok=android.graphics.Color.red(p)>200
                    image.recycle()
                }
            }}
            ok
        }
    }
    private fun sample(file: File,event: String,started: Long) {
        val memory=Debug.MemoryInfo();Debug.getMemoryInfo(memory)
        val m=model().session.playerMetrics()
        val status=File("/proc/self/status").readLines().filter {it.startsWith("VmRSS:") || it.startsWith("Threads:")}
        val row=JSONObject().put("event",event).put("elapsedMs",SystemClock.elapsedRealtime()-started)
            .put("timestamp",java.time.Instant.now().toString()).put("pid",android.os.Process.myPid())
            .put("nativeHeapBytes",Debug.getNativeHeapAllocatedSize()).put("javaUsedBytes",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())
            .put("totalPssKiB",memory.totalPss).put("procStatus",status.joinToString(";"))
            .put("fdCount",File("/proc/self/fd").list()?.size ?: -1).put("jvmThreads",Thread.getAllStackTraces().size)
            .put("frames",m.frames).put("underruns",m.audioUnderruns).put("rewindBytes",m.rewindBytes)
            .put("renderer",surface()?.diagnostics().toString()).put("sessionState",model().session.state.value.name)
        file.appendText(row.toString()+"\n")
    }
    @Test fun safOrientationHomeRecoveryCycles() {
        val cycles=InstrumentationRegistry.getArguments().getString("phase7ApiCycles")?.toInt() ?: 1
        require(cycles in 1..30)
        val file=File(i.targetContext.filesDir,"phase7-api-closeout.jsonl");file.writeText("")
        val started=SystemClock.elapsedRealtime();val original=model().displaySettings
        val orientation=compose.activity.requestedOrientation
        try {
            for(cycle in 0 until cycles) {
                val uri=Uri.parse("content://dev.gbalite.app.test.rom/bringup.gba")
                i.uiAutomation.executeShellCommand("content query --uri $uri").use { fd ->
                    android.os.ParcelFileDescriptor.AutoCloseInputStream(fd).bufferedReader().use { reader ->
                        assertTrue("Fixture provider must publish the ROM",reader.readText().contains("Row: 0"))
                    }
                }
                i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                val filter=android.content.IntentFilter(Intent.ACTION_OPEN_DOCUMENT).apply {addCategory(Intent.CATEGORY_OPENABLE);addDataType("*/*")}
                val monitor=android.app.Instrumentation.ActivityMonitor(filter,android.app.Instrumentation.ActivityResult(android.app.Activity.RESULT_OK,Intent().setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)),true)
                i.targetContext.startActivity(Intent(compose.activity.intent).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                waitFor("Before SAF focus") {compose.activity.hasWindowFocus()}
                i.addMonitor(monitor)
                try {
                    compose.onNode(androidx.compose.ui.test.hasText("添加游戏")).performClick()
                    try {
                        compose.waitUntil(10000) {compose.onAllNodes(androidx.compose.ui.test.hasText("打开游戏")).fetchSemanticsNodes().isNotEmpty()}
                    } catch(error: Throwable) {
                        File(i.targetContext.filesDir,"phase7-api-navigation-error.txt").writeText("monitorHits=${monitor.hits}; focus=${compose.activity.hasWindowFocus()}; loading=${model().loading}; imported=${model().imported}; message=${model().message}\n"+compose.onRoot(useUnmergedTree=true).printToString())
                        throw error
                    }
                    compose.onNode(androidx.compose.ui.test.hasText("打开游戏")).performClick()
                    waitFor("SAF ROM import") {model().playing && !model().loading}
                    assertTrue(monitor.hits>0)
                } finally {i.removeMonitor(monitor)}
                compose.runOnUiThread {model().display(DisplaySettings(DisplayMode.ORIGINAL))}
                i.targetContext.startActivity(Intent(compose.activity.intent).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                waitFor("SAF focus") {compose.activity.hasWindowFocus()};actualFrame()
                assertTrue(runBlocking {model().session.saveState(1)})
                assertTrue(runBlocking {model().session.loadState(1)})
                compose.runOnUiThread {compose.activity.requestedOrientation=if(cycle%2==0) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT}
                Thread.sleep(400);actualFrame()
                pressHome();waitFor("Background paused") {model().session.state.value==SessionState.PAUSED && !compose.activity.hasWindowFocus()}
                val paused=model().session.playerMetrics().frames;Thread.sleep(300);assertEquals(paused,model().session.playerMetrics().frames)
                val recovery=SystemClock.elapsedRealtime()
                i.targetContext.startActivity(Intent(compose.activity.intent).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                waitFor("Foreground running") {compose.activity.hasWindowFocus() && model().session.state.value==SessionState.RUNNING};actualFrame()
                file.appendText(JSONObject().put("cycle",cycle+1).put("api",android.os.Build.VERSION.SDK_INT).put("syntheticSafResult",true).put("actualSurfaceRed",true).put("foregroundFocused",true).put("recoveryObservedMs",SystemClock.elapsedRealtime()-recovery).put("blackFrameDuration","NOT_MEASURED_CONTINUOUSLY").put("audioUnderruns",model().session.playerMetrics().audioUnderruns).put("audioListening","NOT_TESTED").toString()+"\n")
                sample(file,"cycle-complete",started)
                compose.runOnUiThread {model().exit()};waitFor("Exit") {!model().playing}
            }
        } finally {
            runBlocking {model().session.stop()}
            compose.runOnUiThread {model().exit();model().display(original);compose.activity.requestedOrientation=orientation}
        }
    }
    @Test fun pcmPlaybackPausesOnHomeAndResumes() {
        val original=model().displaySettings
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/persistence.gba")
        try {
            i.uiAutomation.executeShellCommand("content query --uri $uri").use {fd -> android.os.ParcelFileDescriptor.AutoCloseInputStream(fd).bufferedReader().use {assertTrue(it.readText().contains("Row: 0"))}}
            i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            i.targetContext.startActivity(Intent(compose.activity.intent).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            waitFor("PCM initial focus") {compose.activity.hasWindowFocus()}
            compose.runOnUiThread {model().open(uri)}
            waitFor("PCM ROM running") {model().playing && !model().loading && model().session.state.value==SessionState.RUNNING}
            compose.runOnUiThread {model().display(DisplaySettings(DisplayMode.ORIGINAL))};actualFrame()
            val core=model().session.javaClass.getDeclaredField("core").apply {isAccessible=true}.get(model().session)!!
            val handle=core.javaClass.getDeclaredField("handle").apply {isAccessible=true}.getLong(core)
            val type=Class.forName("dev.gbalite.mgba.JniBridge");val bridge=type.getDeclaredConstructor().newInstance()
            val played=type.getDeclaredMethod("playedForTest",java.lang.Long.TYPE)
            val nonzero=type.getDeclaredMethod("nonzeroSamplesForTest",java.lang.Long.TYPE)
            fun count(method: java.lang.reflect.Method)=method.invoke(bridge,handle) as Long
            val initial=count(played);val initialNonzero=count(nonzero)
            waitFor("Non-silent PCM playback") {count(played)>initial && count(nonzero)>initialNonzero}
            pressHome();waitFor("PCM background paused") {model().session.state.value==SessionState.PAUSED && !compose.activity.hasWindowFocus()}
            Thread.sleep(200);val paused=count(played);val frame=model().session.playerMetrics().frames
            Thread.sleep(500);assertEquals(paused,count(played));assertEquals(frame,model().session.playerMetrics().frames)
            val beforeResumeNonzero=count(nonzero)
            i.targetContext.startActivity(Intent(compose.activity.intent).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            waitFor("PCM foreground resumed") {compose.activity.hasWindowFocus() && model().session.state.value==SessionState.RUNNING && count(played)>paused && count(nonzero)>beforeResumeNonzero}
            actualFrame()
            File(i.targetContext.filesDir,"phase7-api-audio.json").writeText(JSONObject().put("api",android.os.Build.VERSION.SDK_INT).put("initialPlayed",initial).put("backgroundPlayed",paused).put("returnedPlayed",count(played)).put("returnedNonzeroSamples",count(nonzero)).put("backgroundFramesStable",true).put("humanListening","NOT_TESTED").put("result","PASS").toString(2))
        } finally {runBlocking {model().session.stop()};compose.runOnUiThread {model().exit();model().display(original)}}
    }
}
