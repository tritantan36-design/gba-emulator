@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import androidx.activity.compose.setContent
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.core.*
import dev.gbalite.data.SaveRepository
import dev.gbalite.player.ui.GbaTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.File
import java.util.UUID

class BatchDeleteGamesTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    private fun model()=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
    private fun waitFor(f: ()->Boolean)=compose.waitUntil(15000,f)
    private fun rows()=listOf("Batch Alpha","Batch Beta","Other Gamma").map {name ->
        LibraryGame(GameRecord(GameId.fromBytes((name+UUID.randomUUID()).toByteArray()),name,"content://batch-test/$name"),
            "2026-10-09","2026-10-09",1000,false)
    }
    private fun row(game: LibraryGame)=compose.onNodeWithTag("game-${game.record.gameId.value}")
    private fun shot(name: String) {
        compose.waitForIdle()
        val dir=File(compose.activity.filesDir,"batch-delete-screenshots").apply {mkdirs()}
        val bitmap=InstrumentationRegistry.getInstrumentation().uiAutomation.takeScreenshot()!!
        File(dir,"$name.png").outputStream().use {bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it)}
        bitmap.recycle()
    }
    @Test fun longPressBothPagesSearchSelectAllBackAndRestore() {
        val m=model();val games=rows()
        compose.runOnUiThread {compose.activity.findViewById<android.view.ViewGroup>(android.R.id.content).removeAllViews()}
        val restoration=StateRestorationTester(compose)
        restoration.setContent {GbaTheme {AppShell(m,games)}}
        row(games[0]).performTouchInput {longClick()}
        compose.onNodeWithText("已选择 1 项").assertExists();assertFalse(m.playing)
        row(games[1]).performClick();row(games[0]).assertIsSelected();row(games[1]).assertIsSelected()
        compose.onNodeWithText("已选择 2 项").assertExists();shot("home-selection")
        compose.onNodeWithTag("nav-游戏库").performClick()
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithText("已选择 2 项").assertExists();row(games[0]).assertIsSelected()
        compose.onNodeWithTag("library-search").performTextInput("Gamma")
        compose.onNodeWithTag("selection-all").performClick()
        compose.onNodeWithText("已选择 3 项").assertExists()
        compose.onNodeWithTag("selection-all").performClick()
        compose.onNodeWithText("已选择 2 项").assertExists()
        compose.onNodeWithTag("library-search").performTextClearance()
        compose.onNodeWithTag("selection-delete").performClick()
        compose.onNodeWithText("删除 2 个游戏？").assertExists();shot("delete-confirmation")
        compose.onAllNodesWithText("取消").onLast().performClick()
        compose.onNodeWithText("已选择 2 项").assertExists()
        compose.runOnUiThread {compose.activity.onBackPressedDispatcher.onBackPressed()}
        compose.onNodeWithTag("selection-delete").assertDoesNotExist();compose.onNodeWithTag("library-search").assertExists()
        row(games[2]).performTouchInput {longClick()};row(games[2]).performClick()
        compose.onNodeWithText("已选择 0 项").assertExists();compose.onNodeWithTag("selection-delete").assertIsNotEnabled()
        compose.onNodeWithTag("selection-all").performClick();shot("library-selection")
        compose.onNodeWithText("已选择 3 项").assertExists()
        compose.onNodeWithTag("nav-设置").performClick();compose.onNodeWithTag("nav-游戏库").performClick()
        compose.onNodeWithTag("selection-delete").assertDoesNotExist();assertFalse(m.playing)
    }
    @Test fun batchRemovalKeepsSavesSourceAndScreenshotAndRetriesOnlyFailure() {
        val m=model();val games=rows();val ctx=compose.activity.applicationContext
        val repo=SaveRepository(ctx)
        val snapshots=games.map {File(ctx.filesDir,"roms/${it.record.gameId.value}.gba")}
        val sources=games.map {File(ctx.cacheDir,"batch-source-${it.record.gameId.value}.gba")}
        val pictures=games.map {File(ctx.filesDir,"screenshots/${it.record.gameId.value}/batch-sentinel.webp")}
        val event=m.removalEvent
        try {
            games.forEachIndexed {index,game ->
                repo.index(game.record.copy(romUri=sources[index].toURI().toString()))
                repo.played(game.record.gameId)
                repo.writeBattery(game.record.gameId,byteArrayOf(1,2,index.toByte()))
                val stateBytes=byteArrayOf(7,0,0,index.toByte())
                repo.writeState(game.record.gameId,"slot-1",StoredState(stateBytes,StateMetadata(
                    gameId=game.record.gameId.value,createdAt="2026-10-09T00:00:00Z",slot=1,kind="manual",
                    stateSize=stateBytes.size,stateSha256=sha256(stateBytes))))
                sources[index].writeBytes(byteArrayOf(3,4,5))
                pictures[index].parentFile!!.mkdirs();pictures[index].writeBytes(byteArrayOf(6,7,8))
                snapshots[index].parentFile!!.mkdirs()
                if(index==2) {snapshots[index].mkdir();File(snapshots[index],"blocker").writeText("test failure")}
                else snapshots[index].writeBytes(byteArrayOf(9,10,11))
            }
            compose.runOnUiThread {compose.activity.setContent {GbaTheme {
                AppShell(m,if(m.removalEvent==event) games else m.library.filter {g->games.any {it.record.gameId==g.record.gameId}})
            }}}
            row(games[0]).performTouchInput {longClick()}
            compose.onNodeWithTag("selection-all").performClick()
            compose.onNodeWithTag("selection-delete").performClick();compose.onNodeWithTag("selection-confirm-delete").performClick()
            waitFor {!m.removingGames && m.removalEvent>event}
            assertEquals(setOf(games[2].record.gameId),m.removalFailures)
            compose.onNodeWithText("已选择 1 项").assertExists();row(games[2]).assertIsSelected()
            assertTrue(m.message!!.contains("2 个游戏，1 个删除失败"));shot("partial-failure")
            compose.onNodeWithText("重新选择").assertDoesNotExist()
            games.forEachIndexed {index,game ->
                assertArrayEquals(byteArrayOf(1,2,index.toByte()),repo.readBattery(game.record.gameId))
                assertArrayEquals(byteArrayOf(7,0,0,index.toByte()),repo.readState(game.record.gameId,"slot-1")!!.bytes)
                assertArrayEquals(byteArrayOf(3,4,5),sources[index].readBytes())
                assertArrayEquals(byteArrayOf(6,7,8),pictures[index].readBytes())
                assertEquals(index==2,repo.game(game.record.gameId)!!.inLibrary)
            }
            assertFalse(snapshots[0].exists());assertFalse(snapshots[1].exists())
            File(snapshots[2],"blocker").delete();snapshots[2].delete();snapshots[2].writeBytes(byteArrayOf(9))
            val retry=m.removalEvent
            compose.onNodeWithTag("selection-delete").performClick();compose.onNodeWithTag("selection-confirm-delete").performClick()
            waitFor {!m.removingGames && m.removalEvent>retry}
            compose.onNodeWithTag("selection-delete").assertDoesNotExist()
            assertEquals("已删除 1 个游戏",m.successNotice);assertFalse(repo.game(games[2].record.gameId)!!.inLibrary)
            assertFalse(snapshots[2].exists())
            assertArrayEquals(byteArrayOf(1,2,2),repo.readBattery(games[2].record.gameId))
            assertArrayEquals(byteArrayOf(7,0,0,2),repo.readState(games[2].record.gameId,"slot-1")!!.bytes)
        } finally {
            games.forEach {repo.remove(it.record.gameId)}
            snapshots.forEach {if(it.isDirectory) File(it,"blocker").delete();it.delete()}
            sources.forEach {it.delete()};pictures.forEach {it.delete()};repo.close()
        }
    }
    @Test fun continueCardLongPressSharesSelectionAndSurvivesActivityRecreation() {
        val m=model();val i=InstrumentationRegistry.getInstrumentation()
        val uri=android.net.Uri.parse("content://dev.gbalite.app.test.rom/phase6-library.gba")
        i.context.contentResolver.query(uri,null,null,null,null)!!.close()
        i.context.grantUriPermission("dev.gbalite.app",uri,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        compose.runOnUiThread {m.add(uri)}
        waitFor {!m.loading && m.imported!=null};val game=m.imported!!
        try {
            compose.runOnUiThread {m.dismissMessage();m.play(game,false)}
            waitFor {m.playing && !m.loading && m.session.playerMetrics().frames>3}
            compose.runOnUiThread {m.exit()};waitFor {!m.playing && m.library.any {it.record.gameId==game.gameId && it.lastPlayedAt.isNotEmpty()}}
            compose.onNodeWithTag("home-continue").performTouchInput {longClick()}
            compose.onNodeWithText("已选择 1 项").assertExists();assertFalse(m.playing)
            compose.activityRule.scenario.recreate();compose.waitForIdle()
            compose.onNodeWithText("已选择 1 项").assertExists()
            compose.onNodeWithTag("home-continue").assertIsSelected()
            compose.onNodeWithTag("game-${game.gameId.value}").assertIsSelected().performClick()
            compose.onNodeWithText("已选择 0 项").assertExists();assertFalse(m.playing)
            compose.onNodeWithTag("selection-cancel").performClick()
            compose.onNodeWithTag("home-continue").performClick();waitFor {m.playing && !m.loading}
        } finally {if(m.playing) {compose.runOnUiThread {m.exit()};waitFor {!m.playing}}}
    }
}
