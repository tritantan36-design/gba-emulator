@file:OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
package dev.gbalite.app

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import dev.gbalite.core.DisplaySettings
import dev.gbalite.session.SessionState
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.File
import org.json.JSONObject

/** Uses only pre-existing probes so the same test runs on frozen code11 and code12. */
class NormalAudioCadenceTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>(effectContext=kotlinx.coroutines.Dispatchers.Main)
    @Test fun sampleNormalPcm() {
        val i=InstrumentationRegistry.getInstrumentation();val m=ViewModelProvider(compose.activity)[PlayerViewModel::class.java]
        val uri=Uri.parse("content://dev.gbalite.app.test.rom/bringup.gba")
        i.uiAutomation.executeShellCommand("content query --uri $uri").close()
        i.context.grantUriPermission("dev.gbalite.app",uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        compose.runOnUiThread {m.open(uri);m.display(DisplaySettings())}
        compose.waitUntil(15000) {m.playing && !m.loading && m.session.state.value==SessionState.RUNNING}
        val core=m.session.javaClass.getDeclaredField("core").apply {isAccessible=true}.get(m.session)!!
        val handle=core.javaClass.getDeclaredField("handle").apply {isAccessible=true}.getLong(core)
        val cls=Class.forName("dev.gbalite.mgba.JniBridge");val bridge=cls.getDeclaredConstructor().newInstance()
        fun played()=cls.getDeclaredMethod("playedForTest",java.lang.Long.TYPE).invoke(bridge,handle) as Long
        Thread.sleep(2000)
        val out=File(i.targetContext.filesDir,"normal-audio-cadence.jsonl").apply {writeText("")}
        repeat(3) {n->
            val before=m.session.playerMetrics();val pcm=played();val time=System.nanoTime()
            repeat(10) {val segment=played();Thread.sleep(1000);assertTrue("continuous nonzero PCM each second",played()>segment)}
            val after=m.session.playerMetrics()
            out.appendText(JSONObject().put("repeat",n).put("speed",after.speed).put("playedNonzeroDelta",played()-pcm)
                .put("fps",(after.frames-before.frames)*1e9/(System.nanoTime()-time)).put("underrunsDelta",after.audioUnderruns-before.audioUnderruns).toString()+"\n")
            assertEquals(1,after.speed)
        }
    }
}
